/** ***************************************************************************
 * @file        sf_serial.h
 * @brief       Zynq-Linux的Serial应用操作库引用头文件.
 * @details     应用层的Serial串口驱动库,封装对/dev/serial_fpga_x的操作为函数.
 * @author      兰敏刚  <lanmingang@sf-auto.com>
 * @date        6/6/2017 10:38:02
 * @version     Ver 1.1.0
 * @par         Copyright:
 *              北京四方继保自动化股份有限公司.all rights reserved.
 * -----------------------------------------------------------------------
 * @par         History:
 *              Ver 1.1.0:   兰敏刚   6/6/2017 \n
 *              Ver 1.0.0:   崔津津   4/12/2017 \n
 ** **************************************************************************/

#ifndef SF_SERIAL_H
#define SF_SERIAL_H

// 参数范围定义 ==========================================================
#define BAUDRATE_MIN    50              ///< 支持的最低波特率.
#define BAUDRATE_MAX    5000000         ///< 支持的最高波特率.

// 数据类型定义 ==========================================================
/** -----------------------------------------------------------------
 * @enum        sf_serial_request
 * @brief       该Serial库支持的配置请求类型,用于sf_serial_ioctl().
 *
 *-----------------------------------------------------------------*/
enum sf_serial_request{
    SET_BAUDRATE    = 0x01,             ///< 配置波特率.
    SET_STOP        = 0x02,             ///< 配置停止位.
    SET_CHECK       = 0x04,             ///< 配置校验位.
    SET_LED         = 0x08,             ///< 配置LED相关参数.
    SET_FUN         = 0x10,             ///< 配置串口功能.
};

/** -----------------------------------------------------------------
 * @enum        sf_serial_check
 * @brief       该Serial库支持的校验配置类型,用于sf_serial_ioctl().
 *
 *-----------------------------------------------------------------*/
enum sf_serial_check{
    CHECK_NONE      = 0x00,             ///< 无校验.
    CHECK_EVEN      = 0x01,             ///< 偶校验.
    CHECK_ODD       = 0x03,             ///< 奇校验.
};

/** -----------------------------------------------------------------
 * @enum        sf_serial_led
 * @brief       该Serial库支持的LED配置类型,用于sf_serial_ioctl().
 *              >= LED_TIME配置长时ms数,<=-LED_TIME配置短时间ms数.
 *
 *-----------------------------------------------------------------*/
enum sf_serial_led{
    LED_DISABLE     = 0,                ///< 关闭LED功能.
    LED_ENABLE      = 1,                ///< 使能LED功能.
    LED_USER        = 2,                ///< 用户完全控制LED状态.
    LED_AUTO        = 3,                ///< 驱动自动控制LED状态.
    LED_TEST        = 4,                ///< LED亮灭测试.
    LED_ERR         = 5,                ///< LED错误指示.
    LED_TX          = 6,                ///< LED发送指示.
    LED_RX          = 7,                ///< LED接收指示.
    LED_TR          = 8,                ///< LED收发指示.
    LED_ASYNC       = 9,                ///< LED异步模式(总体配置).
    LED_SYNC        = 10,               ///< LED同步模式(总体配置).
    LED_MUTI        = 50,               ///< LED数据窗/显示窗倍率(总体配置,50为默认,51为1倍,...).
    LED_TIME        = 100,              ///< LED显示窗长短时间配置(总体配置,正长负短,ms).
};

/** -----------------------------------------------------------------
 * @enum        sf_serial_fun
 * @brief       该Serial库支持的功能配置类型,用于sf_serial_ioctl().
 *              >= LED_TIME配置长时ms数,<=-LED_TIME配置短时间ms数.
 *
 *-----------------------------------------------------------------*/
enum sf_serial_fun{
    FUN_RS485       = 0,                ///< RS485功能.
    FUN_RS232       = 1,                ///< RS232功能.
};

#ifdef __cplusplus
extern "C" {
#endif

// 公共函数声明 ==========================================================
/** -----------------------------------------------------------------
 * @fn          int sf_serial_gver(void)
 * @brief       读取串口接口库的git版本信息.
 * @details     返回整形的git版本ID信息.
 *
 * @param [in]  void -> NONE.
 *
 * @return      int -> 借口库git版本ID.
 *
 *-----------------------------------------------------------------*/
extern int sf_serial_gver(void);

/** -----------------------------------------------------------------
 * @fn          void sf_serial_gverstr(char *pver)
 * @brief       读取串口接口库的git版本信息.
 * @details     返回字符串形的git版本ID信息.
 *
 * @param [out] char* pver -> 待存储git版本ID字符串的地址,需>12字节.
 *
 * @return      void -> NONE.
 *
 *-----------------------------------------------------------------*/
extern void sf_serial_gverstr(char *pver); 

/** -----------------------------------------------------------------
 * @fn          void sf_serial_verstr(char *pver)
 * @brief       读取串口接口库的版本信息.
 * @details     返回字符串形的库版本信息.
 *
 * @param [out] char* pver -> 待存储库版本字符串的地址,需>8字节.
 *
 * @return      void -> NONE.
 *
 *-----------------------------------------------------------------*/
extern void sf_serial_verstr(char *pver); 

/** -----------------------------------------------------------------
 * @fn          int sf_serial_dnum(void)
 * @brief       获取当前已例化可用的串口设备数量.
 * @details     通过访问设备驱动引出的配置参数接口获得.
 *
 * @param [in]  void -> NONE.
 *
 * @return      int -> >=0-已例化可用的串口数,<0-错误(设备驱动未提供接口).
 *
 *-----------------------------------------------------------------*/
extern int sf_serial_dnum(void); 

/** -----------------------------------------------------------------
 * @fn          int sf_serial_dverstr(char *pver)
 * @brief       获取当前串口设备驱动版本信息.
 * @details     通过访问设备驱动引出的配置参数接口获得.
 *
 * @param [out] char* pver -> 待存储库版本字符串的地址,需>20字节.
 *
 * @return      int -> >=0-成功获取,<0-错误(设备驱动未提供接口).
 *
 *-----------------------------------------------------------------*/
extern int sf_serial_dverstr(char *pver);

/** -----------------------------------------------------------------
 * @fn          int sf_serial_open(unsigned int unit, int baudrate)
 * @brief       打开Serial接口.
 * @details     在使用接口前都需首先open,使用完成后close释放.
 *
 * @param [in]  unsigned int unit -> Serial接口号,从0开始.
 * @param [in]  int baudrate -> 串口速率,bps.
 *
 * @return      int -> >=0-对应串口设备文件描述符,<0-错误.
 *
 *-----------------------------------------------------------------*/
extern int sf_serial_open(unsigned int unit, int baudrate);


/** -----------------------------------------------------------------
 * @fn          int sf_serial_close(int fd)
 * @brief       关闭Serial接口.
 * @details     inline函数,串口使用完成后close释放.
 *
 * @param [in]  int fd -> 串口设备文件描述符,由sf_serial_open()返回.
 *
 * @return      int -> 0-成功,-1-失败.
 *
 *-----------------------------------------------------------------*/
static inline int sf_serial_close(int fd)
{
	return close(fd);
}

/** -----------------------------------------------------------------
 * @fn          int sf_serial_read(int fd, char *buf, int len)
 * @brief       接收(读取)串口数据.
 * @details     inline函数,是否阻塞由O_NONBLOCK标志控制.
 *
 * @param [in]  int fd -> 串口设备文件描述符,由sf_serial_open()返回.
 * @param [out] char* buf -> 待存储接收数据缓存地址.
 * @param [in]  int len -> 待存储接收数据缓存长度.
 *
 * @return      int -> >=0-实际读取字节数,-1-失败.
 *
 *-----------------------------------------------------------------*/
static inline int sf_serial_read(int fd, char* buf, int len)
{
	int nbytes = 0;

	nbytes = read(fd, buf, len);
	
	return(nbytes);
}

/** -----------------------------------------------------------------
 * @fn          int sf_serial_write(int fd, char *buf, int len)
 * @brief       接收(写入)串口数据.
 * @details     inline函数,是否阻塞由O_NONBLOCK标志控制.
 *
 * @param [in]  int fd -> 串口设备文件描述符,由sf_serial_open()返回.
 * @param [in]  char* buf -> 待发送数据缓存地址.
 * @param [in]  int len -> 待发送数据长度.
 *
 * @return      int -> >=0-实际发送字节数,-1-失败.
 *
 *-----------------------------------------------------------------*/
static inline int sf_serial_write(int fd, char* buf, int len)
{
	int nbytes = 0;

	nbytes = write(fd, buf, len);

	return(nbytes);
}

/** -----------------------------------------------------------------
 * @fn          int sf_serial_ioctl(int fd, int request, void *argu)
 * @brief       设置串口参数属性.
 * @details     inline函数,用于配置串口波特率/校验位/停止位等.
 *
 * @param [in]  int fd -> 串口设备文件描述符,由sf_serial_open()返回.
 * @param [in]  int request -> 配置参数类型,见sf_serial_request.
 * @param [in]  void* argu -> 配置参数值,SET_CHECK类型值见sf_serial_check.
 *
 * @return      int -> 0-成功,-1-失败.
 *
 *-----------------------------------------------------------------*/
extern int sf_serial_ioctl(int fd, int request, void *argu);


#ifdef __cplusplus
}
#endif

#endif  // End of SF_SERIAL_H
/** ********************** -|- End of the H File -|- *************************/
