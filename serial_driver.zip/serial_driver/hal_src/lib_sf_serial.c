#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>

#include <assert.h>

#include "sf_serial.h"
#include "lib_sf_serial.h"
#include "../ver_inc/git_ver.h"
#include "sflibver.h"

SFLIB_VER_DECLARE(sfserial, SFSERIAL_LIB_VER, GIT_COMMIT_ID_STR)

int sf_serial_gver(void)
{
	return(GIT_COMMIT_ID);
}

void sf_serial_gverstr(char *pver)
{
    if(pver) {
        strcpy(pver, GIT_COMMIT_ID_STR);
    }
}

void sf_serial_verstr(char *pver)
{
    if(pver) {
        strcpy(pver, SFSERIAL_LIB_VER);
    }
}

int sf_serial_dnum(void)
{
    FILE * pfd = NULL;
    int num = 0;

    pfd = fopen(SFSERIAL_DRIVER_NUMPARA, "r");
    if(NULL == pfd) {
        return -1;  
    }

    fscanf(pfd, "%d", &num);

    fclose(pfd);

    return num;
}

int sf_serial_dverstr(char *pver)
{
    FILE * pfd = NULL;
    char dver[20];

    if(pver) {
        pfd = fopen(SFSERIAL_DRIVER_VERPARA, "r");
        if(NULL == pfd) {
            return -1;  
        }

        memset(dver, 0x0, 20);
        fscanf(pfd, "%s", dver);

        fclose(pfd);

        strcpy(pver, dver);
        return 0;
    }

    return -1;  
}

int sf_serial_open(unsigned int unit, int baudrate)
{
    char serial_dev_name[64];
	int fd = 0;
	int ret = 0;
	int check = CHECK_NONE;

    if((baudrate > BAUDRATE_MAX) || (baudrate < BAUDRATE_MIN)) {
		PRINT_ERR("input baudrate:%d is error!\n",baudrate);
		return -1;
	}
    
    sprintf(serial_dev_name, "%s%d", SFSERIAL_DEVICE_PRE, unit);

    fd = open(serial_dev_name, O_RDWR|O_NONBLOCK);
	if(fd<0) {
        PRINT_ERR("open %s error!\n",serial_dev_name);
		return -1;	
	}
	
	ret = ioctl(fd, SET_BAUDRATE, &baudrate);  
	if(ret < 0) {
        PRINT_ERR("set %s baudrate:%d error!\n", serial_dev_name, baudrate);
		close(fd);
		return -1;	
	}

	/* No blocking */
	ret = ioctl(fd, SET_CHECK, &check);
	if(ret < 0) {
        PRINT_ERR("set %s check error!\n", serial_dev_name);
		close(fd);
		return -1;	
	}
	
    PRINT_INFO("dev:%s baudrate:%d open ok!\n",serial_dev_name,baudrate);
	return fd;
}

int sf_serial_ioctl(int fd, int request, void *argu)
{
    int rs = 0;
    int funreg = 0;
    int gp_mem_fd;
    void * gp_mmap_vbase;

    if(SET_FUN == request) {
        rs = ioctl(fd, request, &funreg);
        if(0 == rs && 0 < funreg && GP_MMAPSIZE >funreg) {
            gp_mem_fd = open(GP_MEMDEV, O_RDWR);
            if (0 > gp_mem_fd) {
                rs = -1;
            }
            else {
                gp_mmap_vbase = mmap(NULL, GP_MMAPSIZE, PROT_READ | PROT_WRITE, MAP_SHARED, gp_mem_fd, GP_BASEADDR);
                if (MAP_FAILED == gp_mmap_vbase) {
                    close(gp_mem_fd);
                    rs = -1;
                }
                else {
                    *((int *)(gp_mmap_vbase + funreg)) = *((int *)argu);

                     munmap(gp_mmap_vbase, GP_MMAPSIZE);
                     close(gp_mem_fd);
                }
            }
        }
        else {
            rs = -1;
        }
    }
    else {
        rs = ioctl(fd, request, argu);
    }

    return(rs);
}