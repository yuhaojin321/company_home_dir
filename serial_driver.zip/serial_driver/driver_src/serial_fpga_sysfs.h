#ifndef _SERIAL_FPGA_SYSFS_H_
#define _SERIAL_FPGA_SYSFS_H_

extern int serial_sysfs_create(struct class *dev_class,const char *dev_name);
extern int serial_sysfs_release(struct class *dev_class);

#endif /*_SERIAL_FPGA_SYSFS_H_*/