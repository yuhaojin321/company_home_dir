#ifndef _SERIAL_FPGA_MAIN_H_
#define _SERIAL_FPGA_MAIN_H_

#include <linux/semaphore.h>
#include <linux/kfifo.h>

#include "basetype.h"

#define VER_INFO    "V0.43"
#define SERIAL_FPGA_DEV_NAME	"serial_fpga"
#define SERIAL_FPGA_DEV_MAX     32

#ifdef CONFIG_AMP_GP
#define GP_BASE_ADDR				(0x80000000)
#pragma message("Complie gp amp mode GP:0x80000000!")
#else
#define GP_BASE_ADDR				(0x40000000)
#pragma message("Complie gp smp mode GP:0x40000000!")
#endif

#define GP_SERIAL_FLAG_OFFSET		(0x284)
#define GP_SERIAL_NUM_OFFSET		(0x314)
#define SERIAL_BASE_ADDR(address,x)	(address+(0x100 * x))
#define SERIAL_FPGA_NR				(16)

#define POLLING_FREQ                (500000)

#define SERIAL_LED_TICK_MS          (100)
#define SERIAL_LED_TICK_COUNT       ((1000000/POLLING_FREQ)*SERIAL_LED_TICK_MS)
#define SERIAL_LED_SHORT_MS         (200)
#define SERIAL_LED_SHORT_TICKS      (SERIAL_LED_SHORT_MS/SERIAL_LED_TICK_MS)
#define SERIAL_LED_LONG_MS          (1300)
#define SERIAL_LED_LONG_TICKS       (SERIAL_LED_LONG_MS/SERIAL_LED_TICK_MS)
#define SERIAL_LED_MODE_DEF         (1)         /* default mode: 0-async, 1-sync */
#define SERIAL_LED_MUTI_DEF         (6)         /* default muti: data time muti for fresh */

#define REG_WR(u32_OutAddress, u32_Value)		(*(volatile uint32*) (u32_OutAddress) = u32_Value)
#define REG_RD(u32_Addr)  					 	(*(volatile uint32*) (u32_Addr))

#define RX_FIFO_IS_NULL(u32_Addr)				(REG_RD(u32_Addr+SERIAL_RF_STAT_OFFSET) & 0x01)
#define SD_FIFO_IS_FULL(u32_Addr)				(REG_RD(u32_Addr+SERIAL_STATUS_OFFSET) & 0x01)

#define SERIAL_LED_ON(u32_Addr)                 REG_WR(u32_Addr+SERIAL_LED_CTRL_OFFSET, 0x0)
#define SERIAL_LED_OFF(u32_Addr)                REG_WR(u32_Addr+SERIAL_LED_CTRL_OFFSET, 0x1)

#define SERIAL_FPGA_BUF_SIZE	(0x400)

typedef struct serial_fpga_attr_stru {
	uint32 phy_addr;
	uint32 remap_addr;
	uint32 is_opened;
    uint32 fun_offset;
    uint32 led_status;
    uint16 led_on_tick;
    uint16 led_off_tick;
    uint16 led_count;
	struct device* p_dev;
	struct semaphore semWr;
	struct semaphore semRd;
	struct kfifo recv_fifo;
	struct kfifo send_fifo;
} serial_fpga_attr_t;

typedef struct serial_fpga_dev_stru {
    struct cdev cdev;
	struct class *dev_class;
	serial_fpga_attr_t dev_attr[SERIAL_FPGA_NR];
} serial_fpga_dev_t;

typedef enum {
	SERIAL_BITRATE_OFFSET 		= 0,
	SERIAL_CHECK_OFFSET			= 0x04,
	SERIAL_STATUS_OFFSET		= 0x08,
	SERIAL_TX_DATA_OFFSET		= 0x0C,
	SERIAL_RX_DATA_OFFSET		= 0x10,
	SERIAL_RF_STAT_OFFSET		= 0x14,		/*recv fifo*/
    SERIAL_LED_CTRL_OFFSET      = 0x18,     /*led ctrl*/
} _GP_SERIAL_OFFSET_T;

enum {
    LED_STATUS_DISABLE          = 0x0000,   /*disable status*/
    LED_STATUS_ENABLE           = 0x0001,   /*enable status*/
    LED_STATUS_USER             = 0x0002,   /*hand by user flag*/
    LED_STATUS_LIGHT            = 0x0004,   /*on/off status*/
    LED_STATUS_TEST             = 0x0010,   /*test status*/
    LED_STATUS_TESTING          = 0x0020,   /*test opt*/
    LED_STATUS_RX               = 0x0040,   /*rx status*/
    LED_STATUS_RXING            = 0x0080,   /*rx opt*/
    LED_STATUS_TX               = 0x0100,   /*tx status*/
    LED_STATUS_TXING            = 0x0200,   /*tx opt*/
    LED_STATUS_ERR              = 0x0400,   /*err status*/
    LED_STATUS_ERRING           = 0x0800,   /*err opt*/
};

enum {
	SET_BAUDRATE	= 0x01,
	SET_STOP		= 0x02,
	SET_CHECK		= 0x04,
    SET_LED         = 0x08,
    GET_FUN         = 0x10,
};

enum {
    CHECK_NONE      = 0x00,
    CHECK_EVEN      = 0x01,
    CHECK_ODD       = 0x03,
};

enum {
    LED_DISABLE     = 0,
    LED_ENABLE      = 1,
    LED_USER        = 2,
    LED_AUTO        = 3,
    LED_TEST        = 4,
    LED_ERR         = 5,
    LED_TX          = 6,
    LED_RX          = 7,
    LED_TR          = 8,
    LED_ASYNC       = 9,
    LED_SYNC        = 10,
    LED_MUTI        = 50,
    LED_TIME        = 100,
};

#endif /*_SERIAL_FPGA_MAIN_H_*/
