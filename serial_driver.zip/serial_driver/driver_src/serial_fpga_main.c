#ifndef _SERIAL_FPGA_MAIN_C_
#define _SERIAL_FPGA_MAIN_C_


#include <linux/module.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <linux/poll.h>
#include <linux/device.h>
#include <asm/io.h>
#include <linux/mm.h>
#include <linux/fs.h>

#include "basetype.h"
#include "basedefine.h"
#include "serial_fpga_main.h"
#include "serial_fpga_sysfs.h"
#include "../ver_inc/git_ver.h"

static int32 set_check(uint32 minor,int32 value);
static int32 set_baudrate(uint32 minor,int32 baud);

static uint32 serial_fpga_major = 0;

static uint32 serial_fpga_nr = 0;
module_param(serial_fpga_nr, int, 0444);
MODULE_PARM_DESC(serial_fpga_nr, "fpga serial device number");

static char *serial_fpga_ver = VER_INFO;
module_param(serial_fpga_ver, charp, 0444);
MODULE_PARM_DESC(serial_fpga_ver, "fpga serial driver version");

static uint32 serial_fpga_led_long_tick = SERIAL_LED_LONG_TICKS;
module_param(serial_fpga_led_long_tick, int, 0444);
MODULE_PARM_DESC(serial_fpga_led_long_tick, "fpga serial led long tick");

static uint32 serial_fpga_led_short_tick = SERIAL_LED_SHORT_TICKS;
module_param(serial_fpga_led_short_tick, int, 0444);
MODULE_PARM_DESC(serial_fpga_led_short_tick, "fpga serial led short tick");

static uint32 serial_fpga_led_mode = SERIAL_LED_MODE_DEF;
module_param(serial_fpga_led_mode, int, 0444);
MODULE_PARM_DESC(serial_fpga_led_mode, "fpga serial led mode");

static uint32 serial_fpga_led_sync_muti = SERIAL_LED_MUTI_DEF;
module_param(serial_fpga_led_sync_muti, int, 0444);
MODULE_PARM_DESC(serial_fpga_led_sync_muti, "fpga serial led muti of data");

static serial_fpga_dev_t serial_fpga_dev; 
static struct hrtimer serial_fpga_timer;
static ktime_t kt;

static uint32 serial_fpga_led_count = 0;
static uint32 serial_fpga_led_sync_tick = 0;

static void serial_fpga_led_retick(serial_fpga_attr_t *dev)
{
    if(dev) {
        if (!(dev->led_status & LED_STATUS_ENABLE)) {
            dev->led_on_tick = 0;
            dev->led_off_tick = 0;
        }
        else if (dev->led_status & LED_STATUS_TEST) {
            dev->led_on_tick = serial_fpga_led_long_tick;
            dev->led_off_tick = serial_fpga_led_long_tick;
        }
        else if (dev->led_status & LED_STATUS_ERR) {
            dev->led_on_tick = serial_fpga_led_short_tick;
            dev->led_off_tick = serial_fpga_led_short_tick;
        }
        else if((dev->led_status & LED_STATUS_TX) &&
                (dev->led_status & LED_STATUS_RX)) {
            dev->led_on_tick = serial_fpga_led_long_tick;
            dev->led_off_tick = serial_fpga_led_short_tick;
        }
        else if(dev->led_status & LED_STATUS_TX) {
            dev->led_on_tick = serial_fpga_led_short_tick;
            dev->led_off_tick = serial_fpga_led_long_tick;
        }
        else if(dev->led_status & LED_STATUS_RX) {
            dev->led_on_tick = serial_fpga_led_long_tick + serial_fpga_led_short_tick;
            dev->led_off_tick = 0;
        }
    }
}

static void serial_fpga_led_restatus(serial_fpga_attr_t *dev)
{
    if(dev) {
        if(!(dev->led_status & LED_STATUS_ENABLE)) {
            serial_fpga_led_retick(dev);
            dev->led_count = 0;
            dev->led_status &= LED_STATUS_LIGHT; // only keep light status if disable.
        }
        else if(0 == serial_fpga_led_mode || // led mode: async.
                0 == serial_fpga_led_sync_tick) { // or led mode: sync and tick timeout.
            if(dev->led_status & LED_STATUS_TESTING) {
                if(!(dev->led_status & LED_STATUS_TEST)) {
                    dev->led_status &= ~LED_STATUS_TESTING;
                    dev->led_status |= LED_STATUS_TEST;
                    serial_fpga_led_retick(dev);
                    dev->led_count = 3 * serial_fpga_led_sync_muti;
                }
            }
            else if(dev->led_status & LED_STATUS_ERRING) {
                if(!(dev->led_status & LED_STATUS_ERR)) {
                    dev->led_status &= ~LED_STATUS_ERRING;
                    dev->led_status |= LED_STATUS_ERR;
                    serial_fpga_led_retick(dev);
                    dev->led_count = 5 * serial_fpga_led_sync_muti;
                }
            }
            else {
                if(dev->led_status & LED_STATUS_TXING) {
                    if(!(dev->led_status & LED_STATUS_TX)) {
                        dev->led_status &= ~LED_STATUS_TXING;
                        dev->led_status |= LED_STATUS_TX;
                        serial_fpga_led_retick(dev);
                        dev->led_count = 1 * serial_fpga_led_sync_muti;
                    }
                }

                if(dev->led_status & LED_STATUS_RXING) {
                    if(!(dev->led_status & LED_STATUS_RX)) {
                        dev->led_status &= ~LED_STATUS_RXING;
                        dev->led_status |= LED_STATUS_RX;
                        serial_fpga_led_retick(dev);
                        dev->led_count = 1 * serial_fpga_led_sync_muti;
                    }
                }
            }
        }
    }
}

static void serial_fpga_led_reset(serial_fpga_attr_t *dev)
{
    if(dev) {
        dev->led_status &= ~(LED_STATUS_TEST | LED_STATUS_ERR | LED_STATUS_TX | LED_STATUS_RX);
    }
}

static enum hrtimer_restart serial_fpga_hrtimer_func(struct hrtimer *timer)
{
	int32 i = 0;
	serial_fpga_attr_t *dev_attr_p = NULL;
	uint32 remap_addr = 0;
#define SERIAL_FPGA_RECV_FIFO	(256)	
	char recv_data[SERIAL_FPGA_RECV_FIFO] = {0};
    uint32 recv_len = 0, send_len = 0;
	
	char send_data = 0;
    int32 rs = 0;
	
	hrtimer_forward_now(&serial_fpga_timer, kt);
	
	for(i = 0; i < serial_fpga_nr; i++) {
		/*recv function*/
		dev_attr_p = &(serial_fpga_dev.dev_attr[i]);
		if(dev_attr_p->is_opened == 0) continue;
		recv_len = 0;
		memset(recv_data,0,SERIAL_FPGA_RECV_FIFO);
		remap_addr = serial_fpga_dev.dev_attr[i].remap_addr;
		
		while(RX_FIFO_IS_NULL(remap_addr) != 0x01) {
			recv_data[recv_len] = REG_RD(remap_addr+SERIAL_RX_DATA_OFFSET);
			recv_len++;
			
			if(recv_len == SERIAL_FPGA_RECV_FIFO)	break;
        }
        kfifo_in(&dev_attr_p->recv_fifo, recv_data, recv_len);

        if(!(dev_attr_p->led_status & LED_STATUS_USER) && recv_len) {
            dev_attr_p->led_status |= LED_STATUS_RXING;
        }
    }

	for(i = 0; i < serial_fpga_nr; i++) {
		/*send function*/
		dev_attr_p = &(serial_fpga_dev.dev_attr[i]);
		
		if(dev_attr_p->is_opened == 0) continue;
		if(kfifo_is_empty(&dev_attr_p->send_fifo)) continue;
		
		remap_addr = serial_fpga_dev.dev_attr[i].remap_addr;
		
        send_len = 0;
		while(SD_FIFO_IS_FULL(remap_addr) == 0x01) {
			rs = kfifo_out(&dev_attr_p->send_fifo, &send_data, 1);
			if(rs == 0)	break;
            send_len ++;
			
			REG_WR(remap_addr+SERIAL_TX_DATA_OFFSET, send_data);
		}

        if(!(dev_attr_p->led_status & LED_STATUS_USER) && send_len) {
            dev_attr_p->led_status |= LED_STATUS_TXING;
        }
    }

    serial_fpga_led_count++;
    if(SERIAL_LED_TICK_COUNT <= serial_fpga_led_count) {
        serial_fpga_led_count = 0;
        
        for(i = 0; i < serial_fpga_nr; i++) {
            /*led function*/
            dev_attr_p = &(serial_fpga_dev.dev_attr[i]);
            remap_addr = serial_fpga_dev.dev_attr[i].remap_addr;

            serial_fpga_led_restatus(dev_attr_p);

LED_REFRESH:
            if(dev_attr_p->led_on_tick) {
                if(!(dev_attr_p->led_status & LED_STATUS_LIGHT)) {
                    dev_attr_p->led_status |= LED_STATUS_LIGHT;
                    SERIAL_LED_ON(remap_addr);
                }
                dev_attr_p->led_on_tick--;
            }
            else if(dev_attr_p->led_off_tick) {
                if(dev_attr_p->led_status & LED_STATUS_LIGHT) {
                    dev_attr_p->led_status &= ~LED_STATUS_LIGHT;
                    SERIAL_LED_OFF(remap_addr);
                }
                dev_attr_p->led_off_tick--;
            }
            else if(dev_attr_p->led_count) {
                dev_attr_p->led_count--;
                if(dev_attr_p->led_count) {
                    serial_fpga_led_retick(dev_attr_p);

                    goto LED_REFRESH;
                }
                else {
                    serial_fpga_led_reset(dev_attr_p);
                    serial_fpga_led_restatus(dev_attr_p);
                    
                    goto LED_REFRESH;
                }
            }
            else {
                if(dev_attr_p->led_status & LED_STATUS_LIGHT) {
                    dev_attr_p->led_status &= ~LED_STATUS_LIGHT;
                    SERIAL_LED_OFF(remap_addr);
                }
            }
        }

        if(serial_fpga_led_sync_tick) {
            serial_fpga_led_sync_tick --;
        }
        else {
            serial_fpga_led_sync_tick = (serial_fpga_led_long_tick + serial_fpga_led_short_tick) * serial_fpga_led_sync_muti - 1;
        }
    }
	
	return HRTIMER_RESTART;
}

int do_serial_info_show(char* buf)
{
	serial_fpga_attr_t *dev_attr_p = NULL;
	char *ps = buf;
	int32	rs 	= 0;
	int32 len = 0;
	int32 i	= 0;
	
	rs = sprintf(ps, "################################\n");
	len = len + rs;
	ps = ps + rs;
	
	rs = sprintf(ps, "GIT COMMIT ID:%s\n",GIT_COMMIT_ID_STR);
	len = len + rs;
	ps = ps + rs;
	
	for(i=0; i<serial_fpga_nr; i++) {
		
		rs = sprintf(ps, "serial_%d:phyAddr:0x%08x ->0x%08x\n", i, serial_fpga_dev.dev_attr[i].phy_addr,\
				serial_fpga_dev.dev_attr[i].remap_addr);
		len = len + rs;
		ps = ps + rs;
		
		dev_attr_p = &(serial_fpga_dev.dev_attr[i]);
		rs = sprintf(ps, "recv_fifo: size:%d use:%d\n", kfifo_size(&dev_attr_p->recv_fifo), kfifo_len(&dev_attr_p->recv_fifo));
		len = len + rs;
		ps = ps + rs;
		
		rs = sprintf(ps, "send_fifo: size:%d use:%d\n\n", kfifo_size(&dev_attr_p->send_fifo), kfifo_len(&dev_attr_p->send_fifo));
		len = len + rs;
		ps = ps + rs;
	}
	
	return(len);
}

static int serial_fpga_open(struct inode *inode,struct file *file)
{
	uint32 minor = MINOR(file->f_dentry->d_inode->i_rdev);
	serial_fpga_attr_t *dev_attr_p = NULL;
	
	if(unlikely(minor >= SERIAL_FPGA_NR))	return(RTN_ERR);
	
	dev_attr_p = &(serial_fpga_dev.dev_attr[minor]);
	
	set_baudrate(minor,115200);
	set_check(minor,0);

	dev_attr_p->is_opened = 1;
		
	return(RTN_OK);
}

static int serial_fpga_release(struct inode *inode,struct file *file)
{
	uint32 minor = iminor(inode);
	serial_fpga_attr_t *dev_attr_p = NULL;
	
	if(unlikely(minor >= SERIAL_FPGA_NR))	return(RTN_ERR);
	
	dev_attr_p = &(serial_fpga_dev.dev_attr[minor]);
	
	dev_attr_p->is_opened = 0;
						
	return(RTN_OK);
}

static ssize_t serial_fpga_read(struct file *file,char __user *buf,size_t count,loff_t *ppos)
{
	uint32 minor = MINOR(file->f_dentry->d_inode->i_rdev);
	serial_fpga_attr_t *dev_attr_p = NULL;
	uint32 rs = 0;
	uint32 copied = 0;

	if(unlikely(minor >= SERIAL_FPGA_NR))	return -EIO;
	
	dev_attr_p = &(serial_fpga_dev.dev_attr[minor]);
		
	if (down_trylock(&dev_attr_p->semRd) != 0) {
		if (file->f_flags & O_NONBLOCK)		return -EAGAIN;
		if (down_interruptible(&dev_attr_p->semRd)) {
			return -ERESTARTSYS;
		}
	}
	
	rs = kfifo_to_user(&dev_attr_p->recv_fifo, buf, count, &copied);

	up(&dev_attr_p->semRd);
	return(rs ? rs : copied);
}

static ssize_t serial_fpga_write(struct file *file,const char __user *buf,size_t count,loff_t *ppos)
{
	uint32 minor = MINOR(file->f_dentry->d_inode->i_rdev);
	serial_fpga_attr_t *dev_attr_p = NULL;
	uint32 rs = 0;
	uint32 copied = 0;
	
	if(unlikely(minor >= SERIAL_FPGA_NR))	return -EIO;
	
	dev_attr_p = &(serial_fpga_dev.dev_attr[minor]);
	
	if (down_trylock(&dev_attr_p->semWr) != 0) {
		if (file->f_flags & O_NONBLOCK)		return -EAGAIN;
		if (down_interruptible(&dev_attr_p->semWr)) {
			return -ERESTARTSYS;
		}
	}
	
	rs = kfifo_from_user(&dev_attr_p->send_fifo, buf, count, &copied);

	up(&dev_attr_p->semWr);
	return(rs ? rs : copied);
}

static void set_stop(unsigned int minor1,int value)
{
	/* fpga serial mode don't provide this function */
	return;
}

static int32 set_check(uint32 minor,int32 value)
{
	uint32 remap_addr = 0;
	
	if(value != CHECK_NONE && value != CHECK_ODD && value != CHECK_EVEN)
		return(RTN_ERR);
	
	remap_addr = serial_fpga_dev.dev_attr[minor].remap_addr;

	REG_WR((remap_addr+SERIAL_CHECK_OFFSET),value);
	
	return(RTN_OK);
}

static int32 set_baudrate(uint32 minor,int32 baud)
{
    uint32 dl_baud[30] = {
        2500000,
        2083333,
        1666667,
        1250000,
        1041667,
        833333,
        625000,
        416666,
        208333,
        104167,
        52084,
        26042,
        13021,
        6511,
        3256,
        2171,
        1085,
        542,
        271,
        136,
        125,
        100,
        83,
        62,
        50,
        42,
        36,
        31,
        28,
        25,
	};
    uint32 pos = 16;
	uint32 remap_addr = 0;
	int32 rs = RTN_OK;
	
	remap_addr = serial_fpga_dev.dev_attr[minor].remap_addr;

	switch (baud){
        case 50:   
            pos = 0;
            break;
        case 60:   
            pos = 1;
            break;
        case 75:   
            pos = 2;
            break;
        case 100:   
            pos = 3;
            break;
        case 120:   
            pos = 4;
            break;
        case 150:   
            pos = 5;
            break;
        case 200:   
            pos = 6;
            break;
        case 300:   
            pos = 7;
            break;
        case 600:   
            pos = 8;
            break;
		case 1200:	
            pos = 9;
			break;
		case 2400:	
            pos = 10;
			break;	
		case 4800:	
            pos = 11;
			break;
		case 9600:	
            pos = 12;
			break;
		case 19200:	
            pos = 13;
			break;
		case 38400:	
            pos = 14;
			break;		
		case 57600:	
            pos = 15;
			break;
		case 115200:	
            pos = 16;
			break;
        case 230400:    
            pos = 17;
            break;
        case 460800:    
            pos = 18;
            break;
        case 921600:    
            pos = 19;
            break;
        case 1000000:    
            pos = 20;
            break;
        case 1250000:    
            pos = 21;
            break;
        case 1500000:    
            pos = 22;
            break;
        case 2000000:    
            pos = 23;
            break;
        case 2500000:    
            pos = 24;
            break;
        case 3000000:    
            pos = 25;
            break;
        case 3500000:    
            pos = 26;
            break;
        case 4000000:    
            pos = 27;
            break;
        case 4500000:    
            pos = 28;
            break;
        case 5000000:    
            pos = 29;
            break;
		default:	
            pos = 16;
			rs = RTN_ERR;
			break;		
	}
	
	REG_WR((remap_addr+SERIAL_BITRATE_OFFSET),dl_baud[pos]);
	
	return(rs);
}

static int32 set_led(uint32 minor,int32 value)
{
    int32 ret = RTN_OK;
    int neg = 0;
    
    if(0 > value) {
        neg = 1;
        value = 0 - value;
    }

    if(LED_TIME <= value) {
        if(neg) {
            serial_fpga_led_short_tick = value / SERIAL_LED_TICK_MS;
        }
        else {
            serial_fpga_led_long_tick = value / SERIAL_LED_TICK_MS;
        }
    }
    else if(!neg){
        if(LED_MUTI <= value) {
            serial_fpga_led_sync_muti = (0 == value - LED_MUTI) ? SERIAL_LED_MUTI_DEF : (value - LED_MUTI);
        }
        else {
            switch(value) {
            case LED_DISABLE:
                serial_fpga_dev.dev_attr[minor].led_status &= ~LED_STATUS_ENABLE;
                break;
            case LED_ENABLE:
                serial_fpga_dev.dev_attr[minor].led_status |= LED_STATUS_ENABLE;
                break;
            case LED_USER:
                serial_fpga_dev.dev_attr[minor].led_status |= LED_STATUS_USER;
                break;
            case LED_AUTO:
                serial_fpga_dev.dev_attr[minor].led_status &= ~LED_STATUS_USER;
                break;
            case LED_TEST:
                serial_fpga_dev.dev_attr[minor].led_status |= LED_STATUS_TESTING;
                break;
            case LED_ERR:
                serial_fpga_dev.dev_attr[minor].led_status |= LED_STATUS_ERRING;
                break;
            case LED_TX:
                serial_fpga_dev.dev_attr[minor].led_status |= LED_STATUS_TXING;
                break;
            case LED_RX:
                serial_fpga_dev.dev_attr[minor].led_status |= LED_STATUS_RXING;
                break;
            case LED_TR:
                serial_fpga_dev.dev_attr[minor].led_status |= (LED_STATUS_TXING | LED_STATUS_RXING);
                break;
            case LED_ASYNC:
                serial_fpga_led_mode = 0;
                break;
            case LED_SYNC:
                serial_fpga_led_mode = 1;
                serial_fpga_led_sync_tick = 0;
                break;
            default:
                ret = RTN_ERR;
                break;
            }
        }
    }
    else
    {
        ret = RTN_ERR;
    }

    return(ret);
}

static int32 get_fun(uint32 minor,int32 *value)
{
    if(value) {
        *value = serial_fpga_dev.dev_attr[minor].fun_offset;
    }
    return(RTN_OK);
}

static long serial_fpga_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	uint32 minor = iminor(file->f_mapping->host);	
	int32 new_options = 0;
	void __user *argp = (void __user *)arg;
	int32 __user *p = argp;
	int32 rs = RTN_OK;

	if(minor >= serial_fpga_nr) 
		return(RTN_ERR);

	if(get_user(new_options, p) != 0)
		return(RTN_ERR);
	
	switch (cmd) {
		case SET_BAUDRATE:		
			rs = set_baudrate(minor,new_options);			
			break;
		case SET_STOP:
			set_stop(minor,new_options);
			break;
		case SET_CHECK:
			rs = set_check(minor,new_options);
            break;
        case SET_LED:
            rs = set_led(minor,new_options);
            break;
        case GET_FUN:
            rs = get_fun(minor,&new_options);
            if(put_user(new_options, p) != 0) {
                rs = RTN_ERR;
            }
            break;
        default:
            break;
	}
	
	return(rs);
}

static unsigned int serial_fpga_poll(struct file *file, struct poll_table_struct *wait)
{
	return(RTN_OK);
}

static const struct file_operations serial_fpga_fops=
{
	.owner 			= THIS_MODULE,
	.read  			= serial_fpga_read,
	.write 			= serial_fpga_write,
	.unlocked_ioctl = serial_fpga_ioctl,
	.open  			= serial_fpga_open,
	.poll  			= serial_fpga_poll,
	.release		= serial_fpga_release,
};

static int gp_module_map(uint32 phyaddr, uint32 size, uint32 *vaddr, const char *name)
{
/*
	if (!request_mem_region(phyaddr, size, name)) {
		pr_err("%s(%d) %s request_mem_region fail.\n", __FUNCTION__, __LINE__, name);
			return -EBUSY;
	}
*/
	*vaddr = (uint32)ioremap(phyaddr, size);
	if (!*vaddr) {
		pr_err("%s(%d)phyaddr() failed\n", __FUNCTION__, __LINE__);
		release_mem_region(phyaddr, size);
		return -EFAULT;
	}

/*	
	pr_info("%s(%d): %s addr:0x%08x ioremap to: 0x%08x(0x%08x)\n",
		__FUNCTION__, __LINE__, name, phyaddr,
			*vaddr, size);
*/
	return(RTN_OK);
}

static void gp_module_unmap(uint32 phyaddr, uint32 size, uint32 vaddr, const char *name)
{
	iounmap((void *)vaddr);
/*	release_mem_region(phyaddr, size);	*/
/*
	pr_info("%s(%d): %s gp physical addr 0x%08x: unmap.\n",
		__FUNCTION__, __LINE__, name, phyaddr);
*/
}

int __init serial_fpga_drv_init(void)
{
	dev_t dev_id;
	int32 rs = 0;
	uint32 vaddr = 0;
	uint32 i = 0;
	uint32 fpga_nr = 0;
	
	printk("%s Compile Time:%s %s\n",SERIAL_FPGA_DEV_NAME,__DATE__,__TIME__);
    printk("GIT_COMMIT_ID:%s (%s)\n",GIT_COMMIT_ID_STR, VER_INFO);

	gp_module_map(GP_BASE_ADDR,0x1000,&vaddr,SERIAL_FPGA_DEV_NAME);
	if(rs != RTN_OK) {
		printk("Remap global address error.\n");
		return (RTN_ERR);
	}
	
	if(serial_fpga_nr == 0) {
		/*Get serial count from fpga*/
		fpga_nr = REG_RD(vaddr+GP_SERIAL_NUM_OFFSET);
        if(fpga_nr > SERIAL_FPGA_DEV_MAX || fpga_nr == 0) {
            printk("Invalid fpga serial num %d, Invalid insmod serial num %d\n", fpga_nr, serial_fpga_nr);
			gp_module_unmap(GP_BASE_ADDR,0x1000,vaddr,SERIAL_FPGA_DEV_NAME);
			return (RTN_ERR);
		} else {
			serial_fpga_nr = fpga_nr;
		}
	}
    else if(serial_fpga_nr > SERIAL_FPGA_DEV_MAX) {
        /*Correct serial count from insmod*/
        printk("Invalid insmod serial num %d, correct to %d\n", serial_fpga_nr, SERIAL_FPGA_DEV_MAX);
        serial_fpga_nr = SERIAL_FPGA_DEV_MAX;
    }
    
    rs = alloc_chrdev_region(&dev_id, 0, serial_fpga_nr, SERIAL_FPGA_DEV_NAME);
	if(rs < 0) {
		printk("FPGA serial register fail.\n");
		return (RTN_ERR);
	}

	serial_fpga_major = MAJOR(dev_id);
	
	cdev_init(&(serial_fpga_dev.cdev),&serial_fpga_fops);
	serial_fpga_dev.cdev.owner = THIS_MODULE;
	serial_fpga_dev.cdev.ops = &serial_fpga_fops;
	rs = cdev_add(&(serial_fpga_dev.cdev),dev_id,serial_fpga_nr);
	if(rs != 0) {
		printk("cdev_add error!\n");
		goto unreg_dev;
	}
	
	serial_fpga_dev.dev_class = class_create(THIS_MODULE, SERIAL_FPGA_DEV_NAME);
	if(IS_ERR(serial_fpga_dev.dev_class) != 0) {
		printk(KERN_ALERT"Failed to create device class.\n");
		goto del_dev;
	}
	
	for(i=0;i<serial_fpga_nr;i++) {
		/*create device node*/
		serial_fpga_dev.dev_attr[i].p_dev = device_create(serial_fpga_dev.dev_class, NULL, MKDEV(serial_fpga_major,i), NULL, SERIAL_FPGA_DEV_NAME"_%d", i);
		if(IS_ERR(serial_fpga_dev.dev_attr[i].p_dev) != 0) {
			printk(KERN_ALERT"Failed to create device.\n");
			goto destroy_class;
		}
		
        serial_fpga_dev.dev_attr[i].led_status = LED_STATUS_ENABLE;
        if(i == 11) {       // only serial-12 has function reg.
            serial_fpga_dev.dev_attr[i].fun_offset = 0x10C;
        }
        sema_init(&serial_fpga_dev.dev_attr[i].semWr, 1);
        sema_init(&serial_fpga_dev.dev_attr[i].semRd, 1);

		rs = kfifo_alloc(&serial_fpga_dev.dev_attr[i].recv_fifo, SERIAL_FPGA_BUF_SIZE, GFP_KERNEL);
		if (rs) {
			printk("Could not alloate the dev_%d RECV FIFO\n", i);
		}
		
		rs = kfifo_alloc(&serial_fpga_dev.dev_attr[i].send_fifo, SERIAL_FPGA_BUF_SIZE, GFP_KERNEL);
		if (rs) {
			printk("Could not alloate the dev_%d SEND FIFO\n", i);
		}			
	}
	
	rs = serial_sysfs_create(serial_fpga_dev.dev_class,SERIAL_FPGA_DEV_NAME);
	if(rs != RTN_OK) {
		printk("WARNING:create sysfs fail!\n");
	}
	
	if(0x5A5A5A5A == REG_RD(vaddr+GP_SERIAL_FLAG_OFFSET)) {
		for(i=0;i<serial_fpga_nr;i++) {
			serial_fpga_dev.dev_attr[i].phy_addr = SERIAL_BASE_ADDR((GP_BASE_ADDR+0xF40000),i);
			gp_module_map(serial_fpga_dev.dev_attr[i].phy_addr,0x100,&(serial_fpga_dev.dev_attr[i].remap_addr),SERIAL_FPGA_DEV_NAME);			
		}
	} else {
		for(i=0;i<serial_fpga_nr;i++) {
			serial_fpga_dev.dev_attr[i].phy_addr = SERIAL_BASE_ADDR((GP_BASE_ADDR+0x341000),i);
			gp_module_map(serial_fpga_dev.dev_attr[i].phy_addr,0x100,&(serial_fpga_dev.dev_attr[i].remap_addr),SERIAL_FPGA_DEV_NAME);		
		}
	}
	gp_module_unmap(GP_BASE_ADDR,0x1000,vaddr,SERIAL_FPGA_DEV_NAME);
		
	kt = ktime_set(0, POLLING_FREQ);
	hrtimer_init(&serial_fpga_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	serial_fpga_timer.function = serial_fpga_hrtimer_func;
	hrtimer_start(&serial_fpga_timer, kt, HRTIMER_MODE_REL);
	
	printk("Serial dev count:%d(%s) init finish Poll freq:%d HZ!\n",
			serial_fpga_nr,
            (fpga_nr==0)?"from insmod":"from fpga",
			1000000000/POLLING_FREQ);
	
	return (rs);
	
destroy_class:
	class_destroy(serial_fpga_dev.dev_class);
del_dev:
	cdev_del(&serial_fpga_dev.cdev);
unreg_dev:
	unregister_chrdev_region(dev_id,serial_fpga_nr);

	return(RTN_ERR);
}

void __exit serial_fpga_drv_exit(void)
{	
	dev_t dev_id = MKDEV(serial_fpga_major, 0);
	int32 i = 0;
	
	hrtimer_cancel(&serial_fpga_timer);
	serial_sysfs_release(serial_fpga_dev.dev_class);
	
	for(i=0;i<serial_fpga_nr;i++) {
			gp_module_unmap(serial_fpga_dev.dev_attr[i].phy_addr,0x100,serial_fpga_dev.dev_attr[i].remap_addr,SERIAL_FPGA_DEV_NAME);
			device_destroy(serial_fpga_dev.dev_class, MKDEV(serial_fpga_major, i));
			
			kfifo_free(&serial_fpga_dev.dev_attr[i].recv_fifo);
			kfifo_free(&serial_fpga_dev.dev_attr[i].send_fifo);
	}
	
	class_destroy(serial_fpga_dev.dev_class);
	cdev_del(&serial_fpga_dev.cdev);
	unregister_chrdev_region(dev_id,serial_fpga_nr);
	return;
}

MODULE_AUTHOR("CuiJinjin@sf-auto.com");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION("ZYNQ 7010 FPGA SERIAL DRIVER: "GIT_COMMIT_ID_STR);

module_init(serial_fpga_drv_init);
module_exit(serial_fpga_drv_exit);

#endif /*_SERIAL_FPGA_MAIN_C_*/
