#ifndef _SERIAL_FPGA_SYSFS_C_
#define _SERIAL_FPGA_SYSFS_C_

/*
 * Implement FPGA SERIAL information use sysfs.
 * Copyright (C) 2017 sf-auto Ltd. 
 *
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>

#include "basetype.h"
#include "basedefine.h"
#include "serial_fpga_sysfs.h"

extern int do_serial_info_show(char* buf);

static ssize_t serial_info_show(struct class *class, struct class_attribute *attr, char *buf)
{
	int len 	= 0;
	
	len = do_serial_info_show(buf);
	return(len);
}

static ssize_t serial_info_store(struct class *class, struct class_attribute *attr, const char *buf, size_t count)
{
	return ~0;
}

static struct class_attribute dev_attr_serial_info = {
	.attr = {
		.name = NULL,
		.mode = S_IWUSR | S_IRUGO,
	},
	.show = serial_info_show,
	.store = serial_info_store,
};

int serial_sysfs_create(struct class *dev_class,const char *dev_name)
{
	int rs = RTN_ERR;
	
	dev_attr_serial_info.attr.name = dev_name;
	rs = class_create_file(dev_class, &dev_attr_serial_info);
	if(rs < 0) {
		printk(KERN_ALERT"Failed to create attribute info device.\n");
		return(RTN_ERR);
	}
	
	return(RTN_OK);	
}

int serial_sysfs_release(struct class *dev_class)
{
	class_remove_file(dev_class, &dev_attr_serial_info);
	return(RTN_OK);
}


#endif /*_SERIAL_FPGA_SYSFS_C_*/