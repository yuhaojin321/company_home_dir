#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <pthread.h>
#include <signal.h>
#include <sched.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <linux/unistd.h>
#include <assert.h>

#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <sys/mman.h>
#include "sf_serial.h"


#define APP_NAME        "sf_serial_demo"
#define APP_VER         "V0.42"

#define BUF_SIZE        (256)
#define SERIAL_NUM_MAX  (32)
#define BAUD_DEFAULT    (115200)

#define AT_CN1          (0x1)
#define AT_CN2          (0x2)

#define AT_CNSEL_1      (AT_CN1)
#define AT_CNSEL_2      (AT_CN2)
#define AT_CNSEL_ALL    (AT_CN1 | AT_CN2)

typedef struct _at_cfg {
    int nSend;
    int nRcn1;
    int nRcn2;
} AT_CFG;

typedef struct _at_res {
    int nSendCn1OK;
    int nRecvCn1OK;
    int nSendCn2OK;
    int nRecvCn2OK;
} AT_RES;

#define AUTO_GROUP     (6)

// Auto-test support 2 connect method config:
// Connect1: 1 - 3  Connect2: 1 - 2
//           2 - 5            3 - 4
//           4 - 6            5 - 6
// Auto-test step:
// send recv-Cn1  recv-Cn2
// 1    3           2
// 2    5           1
// 3    1           4
// 4    6           3
// 5    2           6
// 6    4           5
const AT_CFG gatCfg[AUTO_GROUP] = {
    { 1, 3, 2 },
    { 2, 5, 1 },
    { 3, 1, 4 },
    { 4, 6, 3 },
    { 5, 2, 6 },
    { 6, 4, 5 },
};

// Auto-test result
char gstrCn1Name[16] = "CN1";
char gstrCn2Name[16] = "CN2";
AT_RES gatRes[SERIAL_NUM_MAX] = { 0 };

#define LOG_REPORT 0x01
#define LOG_SCREEN 0x02

int dump_mem(unsigned int *buf, int length)
{
	int i = 0;
	int buf_addr = (int)buf;

	printf("\ndump the mem, length: %d:\n<0x%08x>: ", length,buf_addr);
	for(i = 0; i < length; i ++) {
		if(i != 0)
			if(!(i%8)){
				buf_addr = buf_addr+0x20;
				printf("\n<0x%08x>: ",buf_addr);
			}
		printf("0x%08x ", buf[i]);
	}
	printf("\n");

	return 0;
}

int getline_stdin(char *buf, int len)
{
    int ret, cnt = 0;
    int flags, flags_bak;

    if(flags_bak = fcntl(STDIN_FILENO, F_GETFL, 0) < 0) {
        perror("fcntl F_GETFL");
        return (-1);
    }
    flags = flags_bak | O_NONBLOCK;
    if(fcntl(STDIN_FILENO, F_SETFL, flags) < 0) {
        perror("fcntl F_SETFL");
        return (-1);
    }

    do {
        ret = read(STDIN_FILENO, buf, 1);
        if(ret) {
            if('\0' == *buf || '\n' == *buf) {
                cnt ++;
                break;
            }
            else {
                buf++;
                cnt ++;
            }
        }
    } while(ret && cnt <= len);

    if(fcntl(STDIN_FILENO, F_SETFL, flags_bak) < 0) {
        perror("fcntl F_SETFL");
        return (-1);
    }

    return cnt;
}

static int times = 1;
static int bitrate = BAUD_DEFAULT;
static int check = 0;
static int report = 0;
static int sernum = 0;

static int test_all_serial(void)
{
	int rs = 0;
	int serial_no = 0;
	int i = 0;
	char buf[BUF_SIZE] = {0};
    int fd[SERIAL_NUM_MAX] = {0};
    int time = 0, sendms = 0;
    int exitloop = 0;
	
    sernum = sf_serial_dnum();
    if(0 > sernum) {
        sernum = SERIAL_NUM_MAX;
    }
    else if(0 == sernum) {
        printf("There is no serial.\n");
        return -1;
    }
    else {
        printf("There are %d serials all.\n", sernum);
    }
    
    for(serial_no=0;serial_no<sernum;serial_no++) {
		/*open serial*/
		fd[serial_no] = sf_serial_open(serial_no,bitrate);
		if(fd[serial_no] < 0) {
            sernum = serial_no;
            printf("There are %d serials realy.\n", sernum);
            break;
		}
	}

    if(0 == sernum) {
        printf("do nothing and exit.\n");
        return 0;
    }

    /*times <= 0: test forever*/ 
    times = (0 > times) ? 0 : times;
    sendms = BUF_SIZE * 15 * 1000 / bitrate;
    sendms = (10 > sendms) ? 10 : sendms;
LOOP_FLAG:
    /*clear screen*/ 
    printf("\033[2J");                  
    printf("\033[H");                   
    printf("#################### All-test %2d/%2d #####################\n", time+1, times);
	
    for(serial_no=0;serial_no<sernum;serial_no++) {
		/*send data*/
		for(i=0;i<BUF_SIZE;i++)
			buf[i] = serial_no;
		
		buf[0] = serial_no;
	
		rs = sf_serial_write(fd[serial_no],buf,BUF_SIZE);
        printf("serial %-2d send: %d bytes ...\n", serial_no, rs);

        /*sleep wait for send finish */
        usleep(sendms * 1000);
    }
	
    for(serial_no=0;serial_no<sernum;serial_no++) {
        /*read data all*/
        do {
            memset(buf, 0, BUF_SIZE);
            rs = sf_serial_read(fd[serial_no],buf,BUF_SIZE);
            if(rs != 0) {
                for(i=1;i<rs;i++) {
                    if(buf[i] != buf[0])
                        break;
                }
                if(i != rs) {
                    printf("serial %-2d recv : %d bytes from serial %-2d ERR:\n",serial_no,rs,buf[0]);
                    dump_mem((int *)buf,rs>>2);
                }
                else {
                    printf("serial %-2d recv : %d bytes from serial %-2d OK.\n",serial_no,rs,buf[0]);
                }
            }
        } while (rs);
	}
	
    /*test loop*/ 
    time++;

    /*q for quit loop*/ 
    if(0 < getline_stdin(buf, BUF_SIZE)) {
        if('q' == buf[0]) {
            exitloop = 1;
        }
    }
    
    if(0 == exitloop && (0 == times || times > time))
        goto LOOP_FLAG;
	
    for(serial_no=0;serial_no<sernum;serial_no++) {
		/**close serial*/
		sf_serial_close(fd[serial_no]);
	}
	
	return(rs);
}

static int test_auto_serial(int cnsel, int sertest)
{
    int rs = 0;
    int serial_no = 0;
    int sersel = 0, fdsel = 0;
    int i = 0, len = 0;
    char sbuf[BUF_SIZE] = {0};
    char rbuf[BUF_SIZE] = {0};
    int fd[SERIAL_NUM_MAX] = {0};
    int time = 0, sendms = 0;
    int rCn1 = 0, rCn2 = 0;
    AT_CFG atcur;
    int exitloop = 0;
    
    if(0 == cnsel) {
        printf("do nothing and exit.\n");
        return 0;
    }
    
    sernum = sf_serial_dnum();
    if(0 > sernum) {
        sernum = SERIAL_NUM_MAX;
    }
    else if(0 == sernum) {
        printf("There is no serial.\n");
        return -1;
    }
    else {
        printf("There are %d serials all.\n", sernum);
    }

    if(0 < sertest && sernum > sertest) {
        sernum = sertest;
        printf("Auto test %d serials here.\n", sernum);
    }

    for(serial_no=0;serial_no<sernum;serial_no++) {
        /*open serial*/
        fd[serial_no] = sf_serial_open(serial_no,bitrate);
        if(fd[serial_no] < 0) {
            sernum = serial_no;
            printf("There are %d serials realy.\n", sernum);
            break;
        }

        if(check) {
            rs = sf_serial_ioctl(fd[serial_no], SET_CHECK, &check);
            if(rs != 0) {
                printf("Set check:%d error!\n", check);
            }
            else {
                printf("Set check:%d success!\n", check);
            }
        }
    }

    if(0 == sernum) {
        printf("do nothing and exit.\n");
        return 0;
    }

    /*times <= 0: test forever*/ 
    times = (0 > times) ? 0 : times;
LOOP_FLAG:
    /*clear screen*/ 
    if(report & LOG_SCREEN) {
        printf("\033[2J");
        printf("\033[H"); 
    }
    if(times) {
        printf("#################### Auto-test %2d/%2d ####################\n", time + 1, times);
    }
    else {
        printf("################# Auto-test %2d (wait q) #################\n", time + 1);
    }
    
    for(serial_no=0;serial_no<sernum;serial_no++) {
        /*cal auto-config for this serial*/
        atcur.nSend = ((serial_no / AUTO_GROUP) * AUTO_GROUP) + gatCfg[serial_no % AUTO_GROUP].nSend;
        atcur.nRcn1 = ((serial_no / AUTO_GROUP) * AUTO_GROUP) + gatCfg[serial_no % AUTO_GROUP].nRcn1;
        atcur.nRcn2 = ((serial_no / AUTO_GROUP) * AUTO_GROUP) + gatCfg[serial_no % AUTO_GROUP].nRcn2;

        /*clear serial recived and res*/ 
        if(cnsel & AT_CN1) {
            rCn1 = 0;
            sersel = atcur.nRcn1;
            fdsel = fd[sersel-1];
            rs = (0 == fdsel) ? 0 : sf_serial_read(fdsel,rbuf,BUF_SIZE);
        }
        if(cnsel & AT_CN2) {
            rCn2 = 0;
            sersel = atcur.nRcn2;
            fdsel = fd[sersel-1];
            rs = (0 == fdsel) ? 0 : sf_serial_read(fdsel,rbuf,BUF_SIZE);
        }

        /*send data*/
        sersel = atcur.nSend;
        fdsel = fd[sersel-1];
        sprintf(sbuf, "Data %d from serial-%d.", time, sersel);
        len = strlen(sbuf);
        
        printf("> s-%-2d Tx", sersel);
        if(report & LOG_REPORT) {
            printf(": %s", sbuf);
        }
        rs = sf_serial_write(fdsel, sbuf, len);
        if(report  & LOG_REPORT) {
            printf(" [%d] -done\n",rs);
        }
        else {
            printf("\t");
        }
        fflush(stdout);

        /*sleep wait for send finish */
        sendms = len * 15 * 1000 / bitrate;
        sendms = (10 > sendms) ? 10 : sendms;
        usleep(sendms * 1000);

        /*read data from Cn1*/ 
        if(cnsel & AT_CN1) {
            sersel = atcur.nRcn1;
            fdsel = fd[sersel-1];
            printf(" <s-%-2d Rx", sersel);
            memset(rbuf,0,BUF_SIZE);
            rs = (0 == fdsel) ? 0 : sf_serial_read(fdsel,rbuf,BUF_SIZE);
            if(0 < rs) {
                rbuf[rs] = '\0';
                if(rs == len && 0 == strcmp(sbuf,rbuf)) {
                    rCn1 = 1;
                }
                
                if(report & LOG_REPORT) {
                    printf(": %s [%d] ", rbuf, rs);
                }
                printf("-%s %s", gstrCn1Name, (rCn1) ? "OK" : "ERR");
                
            }
            else {
                if(report & LOG_REPORT) {
                    printf(": %s NONE", gstrCn1Name);
                }
                else {
                    printf("-%s NONE", gstrCn1Name);
                }
            }
            if(report & LOG_REPORT) {
                printf("\n");
            }
            else {
                if(cnsel & AT_CN2) {
                    printf("\t");
                }
                else {
                    printf("\n");
                }
            }
            fflush(stdout);

            /*Auto-test result for this step*/ 
            if(rCn1) {
                gatRes[atcur.nSend - 1].nSendCn1OK ++;
                gatRes[atcur.nRcn1 - 1].nRecvCn1OK ++;
            }
        }
        
        /*read data from Cn2*/ 
        if(cnsel & AT_CN2) {
            sersel = atcur.nRcn2;
            fdsel = fd[sersel-1];
            printf(" <s-%-2d Rx", sersel);
            memset(rbuf,0,BUF_SIZE);
            rs = (0 == fdsel) ? 0 : sf_serial_read(fdsel,rbuf,BUF_SIZE);
            if(0 < rs) {
                rbuf[rs] = '\0';
                if(rs == len && 0 == strcmp(sbuf,rbuf)) {
                    rCn2 = 1;
                }
                
                if(report & LOG_REPORT) {
                    printf(": %s [%d] ", rbuf, rs);
                }
                printf("-%s %s", gstrCn2Name, (rCn2) ? "OK" : "ERR");
                
            }
            else {
                if(report & LOG_REPORT) {
                    printf(": %s NONE", gstrCn2Name);
                }
                else {
                    printf("-%s NONE", gstrCn2Name);
                }
            }
            printf("\n");

            /*Auto-test result for this step*/ 
            if(rCn2) {
                gatRes[atcur.nSend - 1].nSendCn2OK ++;
                gatRes[atcur.nRcn2 - 1].nRecvCn2OK ++;
            }
        }
    }
    
    /*test loop*/ 
    time++;

    /*q for quit loop*/ 
    if(0 < getline_stdin(sbuf, BUF_SIZE)) {
        if('q' == sbuf[0]) {
            exitloop = 1;
        }
    }

    if(0 == exitloop && (0 == times || times > time))
        goto LOOP_FLAG;
    
    for(serial_no=0;serial_no<sernum;serial_no++) {
        /*close serial*/
        sf_serial_close(fd[serial_no]);
    }

    /*print auto-test report*/
    times = time;
    /*clear screen*/ 
    if(report & LOG_SCREEN) {
        printf("\033[2J");
        printf("\033[H"); 
    }
    printf("------------------- Auto-test report --------------------\n");
    if(cnsel == AT_CNSEL_1) {
        printf("NUM\tT%s\tR%s\tTIME\tRES\n", gstrCn1Name, gstrCn1Name);
        for(serial_no = 0; serial_no < sernum; serial_no++) {
            printf("%d\t%d\t%d\t%d\t",
                   serial_no + 1,
                   gatRes[serial_no].nSendCn1OK,
                   gatRes[serial_no].nRecvCn1OK,
                   times);
            if(times == gatRes[serial_no].nSendCn1OK &&
               times == gatRes[serial_no].nRecvCn1OK) {
                printf("OK\n");
            }
            else {
                printf("ERR\n");
            }
        }
    }
    else if(cnsel == AT_CNSEL_2) {
        printf("NUM\tT%s\tR%s\tTIME\tRES\n", gstrCn2Name, gstrCn2Name);
        for(serial_no = 0; serial_no < sernum; serial_no++) {
            printf("%d\t%d\t%d\t%d\t",
                   serial_no + 1,
                   gatRes[serial_no].nSendCn2OK,
                   gatRes[serial_no].nRecvCn2OK,
                   times);
            if(times == gatRes[serial_no].nSendCn2OK &&
               times == gatRes[serial_no].nRecvCn2OK) {
                printf("OK\n");
            }
            else {
                printf("ERR\n");
            }
        }
    }
    else if(cnsel == AT_CNSEL_ALL) {
        printf("NUM\tT%s\tR%s\tT%s\tR%s\tTIME\tRES\n",
               gstrCn1Name, gstrCn1Name, gstrCn2Name, gstrCn2Name);
        for(serial_no=0;serial_no<sernum;serial_no++) {
            printf("%d\t%d\t%d\t%d\t%d\t%d\t",
                   serial_no + 1, 
                   gatRes[serial_no].nSendCn1OK,
                   gatRes[serial_no].nRecvCn1OK,
                   gatRes[serial_no].nSendCn2OK,
                   gatRes[serial_no].nRecvCn2OK,
                   times);
            if(times == gatRes[serial_no].nSendCn1OK &&
               times == gatRes[serial_no].nRecvCn1OK &&
               times == gatRes[serial_no].nSendCn2OK &&
               times == gatRes[serial_no].nRecvCn2OK) {
                printf("OK\n");
            }
            else
            {
                printf("ERR\n");
            }
        }
    }
    printf("---------------------------------------------------------\n");
    
    return(rs);
}

void main(int argc, char *argv[])
{
	int rs = 0;
    int fd = 0;
	int unit = 0;
    int i = 0, strflag = 0, led, fun;
    char *strSend = NULL;
	char buf[BUF_SIZE] = {0};
		
    if(argc < 2) {
        printf("%s %s\n", APP_NAME, APP_VER);
        printf("usage:\n");
        printf("  ./%s #unit w/r/wr/e #times #bitrate #check\n", APP_NAME);
        printf("  ./%s #unit sw/sr/swr/se string #time #bitrate #check\n", APP_NAME);
        printf("  ./%s #unit led #val #time\n", APP_NAME);
        printf("  ./%s #unit fun #val\n", APP_NAME);
        printf("  ./%s all #times #bitrate\n", APP_NAME);
        printf("  ./%s auto #times #bitrate #report #check\n", APP_NAME);
        printf("  ./%s acn# #times #bitrate #report #check\n", APP_NAME);
        printf("  ./%s unm\n", APP_NAME);
        printf("  ./%s ver\n", APP_NAME);
		return;
	}
		
    if(memcmp(argv[1],"all",3) == 0) {
        if(argc > 2) {
            times = atoi(argv[2]);
        }
        if(argc > 3) {
            bitrate =  atoi(argv[3]);
        }
		rs = test_all_serial();
		return;
	}
    else if(memcmp(argv[1],"auto",4) == 0) {
        if(argc > 2) {
            times = atoi(argv[2]);
        }
        if(argc > 3) {
            bitrate =  atoi(argv[3]);
        }
        if(argc > 4) {
            report =  atoi(argv[4]);
        }
        if(argc > 5) {
            check =  atoi(argv[5]);
        }
        unit = sf_serial_dnum();
        /*for 015.205: auto test 6 of 6 RS485+RS232*/ 
        if(6 == unit) {
            strcpy(gstrCn1Name, "485");
            strcpy(gstrCn2Name, "232");
            rs = test_auto_serial(AT_CNSEL_ALL, 0);
        }
        /*for 004.560: auto test 10 of 12 RS485*/ 
        else if(12 == unit) {
            strcpy(gstrCn2Name, "485");
            rs = test_auto_serial(AT_CNSEL_2, 10);
        }
        return;
    }
    else if(memcmp(argv[1],"acn",3) == 0) {
        if(strlen(argv[1]) > 3) {
            unit = atoi(argv[1] + 3);
        }
        else {
            unit = AT_CNSEL_ALL;
        }
        if(argc > 2) {
            times = atoi(argv[2]);
        }
        if(argc > 3) {
            bitrate =  atoi(argv[3]);
        }
        if(argc > 4) {
            report =  atoi(argv[4]);
        }
        if(argc > 5) {
            check =  atoi(argv[5]);
        }
        rs = test_auto_serial(unit, 0);
        return;
    }
    if(memcmp(argv[1],"num",3) == 0) {
        unit = sf_serial_dnum();
        if(0 > unit) {
            printf("serial dev num: unknown.\n");
        }
        else {
            printf("serial dev num: %d.\n", unit);
        }
        return;
    }
    else if(memcmp(argv[1],"ver",3) == 0) {
        printf("demo app ver: %s\n", APP_VER);
        sf_serial_verstr(buf);
        printf("serial lib ver: %s\n", buf);
        if(0 > sf_serial_dverstr(buf)) {
            printf("serial drv ver: unknown\n");
        }
        else {
            printf("serial drv ver: %s\n", buf);
        }
        return;
    }

    if(memcmp(argv[2],"led",3) == 0) {
        if(argc >= 4) {
            unit = atoi(argv[1]);
            led = atoi(argv[3]);

            if(argc >= 5)
                times = atoi(argv[4]);
            else
                times = 1; 

            fd = sf_serial_open(unit, BAUD_DEFAULT);
            if(fd < 0) {
                printf("Open serial_%d error!\n", unit);
                return;
            }

            while(0 > times || times--) {
                rs = sf_serial_ioctl(fd, SET_LED, &led);
                if(rs != 0) {
                    printf("Set led: %d error!\n", led);
                }
                else {
                    printf("Set led: %d success!\n", led);
                }
                if(times)
                    sleep(1);
            }
            sf_serial_close(fd);
            
        }
        else {
            printf("Please input val for led!\n", led);
        }
        return;
    }
    else if(memcmp(argv[2],"fun",3) == 0) {
        if(argc >= 4) {
            unit = atoi(argv[1]);
            fun = atoi(argv[3]);

            fd = sf_serial_open(unit, BAUD_DEFAULT);
            if(fd < 0) {
                printf("Open serial_%d error!\n", unit);
                return;
            }

            rs = sf_serial_ioctl(fd, SET_FUN, &fun);
            if(rs != 0) {
                printf("Set fun: %d error!\n", fun);
            }
            else {
                printf("Set fun: %d success!\n", fun);
            }
            sf_serial_close(fd);
        }
        else {
            printf("Please input val for fun!\n", led);
        }
        return;
    }
    else if(memcmp(argv[2],"s",1) == 0) {
        strflag = 1;
        if(argc >= 4 && 0 != strcmp(argv[3], ".")) {
            strSend = argv[3];
        }
    }
    
    if(argc >= (4 + strflag))
        times = atoi(argv[3 + strflag]);
	else
		times = 10;
	
    if(argc >= (5 + strflag))
        bitrate =  atoi(argv[4 + strflag]);
	else
        bitrate = BAUD_DEFAULT;
	
    if(argc >= (6 + strflag))
        check =  atoi(argv[5 + strflag]);
	else
		check = 0;
	
	unit = atoi(argv[1]);
	
    fd = sf_serial_open(unit,BAUD_DEFAULT);
	if(fd < 0) {
        printf("Open serial_%d error!\n",unit);
        return;
	}
	
	rs = sf_serial_ioctl(fd,SET_BAUDRATE,&bitrate);
	if(rs != 0) {
		printf("Set bitrate:%d error!\n",bitrate);
	}else {
		printf("Set bitrate:%d success!\n",bitrate);
	}
	
	rs = sf_serial_ioctl(fd,SET_CHECK,&check);
	if(rs != 0) {
		printf("Set check:%d error!\n",check);
	}else {
		printf("Set check:%d success!\n",check);
	}
	
	printf("dev_%d %s function %d times!\n",unit,argv[2],times);
	
    while(0 > times || times--) {
        if(memcmp(argv[2] + strflag,"rw",2) == 0 ||
           memcmp(argv[2] + strflag,"wr",2) == 0) {
            if(strSend) {
                strncpy(buf, strSend, BUF_SIZE);
                rs = sf_serial_write(fd,buf,strlen(buf));
                if(0 < rs) {
                    printf("%d-W [%d]: %s\n", unit, rs, strSend);
                }
                else {
                    printf("%d-W [%d]: time-%d.\n", unit, rs, times);
                }
            }
            else {
                for(i=0;i<BUF_SIZE;i++)
                    buf[i] = times + i;
                rs = sf_serial_write(fd,buf,BUF_SIZE);
                if(0 < rs) {
                    printf("%d-W [%d]: 0x%02X 0x%02X ... 0x%02X\n", 
                           unit, rs, buf[0], buf[1], buf[rs - 1]);
                }
                else {
                    printf("%d-W [%d]: time-%d.\n", unit, rs, times);
                }
            }
            sleep(1);
            rs = sf_serial_read(fd,buf,BUF_SIZE);   
            if(0 < rs) {
                if(strflag) {
                    buf[rs] = '\0';
                    printf("%d-R [%d]: %s\n", unit, rs, buf);
                }
                else {
                    printf("%d-R [%d]: 0x%02X 0x%02X ... 0x%02X\n",
                           unit, rs, buf[0], buf[1], buf[rs - 1]);
                }
            }
            else {
                if(0 <= times) {
                    printf("%d-R [%d]: time-%d.\n", unit, rs, times);
                }
            }
        }
        else if(memcmp(argv[2] + strflag,"e",1) == 0) {
            if(strSend) {
                rs = sf_serial_write(fd,strSend,strlen(strSend));
                if(0 < rs) {
                    printf("%d-W [%d]: %s\n", unit, rs, strSend);
                }
            }
            sleep(1);
            rs = sf_serial_read(fd,buf,BUF_SIZE);   
            if(0 < rs) {
                rs = sf_serial_write(fd,buf,rs);
                if(0 < rs) {
                    if(strflag) {
                        buf[rs] = '\0';
                        printf("%d-E [%d]: %s\n", unit, rs, buf);
                    }
                    else {
                        printf("%d-E [%d]: 0x%02X 0x%02X ... 0x%02X\n",
                               unit, rs, buf[0], buf[1], buf[rs - 1]);
                    }
                }
            }
        }
        else if(memcmp(argv[2] + strflag,"r",1) == 0) {
            sleep(1);
            rs = sf_serial_read(fd,buf,BUF_SIZE);   
            if(0 < rs) {
                if(strflag) {
                    buf[rs] = '\0';
                    printf("%d-R [%d]: %s\n", unit, rs, buf);
                }
                else {
                    printf("%d-R [%d]: 0x%02X 0x%02X ... 0x%02X\n",
                           unit, rs, buf[0], buf[1], buf[rs - 1]);
                }
            }
            else {
                if(0 <= times) {
                    printf("%d-R [%d]: time-%d.\n", unit, rs, times);
                }
            }
		}
        else if(memcmp(argv[2] + strflag,"w",1) == 0) {
            if(strSend) {
                strncpy(buf, strSend, BUF_SIZE);
                rs = sf_serial_write(fd,buf,strlen(buf));
                if(0 < rs) {
                printf("%d-W [%d]: %s\n", unit, rs, strSend);
                }
                else {
                    printf("%d-W [%d]: time-%d.\n", unit, rs, times);
                }
            }
            else {
                for(i=0;i<BUF_SIZE;i++)
                    buf[i] = times + i;
                rs = sf_serial_write(fd,buf,BUF_SIZE);
                if(0 < rs) {
                    printf("%d-W [%d]: 0x%02X 0x%02X ... 0x%02X\n", 
                           unit, rs, buf[0], buf[1], buf[rs - 1]);
                }
                else {
                    printf("%d-W [%d]: time-%d.\n", unit, rs, times);
                }
            }
            if(times)
                sleep(1);
        }
        else {
            printf("%s function is invalid!\n",argv[2]);
            break;
        }
	}
	sf_serial_close(fd);
	
	return;
}