#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/kernel.h>       /* printk() */
#include <linux/fs.h>           /* everything... */
#include <linux/errno.h>        /* error codes */
#include <linux/cdev.h>
#include <linux/interrupt.h>
#include <asm/system.h>         /* cli(), *_flags */
#include <asm/uaccess.h>        /* copy_*_user */
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/device.h>
#include <asm/io.h>
#include <asm/atomic.h>
#include <linux/rtc.h>
#include <linux/hrtimer.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/types.h>  
#include <linux/mm.h>  
#include <linux/slab.h>  
#include <linux/vmalloc.h>  

#ifdef FPGA_CAN_MODE_SMP
#define FPGACAN_USE_SPINLOCK
#else
#undef FPGACAN_USE_SPINLOCK
#endif

#ifdef FPGACAN_USE_SPINLOCK
spinlock_t packet_skb_lock;
#endif

#define FPGA_CAN_NR 3
#define FPGA_CAN_MAXBUF 64
#define FPGA_CAN_DEVICE_NAME 	"fpgacan"		

#define XCAN_TIMEOUT 3
#define	CAN_CTRLMODE_LOOPBACK 0xff 

#define	SET_SPEED		0x11
#define	SET_LOOPBACK	0x22
#define	SET_START		0x33
#define	SET_FILTER		0x44
#define GET_STATUS		0x55
#define RESET_DEV		0x66

#define SPEED_1M   1000000
#define SPEED_200K 200000

/* CAN registers set */
#define XCAN_SRR_OFFSET                 0x00 /* Software reset */
#define XCAN_MSR_OFFSET                 0x04 /* Mode select */
#define XCAN_BRPR_OFFSET                0x08 /* Baud rate prescaler */
#define XCAN_BTR_OFFSET                 0x0C /* Bit timing */
#define XCAN_ECR_OFFSET                 0x10 /* Error counter */
#define XCAN_ESR_OFFSET                 0x14 /* Error status */
#define XCAN_SR_OFFSET                  0x18 /* Status */
#define XCAN_ISR_OFFSET                 0x1C /* Interrupt status */
#define XCAN_IER_OFFSET                 0x20 /* Interrupt enable */
#define XCAN_ICR_OFFSET                 0x24 /* Interrupt clear */
#define XCAN_WIR_OFFSET                 0x2C /* Interrupt clear */
#define XCAN_TXFIFO_ID_OFFSET           0x30 /* TX FIFO ID */
#define XCAN_TXFIFO_DLC_OFFSET          0x34 /* TX FIFO DLC */
#define XCAN_TXFIFO_DW1_OFFSET          0x38 /* TX FIFO Data Word 1 */
#define XCAN_TXFIFO_DW2_OFFSET          0x3C /* TX FIFO Data Word 2 */
#define XCAN_TXHPFIFO_ID_OFFSET         0x40 /* TX HP FIFO ID */
#define XCAN_TXHPFIFO_DLC_OFFSET        0x44 /* TX HP FIFO DLC */
#define XCAN_TXHPFIFO_DW1_OFFSET        0x48 /* TX HP FIFO Data Word 1 */
#define XCAN_TXHPFIFO_DW2_OFFSET        0x4C /* TX HP FIFO Data Word 2 */
#define XCAN_RXFIFO_ID_OFFSET           0x50 /* RX FIFO ID */
#define XCAN_RXFIFO_DLC_OFFSET          0x54 /* RX FIFO DLC */
#define XCAN_RXFIFO_DW1_OFFSET          0x58 /* RX FIFO Data Word 1 */
#define XCAN_RXFIFO_DW2_OFFSET          0x5C /* RX FIFO Data Word 2 */

/* CAN register bit masks - XCAN_<REG>_<BIT>_MASK */
#define XCAN_SRR_CEN_MASK               0x00000002 /* CAN enable */
#define XCAN_SRR_RESET_MASK             0x00000001 /* Soft Reset the CAN core */
#define XCAN_MSR_LBACK_MASK             0x00000002 /* Loop back mode select */
#define XCAN_MSR_SLEEP_MASK             0x00000001 /* Sleep mode select */
#define XCAN_BRPR_BRP_MASK              0x000000FF /* Baud rate prescaler */
#define XCAN_BTR_SJW_MASK               0x00000180 /* Synchronous jump width */
#define XCAN_BTR_TS2_MASK               0x00000070 /* Time segment 2 */
#define XCAN_BTR_TS1_MASK               0x0000000F /* Time segment 1 */
#define XCAN_ECR_REC_MASK               0x0000FF00 /* Receive error counter */
#define XCAN_ECR_TEC_MASK               0x000000FF /* Transmit error counter */
#define XCAN_ESR_ACKER_MASK             0x00000010 /* ACK error */
#define XCAN_ESR_BERR_MASK              0x00000008 /* Bit error */
#define XCAN_ESR_STER_MASK              0x00000004 /* Stuff error */
#define XCAN_ESR_FMER_MASK              0x00000002 /* Form error */
#define XCAN_ESR_CRCER_MASK             0x00000001 /* CRC error */
#define XCAN_SR_TXFLL_MASK              0x00000400 /* TX FIFO is full */
#define XCAN_SR_TXHPFLL_MASK            0x00000200 /* high proi TX FIFO is full */
#define XCAN_SR_ESTAT_MASK              0x00000180 /* Error status */
#define XCAN_SR_ERRWRN_MASK             0x00000040 /* Error warning */
#define XCAN_SR_BUSBUSY_MASK            0x00000020 /* Bus busy warning */
#define XCAN_SR_NORMAL_MASK             0x00000008 /* Normal mode */
#define XCAN_SR_LBACK_MASK              0x00000002 /* Loop back mode */
#define XCAN_SR_CONFIG_MASK             0x00000001 /* Configuration mode */
#define XCAN_IXR_TXFEMP_MASK            0x00004000 /* TX FIFO Empty */
#define XCAN_IXR_WKUP_MASK              0x00000800 /* Wake up interrupt */
#define XCAN_IXR_SLP_MASK               0x00000400 /* Sleep interrupt */
#define XCAN_IXR_BSOFF_MASK             0x00000200 /* Bus off interrupt */
#define XCAN_IXR_ERROR_MASK             0x00000100 /* Error interrupt */
#define XCAN_IXR_RXNEMP_MASK            0x00000080 /* RX FIFO NotEmpty intr */
#define XCAN_IXR_RXOFLW_MASK            0x00000040 /* RX FIFO Overflow intr */
#define XCAN_IXR_RXOK_MASK              0x00000010 /* Message received intr */
#define XCAN_IXR_TXFLL_MASK             0x00000004 /* TX FIFO is full */
#define XCAN_IXR_TXOK_MASK              0x00000002 /* TX successful intr */
#define XCAN_IXR_ARBLST_MASK            0x00000001 /* Arbitration lost intr */
#define XCAN_IDR_ID1_MASK               0xFFE00000 /* Standard msg identifier */
#define XCAN_IDR_SRR_MASK               0x00100000 /* Substitute remote TXreq */
#define XCAN_IDR_IDE_MASK               0x00080000 /* Identifier extension */
#define XCAN_IDR_ID2_MASK               0x0007FFFE /* Extended message ident */
#define XCAN_IDR_RTR_MASK               0x00000001 /* Remote TX request */
#define XCAN_DLCR_DLC_MASK              0xF0000000 /* Data length code */

/* CAN register bit shift - XCAN_<REG>_<BIT>_SHIFT */
#define XCAN_BTR_SJW_SHIFT              7  /* Synchronous jump width */
#define XCAN_BTR_TS2_SHIFT              4  /* Time segment 2 */
#define XCAN_IDR_ID1_SHIFT              21 /* Standard Messg Identifier */
#define XCAN_IDR_ID2_SHIFT              1  /* Extended Message Identifier */
#define XCAN_DLCR_DLC_SHIFT             28 /* Data length code */
#define XCAN_ESR_REC_SHIFT              8  /* Rx Error Count */


/* GP global register for 7010 lite  */
#ifndef FPGA_CAN_MODE_SMP
#define FPGA_GLOBAL_BASE				0x80000000
#define FPGA_GLOBAL_SIZE				10
#define FPGA_GLOBAL_NAME				"fpga_glabel"
#endif

static int fpga_can_major = 252;

#define FPGA_CLOCK 24000000

#define GP_MT_UNCACHED		(4)

#ifdef FPGA_CAN_MODE_SMP
const  int  PHYS_ADDR_CAN[FPGA_CAN_NR] = {0xe0008000,0xe0009000,0x401c0000};
//const  int  PHYS_ADDR_CAN[FPGA_CAN_NR] = {0x40140000,0x40180000,0x401c0000};
#else
/*const*/  int  PHYS_ADDR_CAN[FPGA_CAN_NR] = {0x80140000,0x80180000,0x801c0000}; 
#endif

#define FPGA_CAN_PHY_SIZE  0x1000 	

/* Added by zhengg for sync time functions */
#define BCODE_OCM_PHY_BASE     0xffff0420
#define BCODE_OCM_PHY_SIZE     0x100
#ifdef FPGA_CAN_MODE_SMP
void __iomem *bcode_ocm_virt = NULL;
#endif

struct fpga_can_stats {
	unsigned long tx_packets; 
	unsigned long tx_bytes; 
	unsigned long rx_packets; 
	unsigned long rx_bytes;
	unsigned long rx_over_errors;
	unsigned long tx_errors;
};

#define FPGA_CAN_USING_IOMEM

typedef struct _fpga_can_data {
	unsigned long id;
	unsigned long dlc;
	unsigned long data1;
	unsigned long data2;
}fpga_can_data;

/* buffer size = 128 * 16 = 2048, rx+tx=4K(one page size) per port */
#define SF_FPGACAN_BUFFER_COUNT 127
#define SF_FPGACAN_BUFFER_SIZE ((SF_FPGACAN_BUFFER_COUNT + 1)*16)
typedef struct _fpga_can_buffer {
	unsigned long buf_count; 
	volatile unsigned long rptr; 
	volatile unsigned long wptr; 
	unsigned long reserve; 
	fpga_can_data data[1];
}fpga_can_buffer;


typedef struct _fpga_can_dev {
	struct cdev cdev;
	struct class *can_dev_class;
#ifdef FPGA_CAN_USING_IOMEM
	void __iomem *base[FPGA_CAN_NR];
#else
	unsigned long base[FPGA_CAN_NR];
#endif
	int dev_num;
	int dev_exist[FPGA_CAN_NR];
	fpga_can_buffer *rx_buffer[FPGA_CAN_NR];
	fpga_can_buffer *tx_buffer[FPGA_CAN_NR];
	int state[FPGA_CAN_NR];
	int ctrlmode[FPGA_CAN_NR];
	int speed[FPGA_CAN_NR];
	int open_count[FPGA_CAN_NR];
	struct semaphore semWr[FPGA_CAN_NR];
	struct semaphore semRd[FPGA_CAN_NR];
	struct fpga_can_stats stats[FPGA_CAN_NR];
	struct work_struct sf_fpgacan_rx_wk;
	struct work_struct sf_fpgacan_tx_wk;
	struct hrtimer sf_fpgacan_rx_timer;
	struct hrtimer sf_fpgacan_tx_timer;
}fpgacan_dev;

fpgacan_dev 	sf_fpgacan_dev;	

//#define SF_FPGACAN_POLL_INTERVAL 500
#define SF_FPGACAN_POLL_INTERVAL 2000
//#define SF_FPGACAN_POLL_INTERVAL 1000
//#define SF_FPGACAN_POLL_INTERVAL 4000
enum {
	FPGA_CAN_STATE_STOPPED,
	FPGA_CAN_STATE_START,
	FPGA_CAN_STATE_ERROR_ACTIVE,
};

int fpga_can_read(int minor);
int fpga_can_write(int minor);
long fpga_can_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
static void set_baudrate(unsigned int minor,int baud);
static int set_reset_mode(int minor);
int fpgacan_rx_poll(int minor, unsigned long *buf);
static int fpgacan_start_xmit(unsigned long *buf, int minor);
static int fpgacan_start(int minor);
static void fpgacan_stop(int minor);
static void sf_fpgacan_rx_wk(struct work_struct *work);
static void sf_fpgacan_tx_wk(struct work_struct *work);
#if 0
static ssize_t fpga_can_info(int minor);
#endif

#define FPGA_CAN_USING_SFIOREMAP 1
#define FPGA_CAN_BUGET_PER_LOOP 64


/********************* hrtimer ****************************/
static enum hrtimer_restart sf_fpgacan_rx_timer_handle(struct hrtimer *timer)
{
	int missed;

	schedule_work(&sf_fpgacan_dev.sf_fpgacan_rx_wk);
	missed = hrtimer_forward_now(&sf_fpgacan_dev.sf_fpgacan_rx_timer,
                        ktime_set(0, SF_FPGACAN_POLL_INTERVAL * NSEC_PER_USEC));

	return HRTIMER_RESTART;
}


/********************* hrtimer ****************************/
static enum hrtimer_restart sf_fpgacan_tx_timer_handle(struct hrtimer *timer)
{
	int missed;

	schedule_work(&sf_fpgacan_dev.sf_fpgacan_tx_wk);

	missed = hrtimer_forward_now(&sf_fpgacan_dev.sf_fpgacan_tx_timer,
                        ktime_set(0, SF_FPGACAN_POLL_INTERVAL * NSEC_PER_USEC));
	
	return HRTIMER_RESTART;
}

int kthrd_timer_init(fpgacan_dev *dev)
{
	/* initialize a hrtimer */
	hrtimer_init(&dev->sf_fpgacan_rx_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	dev->sf_fpgacan_rx_timer.function = sf_fpgacan_rx_timer_handle;
	hrtimer_start(&dev->sf_fpgacan_rx_timer, 
			ktime_set(0, SF_FPGACAN_POLL_INTERVAL * NSEC_PER_USEC),
			HRTIMER_MODE_REL);

	pr_info("%s(%d): fpga_can_timer start.\n", __FUNCTION__, __LINE__);

	return 0;
}

void kthrd_timer_cleanup(fpgacan_dev *dev)
{
	hrtimer_cancel(&dev->sf_fpgacan_rx_timer);
	return;
}

static void sf_fpgacan_rx_wk(struct work_struct *work)
{
	int i, ret;

	for(i = 0; i < FPGA_CAN_NR; i++) {
		ret = fpga_can_read(i);

		ret = fpga_can_write(i);
	}


	return;	
}

static void sf_fpgacan_tx_wk(struct work_struct *work)
{
	int i, ret;

	for(i = 0; i < FPGA_CAN_NR; i++) {
		ret = fpga_can_write(i);
	}

	return;	
}

static void can_write_reg(void __iomem *base, unsigned long reg, u32 val)
{
	*(volatile unsigned long *)(base+reg) = val;
}

static u32 can_read_reg(void __iomem *base, unsigned long reg)
{
	u32 val;
	val = *(volatile unsigned long *)(base + reg);
	return val;
}

int fpga_can_open(struct inode *inode, struct file *file)
{
	unsigned int minor = iminor(inode);
	int err;

	if(minor >= FPGA_CAN_NR) 
		return -EIO;				

		/* Set chip into reset mode */
	if(sf_fpgacan_dev.open_count[minor] == 0) {
		err = set_reset_mode(minor);
		if (err < 0) {
			printk("mode resetting failed failed!\n");
		}
	}

	sf_fpgacan_dev.open_count[minor]++;
#ifdef DEBUG
	printk("%s init canport %d open!\n", __FUNCTION__, minor);	
#endif

	return 0;
}

int fpga_can_read(int minor)
{
	int wptr, rptr, buf_count;
	int ret, work_done = 0;
	unsigned long *buf;

	if((minor >= FPGA_CAN_NR) || (sf_fpgacan_dev.dev_exist[minor] == 0))
		return -1;

	wptr = sf_fpgacan_dev.rx_buffer[minor]->wptr;
	rptr = sf_fpgacan_dev.rx_buffer[minor]->rptr;
	buf_count = sf_fpgacan_dev.rx_buffer[minor]->buf_count;
	
	do { 
		if(((wptr + 1)%buf_count) == rptr) { 
			//printk("%s buffer full.\n", __FUNCTION__);
			break; /* buffer full */
		}

		buf = (unsigned long *)(sf_fpgacan_dev.rx_buffer[minor]->data + wptr);
		ret = fpgacan_rx_poll(minor, buf);
		if(ret == 0) { 	
			wptr++;
			wptr = wptr%buf_count;
			work_done ++;
			if(work_done > FPGA_CAN_BUGET_PER_LOOP){
				break;
			}
		}
		else if(ret == -2)  /* receive sync packet */
			continue;
		else /* phy fifo empty */
			break;
	}while(1);	

	sf_fpgacan_dev.rx_buffer[minor]->wptr = wptr; /* Update the write point at last */

	return work_done;
}

struct xcan_rx_frame {
	u32 reg_id_xcan;
	u32 reg_dlc;
	u32 reg_data1;
	u32 reg_data2;
} xcan_rx_buffer;

int xcan_highprior_xmit(struct xcan_rx_frame *frame)
{

	if(frame == NULL)
		return -1;

	/* Check if the TX buffer is full */
	if (can_read_reg(sf_fpgacan_dev.base[0], XCAN_SR_OFFSET) & XCAN_SR_TXHPFLL_MASK) 
		return -1;

	/* Write the Frame to Xilinx CAN TX FIFO */
	can_write_reg(sf_fpgacan_dev.base[0], XCAN_TXHPFIFO_ID_OFFSET,  frame->reg_id_xcan);
	can_write_reg(sf_fpgacan_dev.base[0], XCAN_TXHPFIFO_DLC_OFFSET, frame->reg_dlc);
	can_write_reg(sf_fpgacan_dev.base[0], XCAN_TXHPFIFO_DW1_OFFSET, frame->reg_data1);
	can_write_reg(sf_fpgacan_dev.base[0], XCAN_TXHPFIFO_DW2_OFFSET, frame->reg_data2);

	return 0;
}

EXPORT_SYMBOL(xcan_highprior_xmit);

static int fpga_can_mmap(struct file *filp, struct vm_area_struct *vma)  
{  
	unsigned int minor = MINOR(filp->f_dentry->d_inode->i_rdev);
	unsigned long mmap_size;  
	unsigned long start = vma->vm_start;  
	unsigned long size = PAGE_ALIGN(vma->vm_end - vma->vm_start);  
	unsigned char *mmap_buf;

	if(sf_fpgacan_dev.dev_exist[minor] == 0)
		return -EINVAL;

	mmap_size = SF_FPGACAN_BUFFER_SIZE*2;
	mmap_buf  = (unsigned char *)sf_fpgacan_dev.rx_buffer[minor];

	printk("mmap_size %ld, size %ld.\n", mmap_size, size);
	if (size > mmap_size || !mmap_buf) {  
		return -EINVAL;  
	}  

	return remap_pfn_range(vma, start, (virt_to_phys(mmap_buf) >> PAGE_SHIFT), size, PAGE_SHARED);  
}  
	
/* Read from soft buffer, and write to the can fifo */
int fpga_can_write(int minor)
{	
	int wptr, rptr, buf_count;
	int ret, work_done = 0;
	unsigned long *buf;

	if((minor >= FPGA_CAN_NR) || (sf_fpgacan_dev.dev_exist[minor] == 0))
		return -EIO;

	wptr = sf_fpgacan_dev.tx_buffer[minor]->wptr;
	rptr = sf_fpgacan_dev.tx_buffer[minor]->rptr;

	buf_count = sf_fpgacan_dev.tx_buffer[minor]->buf_count;
	
	while(rptr != wptr) {
		buf = (unsigned long *)(sf_fpgacan_dev.tx_buffer[minor]->data + rptr);
		//printk("\nfind a frame wptr %d rptr %d.\n", wptr, rptr);
		//printk("minor %d %08x %08x %08x %08x.\n", minor, buf[0],buf[1],buf[2],buf[3]);
		ret = fpgacan_start_xmit(buf, minor);
		if(ret < 0) {
			break; /* phy fifo full */
		}
		rptr ++;
		rptr = rptr % buf_count;

		work_done++;
		if(work_done > FPGA_CAN_BUGET_PER_LOOP){
            break;
        }

	}

	sf_fpgacan_dev.tx_buffer[minor]->rptr = rptr; /* Update the write point at last */
	return work_done;	
}

static int fpga_can_reset(int minor)
{
	int rs = 0;
	
	/*reset device*/
	fpgacan_stop(minor);
	
	fpgacan_start(minor);
	
	return(rs);
}

long fpga_can_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	unsigned int minor = iminor(file->f_mapping->host);	
	int new_option = 0;
	unsigned int isr = 0;
	void __user *argp = (void __user *)arg;
	int __user *p = argp;

	if(minor >= FPGA_CAN_NR) 
		return -EIO;

	get_user(new_option, p);
#ifdef DEBUG
	printk("cmd=%x,data=%d\n",cmd,new_option);
#endif
	switch (cmd) {
		case SET_SPEED:		
			if (get_user(new_option, p) != 0)
				return -1;

			if((new_option != SPEED_1M) && (new_option != SPEED_200K)) {
				sf_fpgacan_dev.speed[minor] = SPEED_1M;
				return -1;
			}
			sf_fpgacan_dev.speed[minor] = new_option;

			break;
		case SET_LOOPBACK:		
			if (get_user(new_option, p) != 0)
				return -1;
			sf_fpgacan_dev.ctrlmode[minor] = new_option;
			break;
		case SET_START:		
			if(sf_fpgacan_dev.state[minor] == FPGA_CAN_STATE_STOPPED)
				fpgacan_start(minor);			
			break;
		case GET_STATUS:
			isr = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ISR_OFFSET);
			put_user(isr,p);
			break;
		case RESET_DEV:
				fpga_can_reset(minor);
			break;
		default:
			printk("%s: error parameter: %d.\n", __FUNCTION__, cmd);
			break;
	}			
	return 0;
}

int fpga_can_release(struct inode *inode, struct file *file)
{
	unsigned int minor = iminor(inode);

	if(minor >= FPGA_CAN_NR) 
 		return -1;

	sf_fpgacan_dev.open_count[minor]--;
	if(sf_fpgacan_dev.open_count[minor] <= 0) {
		fpgacan_stop(minor);
		sf_fpgacan_dev.open_count[minor] = 0;
	}

	return 0;
}

static const struct file_operations fpga_can_fops = {
	.owner = THIS_MODULE,
//	.read = fpga_can_read,
//	.write = fpga_can_write,
	.unlocked_ioctl = fpga_can_ioctl,
	.open = fpga_can_open,
	.mmap = fpga_can_mmap,
	.release = fpga_can_release,
};

static void set_baudrate(unsigned int minor,int baud)
{
	/* for input clk is 24M Hz */
	switch (baud){
		case 200000:	
			can_write_reg(sf_fpgacan_dev.base[minor], XCAN_BRPR_OFFSET, 0x9);
			break;	
		case 1000000:	
			can_write_reg(sf_fpgacan_dev.base[minor], XCAN_BRPR_OFFSET, 0x1);
			break;
		default:	
			can_write_reg(sf_fpgacan_dev.base[minor], XCAN_BRPR_OFFSET, 0x9);
			break;		
	}
	
	/* BRPR: x+1 */
	/* BTR: 0+3+6+3 = 12 */
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_BTR_OFFSET, 0x54);
	//can_write_reg(sf_fpgacan_dev.base[minor], XCAN_BTR_OFFSET, 0x27);
	printk("%s: set baud %d, brpr: %x, , btr %x.\n", 
	__FUNCTION__, baud,
	can_read_reg(sf_fpgacan_dev.base[minor], XCAN_BRPR_OFFSET),
	can_read_reg(sf_fpgacan_dev.base[minor], XCAN_BTR_OFFSET));

	return;
}
 
#if 0
static ssize_t fpga_can_info(int minor)
{
	int result;
	struct fpga_can_stats *stats;

	stats = &sf_fpgacan_dev.stats[minor];

	printk("%s%d info:\n", FPGA_CAN_DEVICE_NAME, minor);
	printk( "tx pkts: %ld byte %ld, rx pkts %ld byte %ld\n", stats->tx_packets, stats->tx_bytes, stats->rx_packets, stats->rx_bytes);
	printk("Errors:\n");
	printk("ro: %ld, te: %ld\n", 
			stats->rx_over_errors, stats->tx_errors);

	printk("State:\n");
	printk("state: 0x%x,  ISR: 0x%x, SR: 0x%x, ESR: 0x%x, ECR: 0x%x\n", sf_fpgacan_dev.state[minor], 
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ISR_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET), 
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ECR_OFFSET));
	printk("regs:\n");
	printk("mcr: 0x%x,  ier: 0x%x, brpr: 0x%x, btr: 0x%x, wir: 0x%x\n", can_read_reg(sf_fpgacan_dev.base[minor], XCAN_MSR_OFFSET),
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_IER_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_BRPR_OFFSET), 
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_BTR_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_WIR_OFFSET));

	return result;
}

/* sysfs */
static ssize_t fpga_can_show_info(struct device *dev, struct device_attribute *attr, char *buf)
{
	unsigned int minor = MINOR(dev->devt);
	int result;
	struct fpga_can_stats *stats;

	stats = &sf_fpgacan_dev.stats[minor];

	result  = snprintf(buf, PAGE_SIZE, "%s%d info:\n", FPGA_CAN_DEVICE_NAME, minor);
	result += snprintf(buf + result, PAGE_SIZE - result,
			"tx pkts: %ld byte %ld, rx pkts %ld byte %ld\n", stats->tx_packets, stats->tx_bytes, stats->rx_packets, stats->rx_bytes);
	result += snprintf(buf + result, PAGE_SIZE - result, "Errors:\n");
	result += snprintf(buf + result, PAGE_SIZE - result, "ro: %ld, te: %ld\n", 
			stats->rx_over_errors, stats->tx_errors);

	result += snprintf(buf + result, PAGE_SIZE - result, "State:\n");
	result += snprintf(buf + result, PAGE_SIZE - result,
			"state: 0x%x,  ISR: 0x%x, SR: 0x%x, ESR: 0x%x, ECR: 0x%x\n", sf_fpgacan_dev.state[minor], 
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ISR_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET), 
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ECR_OFFSET));
	result += snprintf(buf + result, PAGE_SIZE - result, "regs:\n");
	result += snprintf(buf + result, PAGE_SIZE - result,
			"mcr: 0x%x,  ier: 0x%x, brpr: 0x%x, btr: 0x%x, wir: 0x%x\n", can_read_reg(sf_fpgacan_dev.base[minor], XCAN_MSR_OFFSET),
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_IER_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_BRPR_OFFSET), 
			can_read_reg(sf_fpgacan_dev.base[minor], XCAN_BTR_OFFSET), can_read_reg(sf_fpgacan_dev.base[minor], XCAN_WIR_OFFSET));

	return result;
}

static ssize_t fpga_can_set_info(struct device *dev,
                            struct device_attribute *attr,
			                                const char *buf, size_t count)
{
	        return 0;
}

static DEVICE_ATTR(fpga_can_info, 0644, fpga_can_show_info, fpga_can_set_info);
#endif


#if 0
#define XCAN_INTR_ALL		(XCAN_IXR_TXOK_MASK | XCAN_IXR_BSOFF_MASK |\
				 XCAN_IXR_WKUP_MASK | XCAN_IXR_SLP_MASK | \
				 XCAN_IXR_RXNEMP_MASK | XCAN_IXR_ERROR_MASK | \
				 XCAN_IXR_ARBLST_MASK | XCAN_IXR_RXOK_MASK)
#else
//#define XCAN_INTR_ALL		XCAN_IXR_TXFLL_MASK            
#define XCAN_INTR_ALL		0
#endif

static int set_reset_mode(int minor)
{
	unsigned long timeout;

	sf_fpgacan_dev.state[minor] = FPGA_CAN_STATE_STOPPED;
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_SRR_OFFSET, XCAN_SRR_OFFSET);

	timeout = jiffies + XCAN_TIMEOUT;
	while (!(can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET) & XCAN_SR_CONFIG_MASK)) {
		if (time_after(jiffies, timeout)) {
			printk("timedout waiting for config mode\n");
			return -ETIMEDOUT;
		}
		schedule_timeout(1);
	}

	return 0;
}

/**
 * fpgacan_start - This the drivers start routine
 * @ndev:	Pointer to net_device structure
 *
 * This is the drivers start routine.
 * Based on the State of the CAN device it puts
 * the CAN device into a proper mode.
 *
 * Return: 0 always
 */
static int fpgacan_start(int minor)
{
	unsigned long timeout;

	/* Check if it is in reset mode */
	if (sf_fpgacan_dev.state[minor] != FPGA_CAN_STATE_STOPPED)
		set_reset_mode(minor);

	//can_write_reg(sf_fpgacan_dev.base[minor], XCAN_WIR_OFFSET, 0x3f3f);

	/* Check whether it is loopback mode or normal mode  */
	//printk("\n%s: minor %d, mode %ld, rate %ld.\n", __FUNCTION__, minor, sf_fpgacan_dev.ctrlmode[minor], sf_fpgacan_dev.speed[minor]);
	if (sf_fpgacan_dev.ctrlmode[minor] == CAN_CTRLMODE_LOOPBACK)
		/* Put device into loopback mode */
		can_write_reg(sf_fpgacan_dev.base[minor], XCAN_MSR_OFFSET, XCAN_MSR_LBACK_MASK);
	else
		/* The device is in normal mode */
		can_write_reg(sf_fpgacan_dev.base[minor], XCAN_MSR_OFFSET, 0);

	set_baudrate(minor, sf_fpgacan_dev.speed[minor]);

	/* Enable interrupts */
	if(XCAN_INTR_ALL != 0) {
		can_write_reg(sf_fpgacan_dev.base[minor], XCAN_IER_OFFSET, XCAN_INTR_ALL);
	}

	if (sf_fpgacan_dev.state[minor] == FPGA_CAN_STATE_STOPPED) {
		/* Enable sifang CAN */
		can_write_reg(sf_fpgacan_dev.base[minor], XCAN_SRR_OFFSET, XCAN_SRR_CEN_MASK);
		sf_fpgacan_dev.state[minor] = FPGA_CAN_STATE_ERROR_ACTIVE;
		timeout = jiffies + XCAN_TIMEOUT;
		if (sf_fpgacan_dev.ctrlmode[minor] == CAN_CTRLMODE_LOOPBACK) {
			while ((can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET) &
					XCAN_SR_LBACK_MASK) == 0) {
				if (time_after(jiffies, timeout)) {
					printk("timedout waiting for loopback mode\n");
					return -ETIMEDOUT;
				}
			}
		} else {
			while ((can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET)
					& XCAN_SR_NORMAL_MASK) == 0) {
				if (time_after(jiffies, timeout)) {
					printk("timedout waiting for normal mode\n");
					return -ETIMEDOUT;
				}
			}
					
		}
		//printk("status:#x%08x\n", can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET));
	}

	sf_fpgacan_dev.state[minor] = FPGA_CAN_STATE_ERROR_ACTIVE;

	printk("%s: port %d started.\n", __FUNCTION__, minor);
	return 0;
}

/**
 * fpgacan_start_xmit - Starts the transmission
 * @skb:	sk_buff pointer that contains data to be Txed
 * @ndev:	Pointer to net_device structure
 *
 * This function is invoked from upper layers to initiate transmission. This
 * function uses the next available free txbuff and populates their fields to
 * start the transmission.
 *
 * Return: 0 on success and failure value on error
 */
static int fpgacan_start_xmit(unsigned long *buf, int minor)
{
	struct fpga_can_stats *stats;
#ifdef FPGACAN_USE_SPINLOCK
	unsigned long flags1;
#endif
	unsigned long can_sr;

	stats = &sf_fpgacan_dev.stats[minor];

	can_sr =  can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET);
	/* Check if the TX buffer is full */
	if (can_sr & XCAN_SR_TXFLL_MASK)  {
		return -EIO;
	}

#ifdef FPGACAN_USE_SPINLOCK
	spin_lock_irqsave(&packet_skb_lock, flags1);
#endif
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_TXFIFO_ID_OFFSET, buf[0]);
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_TXFIFO_DLC_OFFSET, buf[1]);
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_TXFIFO_DW1_OFFSET, buf[2]);
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_TXFIFO_DW2_OFFSET, buf[3]);
#ifdef FPGACAN_USE_SPINLOCK
	spin_unlock_irqrestore(&packet_skb_lock, flags1);
#endif

	stats->tx_bytes += (buf[1]>>28);
	stats->tx_packets++;

	return 0;
}

#define IS_CAN_EXTID	(0x00080000)	

static const u32 constCan29NoSrc = 0x1FE01FE0;  /* src & frame end & seq mask */
static const u32 constCan29MstBC = ((((u32)0x40) &0xFF)<<21);
static const u32 constCan29FrameEnd = (((u32)0x01)<<12);

static const u32 constCan11NoSrc = 0x000007E0;	/* src & frame end */
static const u32 constCan11MstBC = ((((u32)0x1E) &0x1F)<<6);
static const u32 constCan11FrameEnd = (((u32)0x01)<<5);

static int is_can_sync_frame(u32 canID)
{
	u32 id = 0;
	int rs = 0;
	
	if(canID & 0x00080000) {
		id = ((canID & 0xFFE00000)>>3) | ((canID & 0x0007FFFE)>>1);
		if((id & constCan29NoSrc) == (constCan29MstBC|constCan29FrameEnd))
			rs = 1;
	} else {		
		id = ((canID>>21)&0x0000007FF);
		if((id & constCan11NoSrc) == (constCan11MstBC|constCan11FrameEnd))
			rs = 1;
	}
	return (rs);
}

/**
 * fpgacan_rx_poll - Poll routine for rx packets (NAPI)
 * @napi:	napi structure pointer
 * @quota:	Max number of rx packets to be processed.
 *
 * This is the poll routine for rx part.
 * It will process the packets maximux quota value.
 *
 * Return: number of packets received
 */
#undef SF_CAN_INT_DEBUG
int fpgacan_rx_poll(int minor, unsigned long *buf)
{
	u32 isr;
	struct fpga_can_stats *stats;
	int ret = -1;
#ifdef FPGACAN_USE_SPINLOCK
	unsigned long flags1;
#endif
#ifdef FPGA_CAN_MODE_SMP
	int can_dlc;
	int temp_data;
#endif
	int esr;

	stats = &sf_fpgacan_dev.stats[minor];

	isr = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ISR_OFFSET);
	if (isr & XCAN_IXR_RXNEMP_MASK) {
		//fpgacan_read_time(&fpgacan_debug_time[4][0], &fpgacan_debug_time[4][1]);
		//if(isr & XCAN_IXR_RXOK_MASK) {

#ifdef FPGACAN_USE_SPINLOCK
			spin_lock_irqsave(&packet_skb_lock, flags1);
#endif
			/* Read a frame from sifang zynq CANPS */
			buf[0] = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_RXFIFO_ID_OFFSET);
			buf[1] = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_RXFIFO_DLC_OFFSET) & XCAN_DLCR_DLC_MASK;
			buf[2] = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_RXFIFO_DW1_OFFSET);
			buf[3] = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_RXFIFO_DW2_OFFSET);
#ifdef FPGACAN_USE_SPINLOCK
			spin_unlock_irqrestore(&packet_skb_lock, flags1);
#endif
#ifdef FPGA_CAN_MODE_SMP
			if((minor == 0) && (bcode_ocm_virt != NULL)) {
				/* capture the pps 03 message, store it into the ocm */
				can_dlc = (buf[1]& XCAN_DLCR_DLC_MASK) >> XCAN_DLCR_DLC_SHIFT;
				if((buf[2]>>24 & 0xff) == 0x03 && can_dlc == 0x08 && is_can_sync_frame(buf[0])){
					*(unsigned long *)bcode_ocm_virt = buf[2];
					temp_data = *(unsigned long *)bcode_ocm_virt;
					*((volatile unsigned long *)bcode_ocm_virt + 1) = buf[3];
					temp_data = *((unsigned long *)bcode_ocm_virt + 1);
					
					ret = -2;
					goto CAN0_SYNC_FINISHED;
				}
				//printk("buf2 0x%lx, buf3 0x%lx.\n", buf[2], buf[3]);
			}
#endif

#ifdef SF_CAN_INT_DEBUG
			if(minor == 0) {
			temp_data = (buf[0] & 0xFFE00000) >> 3;
			temp_data |= (buf[0] & 0x0007FFFE) >> 1;
			temp_data |= 0x80000000;

			if(buf[0] & 0x00000001)
				temp_data |= 0x40000000;
			
			printk("\n%s port %d isr %x s:%x d:%x seq:%d l:%d %lx %lx %lx.\n", __FUNCTION__, minor, isr, (temp_data>>21)&0xff,
                              (temp_data>>13)&0xff,((temp_data>>5)&0x7f), ((temp_data>>12)&1) ,buf[1],buf[2],buf[3]);
			}
#endif
			if(isr & 0x100) {
#ifdef SF_CAN_INT_DEBUG
				if(minor == 0) {
					printk("state: SR: 0x%x, ESR: 0x%x, ECR: 0x%x\n", 
							can_read_reg(sf_fpgacan_dev.base[minor], XCAN_SR_OFFSET), 
							can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET), 
							can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ECR_OFFSET));
				}
#endif
				if(can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET) != 0) {
					esr = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET);
					can_write_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET, esr);
					//		mb();
					//printk("clear ESR: 0x%x\n", can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ESR_OFFSET)); 
				}
			}
			stats->rx_bytes += buf[1] >> 28;
			stats->rx_packets++;

		//	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_ICR_OFFSET, XCAN_IXR_RXOK_MASK);

			ret = 0;
	//	}
		//isr = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_ISR_OFFSET);
	//	isr &= XCAN_IXR_RXNEMP_MASK;
		//can_write_reg(sf_fpgacan_dev.base[minor], XCAN_ICR_OFFSET, isr);
CAN0_SYNC_FINISHED:
		can_write_reg(sf_fpgacan_dev.base[minor], XCAN_ICR_OFFSET, XCAN_IXR_RXNEMP_MASK);
		//fpgacan_read_time(&fpgacan_debug_time[5][0], &fpgacan_debug_time[5][1]);
	}

	return ret;

}

static void fpgacan_stop(int minor)
{
	u32 ier;

	/* Disable interrupts and leave the sf_fpgacan_dev in configuration mode */
	if(XCAN_INTR_ALL != 0) {
		ier = can_read_reg(sf_fpgacan_dev.base[minor], XCAN_IER_OFFSET);
		ier &= ~XCAN_INTR_ALL;
		can_write_reg(sf_fpgacan_dev.base[minor], XCAN_IER_OFFSET, ier);
	}
	can_write_reg(sf_fpgacan_dev.base[minor], XCAN_SRR_OFFSET, XCAN_SRR_RESET_MASK);
	sf_fpgacan_dev.state[minor] = FPGA_CAN_STATE_STOPPED;
}


/*
 * V1.0.0,2016.12.26
 * V1.0.1,2017.03.31, modify for 7010 AMP,using ps can1 to connect outside can0 
 * V1.0.2,2017.04.05, merge the baudrate setting and logs in the interrupt handlers,  by zhenggang
 * V1.0.3,2017.04.10, modified the gp unremap operation parameter 
 */
#include "ver_inc/git_ver.h"
#define DRV_NAME	"fpgacan "
#define DRV_VERSION	"V1.0.6,"
#define GIT_INFO  	" git commit id "
#define VER_END  	"\r\n"


#define SF_DRIVER_VER_INFO   DRV_NAME  DRV_VERSION __DATE__ " " __TIME__ GIT_INFO  GIT_COMMIT_ID_STR VER_END

ssize_t  drv_version_show_info(struct class *class, struct class_attribute *attr,
		char *buf)
{
	int result;
	result  = snprintf(buf, PAGE_SIZE, SF_DRIVER_VER_INFO);

	return result;	
}
static CLASS_ATTR(drv_version, 0644, drv_version_show_info, NULL);

int fpga_can_init(void)
{
	int i, result, ret;
	dev_t dev_id;
	unsigned char *tmp_mem_addr;
	unsigned long size;
	struct page *page;

	pr_info("\r\n"SF_DRIVER_VER_INFO);
	pr_notice("can_init_module\n");

	/* Clear the device descripter first */
	memset(&sf_fpgacan_dev, 0, sizeof(sf_fpgacan_dev));

	result = alloc_chrdev_region(&dev_id, 0, FPGA_CAN_NR, FPGA_CAN_DEVICE_NAME);
	if(result < 0) 
		goto out;

	fpga_can_major = MAJOR(dev_id);

	cdev_init(&sf_fpgacan_dev.cdev, &fpga_can_fops);
	sf_fpgacan_dev.cdev.owner = THIS_MODULE;

	result = cdev_add(&sf_fpgacan_dev.cdev, dev_id, FPGA_CAN_NR);
	if (result < 0)
		goto unreg_chardev;

	sf_fpgacan_dev.can_dev_class = class_create(THIS_MODULE, FPGA_CAN_DEVICE_NAME);
	if (IS_ERR(sf_fpgacan_dev.can_dev_class)) {
		result = PTR_ERR(sf_fpgacan_dev.can_dev_class);
		goto del_chardev;
	}

	class_create_file(sf_fpgacan_dev.can_dev_class , &class_attr_drv_version);


	// process 7010 lite fpga,using ps can1 to connect outside can0 on the backplane
	// only use in AMP,add by lwp .2017.3.31
#ifndef FPGA_CAN_MODE_SMP
	tmp_mem_addr = ioremap_nocache(FPGA_GLOBAL_BASE, FPGA_GLOBAL_SIZE);
	if( readl((void __iomem *)tmp_mem_addr) == 0x70100001 )  // 7010 lite ver
		PHYS_ADDR_CAN[0] = 0xe0009000;	//	ps can1
	iounmap((void *)tmp_mem_addr);	
#endif

	sf_fpgacan_dev.dev_num = 0;
	for(i = 0; i < FPGA_CAN_NR; i++) {		 
		printk("scan %d sf_fpgacan_dev port.\n", i);
		request_mem_region(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE, FPGA_CAN_DEVICE_NAME);			
#ifdef FPGA_CAN_USING_IOMEM
#ifdef FPGA_CAN_USING_SFIOREMAP
		sf_fpgacan_dev.base[i] = __arm_ioremap(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE, GP_MT_UNCACHED);
#else
		sf_fpgacan_dev.base[i] = (void __iomem *)ioremap_nocache(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE);
#endif
#else
		sf_fpgacan_dev.base[i] = (unsigned char *)ioremap_nocache(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE);
#endif
		if (!sf_fpgacan_dev.base[i]) {
			printk("there is no area for sf_fpgacan_dev %d!\n", i);
			release_mem_region(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE); 	
			continue;
		}			

		if(can_read_reg(sf_fpgacan_dev.base[i], 0) == 0xDEADBEEF) {
			iounmap(sf_fpgacan_dev.base[i]);
			sf_fpgacan_dev.base[i] = NULL;
			sf_fpgacan_dev.dev_exist[i] = 0;
			release_mem_region(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE); 	
			continue;
		}
		else {
			/* Vmalloc the tx/rx buffer, and mapped them to the user space */
			size = PAGE_ALIGN(SF_FPGACAN_BUFFER_SIZE * 2);
			tmp_mem_addr = kmalloc(size, GFP_KERNEL);
			if(!tmp_mem_addr) {
				iounmap(sf_fpgacan_dev.base[i]);
				sf_fpgacan_dev.base[i] = NULL;
				release_mem_region(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE); 	
				continue;
			}

			for (page = virt_to_page(tmp_mem_addr); page < virt_to_page(tmp_mem_addr + size); page++) {  
				SetPageReserved(page);  
			}  

			sf_fpgacan_dev.rx_buffer[i] = (fpga_can_buffer *)tmp_mem_addr;
			sf_fpgacan_dev.tx_buffer[i] = (fpga_can_buffer *)(tmp_mem_addr + SF_FPGACAN_BUFFER_SIZE);

			/* Init and Clear buffer first */
			memset((void *)sf_fpgacan_dev.rx_buffer[i], 0, SF_FPGACAN_BUFFER_SIZE);
			memset((void *)sf_fpgacan_dev.tx_buffer[i], 0, SF_FPGACAN_BUFFER_SIZE);
			sf_fpgacan_dev.rx_buffer[i]->buf_count = SF_FPGACAN_BUFFER_COUNT; 
			sf_fpgacan_dev.rx_buffer[i]->reserve = 0x5a5a5a5a;  /* Tag for applications */
			sf_fpgacan_dev.tx_buffer[i]->buf_count = SF_FPGACAN_BUFFER_COUNT; 
			sf_fpgacan_dev.tx_buffer[i]->reserve = 0x5a5a5a5a;  /* Tag for applications */


			sf_fpgacan_dev.dev_exist[i] = 1;
			sf_fpgacan_dev.dev_num++;

			device_create(sf_fpgacan_dev.can_dev_class, NULL, MKDEV(fpga_can_major, i), NULL, FPGA_CAN_DEVICE_NAME"%d", i);

			//device_create_file(&sf_fpgacan_dev.cdev, &dev_attr_fpga_can_info);
		}
#ifdef FPGA_CAN_MODE_SMP
		if(i == 0) {
			bcode_ocm_virt = ioremap_cache(BCODE_OCM_PHY_BASE, BCODE_OCM_PHY_SIZE);
			if (!bcode_ocm_virt) {
				printk("fail to ioremap bcode_ocm failed\n");
				bcode_ocm_virt = NULL;
			}
			printk("channel 0 map the ocm memory for the 0x03 message.\n");
		}
#endif
		sema_init(&sf_fpgacan_dev.semWr[i], 1);
		sema_init(&sf_fpgacan_dev.semRd[i], 1);
	}

#ifdef FPGACAN_USE_SPINLOCK
	spin_lock_init(&packet_skb_lock);
#endif

	if(sf_fpgacan_dev.dev_num == 0) {
		result = -1;
		goto destroy_class;
	}
	else {
		printk("Sifang can driver find device: ");
		for(i = 0; i < FPGA_CAN_NR; i ++) {
			if(sf_fpgacan_dev.dev_exist[i] == 1)
				printk(" can%1d,", i);
		} 
		printk("\n");
	}

	sf_fpgacan_dev.ctrlmode[0] = 0;
	sf_fpgacan_dev.speed[0] = 1000000;
	fpgacan_start(0);
	sf_fpgacan_dev.open_count[0]++;

	INIT_WORK(&sf_fpgacan_dev.sf_fpgacan_rx_wk, sf_fpgacan_rx_wk);
//	INIT_WORK(&sf_fpgacan_dev.sf_fpgacan_tx_wk, sf_fpgacan_tx_wk);

	kthrd_timer_init(&sf_fpgacan_dev);

	return 0;

destroy_class:
	class_destroy(sf_fpgacan_dev.can_dev_class);
del_chardev:
	cdev_del(&sf_fpgacan_dev.cdev);
unreg_chardev:
	unregister_chrdev_region(dev_id, FPGA_CAN_NR);
out:
	return result;
}

void fpga_can_exit(void)
{	
	int	i;
	dev_t dev_id = MKDEV(fpga_can_major, 0);
	unsigned long size;
	unsigned char *mmap_buf;
	struct page *page;

	
    kthrd_timer_cleanup(&sf_fpgacan_dev);

	for(i = 0; i < FPGA_CAN_NR; i++){		  

		if(sf_fpgacan_dev.dev_exist[i] == 0) 
			continue;

		if (set_reset_mode(i) < 0)
			printk("mode resetting failed!\n");

		if(sf_fpgacan_dev.base[i] != 0) {
			/* unmap the reg space */
			iounmap((void *)sf_fpgacan_dev.base[i]);
			release_mem_region(PHYS_ADDR_CAN[i], FPGA_CAN_PHY_SIZE); 	

			/* unmap the data buffer space */
			size = PAGE_ALIGN(SF_FPGACAN_BUFFER_SIZE * 2);
			mmap_buf = (unsigned char *)sf_fpgacan_dev.rx_buffer[i];

			for (page = virt_to_page(mmap_buf); page < virt_to_page(mmap_buf + size); page++) {  
				ClearPageReserved(page);
			}  
			kfree(mmap_buf);

			sf_fpgacan_dev.rx_buffer[i] = NULL;
			sf_fpgacan_dev.tx_buffer[i] = NULL;
		}

#ifdef FPGA_CAN_MODE_SMP
		if(i == 0) {
			if(bcode_ocm_virt != NULL)
				iounmap((void *)bcode_ocm_virt);
		}
#endif
	}

	cdev_del(&sf_fpgacan_dev.cdev);   
	for(i = 0; i < FPGA_CAN_NR; i++){		  
		device_destroy(sf_fpgacan_dev.can_dev_class, MKDEV(fpga_can_major, i));
	}
	class_remove_file(sf_fpgacan_dev.can_dev_class, &class_attr_drv_version);
	class_destroy(sf_fpgacan_dev.can_dev_class);
	unregister_chrdev_region(dev_id, FPGA_CAN_NR);   

	printk("Sifang zynq fpga sf_fpgacan_dev driver exit\n");
}


MODULE_AUTHOR("Zgpegasus");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION("fpga_can Driver from Zgpegasus!");

module_param(fpga_can_major, int, S_IRUGO);

module_init(fpga_can_init);
module_exit(fpga_can_exit);

 
