#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <pthread.h>
#include <signal.h>
#include <sched.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <linux/unistd.h>
#include <assert.h>
#include <semaphore.h>

#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <sys/mman.h>

#include <net/if.h>
#include <sys/ioctl.h>
#include <linux/can.h>
#include <linux/fs.h>
#include <linux/can/raw.h>
#include <linux/can/netlink.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <errno.h>
#include "sf_fpga_can.h"

#define FRAME_TYPE_MASK_STANDARD 	0x00000020
#define FRAME_TYPE_MASK_EXTENDED 	0x00001000

/* CAN register bit shift - XCAN_<REG>_<BIT>_SHIFT */
#define XCAN_BTR_SJW_SHIFT              7  /* Synchronous jump width */
#define XCAN_BTR_TS2_SHIFT              4  /* Time segment 2 */
#define XCAN_IDR_ID1_SHIFT              21 /* Standard Messg Identifier */
#define XCAN_IDR_ID2_SHIFT              1  /* Extended Message Identifier */
#define XCAN_DLCR_DLC_SHIFT             28 /* Data length code */
#define XCAN_ESR_REC_SHIFT              8  /* Rx Error Count */

#define XCAN_IDR_ID1_MASK               0xFFE00000 /* Standard msg identifier */
#define XCAN_IDR_SRR_MASK               0x00100000 /* Substitute remote TXreq */
#define XCAN_IDR_IDE_MASK               0x00080000 /* Identifier extension */
#define XCAN_IDR_ID2_MASK               0x0007FFFE /* Extended message ident */
#define XCAN_IDR_RTR_MASK               0x00000001 /* Remote TX request */
#define XCAN_DLCR_DLC_MASK              0xF0000000 /* Data length code */

#define NLMSG_TAIL(nmsg) \
	((struct rtattr *) (((void *) (nmsg)) + NLMSG_ALIGN((nmsg)->nlmsg_len)))

//#define DEBUG
#define FPGACAN_LIB_SEMNAME "fpgacan_sem"

struct req_info {
	__u8 restart;
	__u8 disable_autorestart;
	__u32 restart_ms;
	struct can_ctrlmode *ctrlmode;
	struct can_bittiming *bittiming;
};

typedef struct __fpga_can_frame {
	unsigned long can_id;
	unsigned long can_dlc;
	unsigned long data1;
	unsigned long data2;
}fpga_can_frame;

/* buffer size = 128 * 16 = 2048, rx+tx=4K(one page size) per port */
#define SF_FPGACAN_BUFFER_COUNT 127
#define SF_FPGACAN_BUFFER_SIZE ((SF_FPGACAN_BUFFER_COUNT + 1)*16)
typedef struct _fpga_can_buffer {
        unsigned long buf_count; 
        volatile unsigned long rptr; 
        volatile unsigned long wptr;
        unsigned long reserve; 
        fpga_can_frame frame[1];
}fpga_can_buffer;


static int fpgacan_open_count = 0;
#define FPGACAN_OPEN_MAX_VALUE 10
typedef struct _fpga_can_dev{
	int fd;
	int used_flag;
	unsigned char *data_buf;
	unsigned long map_size;
	fpga_can_buffer *rx_buf;
	fpga_can_buffer *tx_buf;
}fpga_can_dev;
static fpga_can_dev fpgacan_lib_dev[FPGACAN_OPEN_MAX_VALUE] = {0};

//#undef  SF_FPGACAN_USE_MUTEX

#ifdef  SF_FPGACAN_USE_MUTEX
#define SF_FPGACAN_LIB_PROCESS_MUX

#ifdef SF_FPGACAN_LIB_PROCESS_MUX
static sem_t *sem = NULL;
#else
pthread_mutex_t mylock = PTHREAD_MUTEX_INITIALIZER;
#endif
#endif

int  sf_fpgacan_read(int can_fd, fpga_can_frame *frame, int count)
{
	fpga_can_buffer *tmp_rx_buff;
	fpga_can_frame *tmp_frame;
	unsigned char *read_buf;
	int lib_wptr, lib_rptr, buf_count;
	int i, work_done = 0, read_buget = 0;

	if((frame == NULL) || (count <= 0))
                return -1;

	for(i = 0; i < FPGACAN_OPEN_MAX_VALUE; i ++) {
		if(fpgacan_lib_dev[i].used_flag == 0)
			continue;
		else {
			if(can_fd == fpgacan_lib_dev[i].fd) {
				tmp_rx_buff = fpgacan_lib_dev[i].rx_buf;  	
				break;
			} 
		}
	}
	if(i == FPGACAN_OPEN_MAX_VALUE) {
		return -1;
	}

        lib_wptr = tmp_rx_buff->wptr;
        lib_rptr = tmp_rx_buff->rptr;
        buf_count = tmp_rx_buff->buf_count;
	tmp_frame = frame;

		printf("line:%d can_%d rd:%d wr:%d, 0x%08x 0x%08x %d\n",__LINE__,i,lib_rptr,lib_wptr,tmp_rx_buff->reserve,tmp_rx_buff->buf_count);
        while(lib_rptr != lib_wptr) {

                read_buf = (unsigned char *)(tmp_rx_buff->frame + lib_rptr);
		memcpy((void *)(frame + work_done), (void *)read_buf, sizeof(fpga_can_frame));

                lib_rptr ++;
                lib_rptr = lib_rptr % buf_count;

                work_done++;
                if(work_done >= count){
                        break;
                }
        }

        tmp_rx_buff->rptr = lib_rptr; /* Update the read point at last */
	
	return work_done;
}

int  sf_fpgacan_write(int can_fd, fpga_can_frame *send_frame, int count)
{
	fpga_can_buffer *tmp_tx_buff;
	fpga_can_frame *tmp_frame;
	int i, work_done = 0, lib_wptr, lib_rptr, buf_count;
	unsigned char *write_buf;

	if((send_frame == NULL) || (count <= 0))
                return -1;

	for(i = 0; i < FPGACAN_OPEN_MAX_VALUE; i ++) {
		if(fpgacan_lib_dev[i].used_flag == 0)
			continue;
		else {
			if(can_fd == fpgacan_lib_dev[i].fd) {
				tmp_tx_buff = fpgacan_lib_dev[i].tx_buf;  	
				break;
			} 
		}
	}
	if(i == FPGACAN_OPEN_MAX_VALUE) {
		return -1;
	}

        lib_wptr = tmp_tx_buff->wptr;
        lib_rptr = tmp_tx_buff->rptr;
        buf_count = tmp_tx_buff->buf_count;

	//printf("sf_fpgacan_write: wptr %d rptr %d\n", lib_wptr, lib_rptr);

	do {
		if(((lib_wptr + 1)%buf_count) == lib_rptr) {
			break; /* buffer full */
		}

		write_buf = (unsigned char *)(tmp_tx_buff->frame + lib_wptr);
		memcpy((void *)write_buf, (void *)(send_frame + work_done), sizeof(fpga_can_frame));
		lib_wptr++;
		lib_wptr = lib_wptr%buf_count;

		work_done ++;
		if(work_done >= count){
			break;
		}
	}while(1);

        tmp_tx_buff->wptr = lib_wptr; /* Update the write point at last */

	//printf("%s exit wptr %d rptr %d, worddone %d.\n", __FUNCTION__, lib_wptr, tmp_tx_buff->rptr, work_done);
	return work_done;
}

int sf_can_open(const char *name, int speed)
{
	int fd, i, data;
	int ret, mmap_size;
	unsigned char *mmap_ptr;
	fpga_can_dev  *tmp_can_dev;
	fpga_can_buffer  *tmp_can_buf;

	if((speed != SPEED_1M) && (speed != SPEED_200K)) {
		printf("dev %s only support 1M and 200K speed.\n", name);
		return -1;
	}

	if(name == NULL) {
		printf("input name is null.\n");
		return -1;
	}

	fd = open(name, O_RDWR);
	if(fd<0) {
		printf("  open %s error \n", name);
		tmp_can_dev->used_flag = 0;
		return -1;	
	}
#if 0
	else{
		printf("open %s ok\n", name);	

	}
#endif

#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	if(NULL == sem) {
		sem = sem_open(FPGACAN_LIB_SEMNAME, 0777, O_CREAT|O_RDWR, 1);
		if(sem) {
		}
		else {
			printf("fpgacan_open error | sem_open error(%s)\n", strerror(errno));
			return -2;
		}
	}
#endif
#endif

	mmap_size = 16;
	mmap_ptr = (unsigned char *)mmap(NULL, mmap_size, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_LOCKED, fd, 0);  
	if (mmap_ptr == MAP_FAILED) {  
		printf("fpgacan_open error | tmp mmap data buffer error\n");
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
		sem_close(sem);
#endif
#endif
		close(fd);
		return -1;  
	}  
	tmp_can_buf = (fpga_can_buffer *)mmap_ptr;
	printf("driver data buf fifo count: %d magic: %lx.\n", tmp_can_buf->buf_count, 
				tmp_can_buf->reserve);
	mmap_size = (tmp_can_buf->buf_count + 1) * 32;
	munmap(mmap_ptr, 16);

	mmap_ptr = (unsigned char *)mmap(NULL, mmap_size, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_LOCKED, fd, 0);  
	if (mmap_ptr == MAP_FAILED) {  
		printf("fpgacan_open error | mmap data buffer error\n");
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
		sem_close(sem);
#endif
#endif
		close(fd);
		return -1;  
	}  

	for(i = 0; i < FPGACAN_OPEN_MAX_VALUE; i ++) {
		if(fpgacan_lib_dev[i].used_flag == 1)
			continue;
		else {
			fpgacan_lib_dev[i].used_flag = 1;
			tmp_can_dev = &fpgacan_lib_dev[i];
			break;
		}
	}
	if(i == FPGACAN_OPEN_MAX_VALUE) {
		printf("No space open new fd.\n");
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
		sem_close(sem);
#endif
#endif
		munmap(mmap_ptr, mmap_size);
		close(fd);
		return -1;
	} 

	tmp_can_dev->fd = fd;
	tmp_can_dev->data_buf = mmap_ptr;
	tmp_can_dev->map_size = mmap_size;
	tmp_can_dev->rx_buf =(fpga_can_buffer *)mmap_ptr;
	printf("rx data buf fifo count: %d magic: %lx.\n", tmp_can_dev->rx_buf->buf_count, tmp_can_dev->rx_buf->reserve);
	tmp_can_dev->tx_buf = (fpga_can_buffer *)(mmap_ptr + (tmp_can_dev->rx_buf->buf_count + 1)*16);
	printf("tx data buf fifo count: %d magic: %lx.\n", tmp_can_dev->tx_buf->buf_count, tmp_can_dev->tx_buf->reserve);

	ret = ioctl(fd,  SET_SPEED,  &speed);  
	if(ret < 0) {
		printf("  set %s speed %d error \n", name, speed);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
		sem_close(sem);
#endif
#endif
		munmap(mmap_ptr, mmap_size);
		close(fd);
		return -1;	
	}

	data = 0;
	ret = ioctl(fd,  SET_LOOPBACK,  &data);  
	if(ret < 0) {
		printf("  set %s no loopbak error \n", name);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
		sem_close(sem);
#endif
#endif
		munmap(mmap_ptr, mmap_size);
		close(fd);
		return -1;	
	}

	data = 1;
	ret = ioctl(fd,  SET_START,  &data);  
	if(ret < 0) {
		printf("  start %s port failed\n", name);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
		sem_close(sem);
#endif
#endif
		munmap(mmap_ptr, mmap_size);
		close(fd);
		return -1;	
	}

	/* No blocking */
	data = 1;
	ret = ioctl(fd, FIONBIO, &data);

	fpgacan_open_count++; 

	return fd;
}

int sf_can_set_filter(int can_fd, int filter_count, int *filter)
{
	int down_filter[9], *tmp;
	int ret;

	if(filter_count > 4) {
		printf("  filter count %d, we only support 4 filter\n", filter_count);
		return -1;
	}

	if(filter == NULL) {
		printf("  filter mask is null\n");
		return -1;
	}

	tmp = down_filter;
	tmp[0] = filter_count;
	tmp++;
	memcpy(tmp, filter, sizeof(int)*filter_count*2);

	ret = ioctl(can_fd,  SET_FILTER,  down_filter);  
	if(ret < 0) {
		printf("  set can %d filter error \n", can_fd);
		return -1;	
	}

	return 0;
}

static int parse_frame(fpga_can_frame *pframe, sf_can_info *pcan_info, enum can_id_mode mode)
{
	unsigned long tmp_dw1, tmp_dw2; 
	unsigned long id;

	id = pframe->can_id;

	pcan_info->data_len = pframe->can_dlc >> 28;

	/* Change sifang CAN ID format to socketCAN ID format */
        if (id & XCAN_IDR_IDE_MASK) {
                /* The received frame is an Extended format frame */
                pframe->can_id = (id & XCAN_IDR_ID1_MASK) >> 3;
                pframe->can_id |= (id & XCAN_IDR_ID2_MASK) >>
                                XCAN_IDR_ID2_SHIFT;
                pframe->can_id |= CAN_EFF_FLAG;
                if (id & XCAN_IDR_RTR_MASK)
                        pframe->can_id |= CAN_RTR_FLAG;
        } else {
                /* The received frame is a standard format frame */
                pframe->can_id = (id & XCAN_IDR_ID1_MASK) >>
                                XCAN_IDR_ID1_SHIFT;
                if (id & XCAN_IDR_SRR_MASK)
                        pframe->can_id |= CAN_RTR_FLAG;
        }

	if(ID_MODE_STANDARD == mode)
	{
		pcan_info->des_addr = (pframe->can_id >> 6) & 0x1f;
		pcan_info->src_addr = (pframe->can_id) & 0x1f;

		if(FRAME_TYPE_MASK_STANDARD & pframe->can_id)
			pcan_info->type = FRAME_TYPE_TAIL;
		else
			pcan_info->type = FRAME_TYPE_REGULAR;
	}
	else if(ID_MODE_EXTENDED == mode)
	{
		pcan_info->des_addr = (pframe->can_id >> 21) & 0xff;
		pcan_info->src_addr = (pframe->can_id >> 13) & 0xff;
		pcan_info->seq = (pframe->can_id >> 5) & 0x7f;

		if(FRAME_TYPE_MASK_EXTENDED & pframe->can_id)
			pcan_info->type = FRAME_TYPE_TAIL;
		else
			pcan_info->type = FRAME_TYPE_REGULAR;
	}

	tmp_dw1 = ntohl(pframe->data1);
	tmp_dw2 = ntohl(pframe->data2);

	memcpy(pcan_info->data, &tmp_dw1, 4);
	if(pcan_info->data_len > 4) 
		memcpy(pcan_info->data+4, &tmp_dw2, pcan_info->data_len - 4);

	return 0;
}

static void construct_frame(fpga_can_frame *pframe, sf_can_info *pcan_info, enum can_id_mode mode)
{

	unsigned long id;
	unsigned long tmp_dw1, tmp_dw2;

	if(ID_MODE_STANDARD == mode)
	{
		pframe->can_id = ((pcan_info->des_addr & 0x1f) << 6) | (pcan_info->src_addr & 0x1f);

		if(FRAME_TYPE_REGULAR == pcan_info->type)
		{
			pframe->can_id &= (~FRAME_TYPE_MASK_STANDARD);

		}
		else if(FRAME_TYPE_TAIL == pcan_info->type)
		{
			pframe->can_id |= FRAME_TYPE_MASK_STANDARD;
		}

	}
	else if(ID_MODE_EXTENDED == mode)
	{
		pframe->can_id = ((pcan_info->des_addr & 0xff) << 21) | ((pcan_info->src_addr & 0xff) << 13) | ((pcan_info->seq & 0x7f) << 5);

		if(FRAME_TYPE_REGULAR == pcan_info->type)
		{
			pframe->can_id &= (~FRAME_TYPE_MASK_EXTENDED);

		}
		else if(FRAME_TYPE_TAIL == pcan_info->type)
		{
			pframe->can_id |= FRAME_TYPE_MASK_EXTENDED;
		}
		pframe->can_id |= CAN_EFF_FLAG; //must set extend id frame flag.
	}

	/* Watch carefully on the bit sequence */
	if ((pframe->can_id & CAN_EFF_FLAG) == 0) {
		/* Standard CAN ID format */
		id = ((pframe->can_id & CAN_SFF_MASK) << XCAN_IDR_ID1_SHIFT) &
			XCAN_IDR_ID1_MASK;

		if (pframe->can_id & CAN_RTR_FLAG)
			/* Extended frames remote TX request */
			id |= XCAN_IDR_SRR_MASK;
	} else {
		/* Extended CAN ID format */
		id = ((pframe->can_id & CAN_EFF_MASK) << XCAN_IDR_ID2_SHIFT) &
			XCAN_IDR_ID2_MASK;
		id |= (((pframe->can_id & CAN_EFF_MASK) >>
					(29-11)) <<
				XCAN_IDR_ID1_SHIFT) & XCAN_IDR_ID1_MASK;

		/* The substibute remote TX request bit should be "1"
		 * for extended frames as in the sifang CAN datasheet
		 */
		id |= XCAN_IDR_IDE_MASK | XCAN_IDR_SRR_MASK;

		if (pframe->can_id & CAN_RTR_FLAG)
			/* Extended frames remote TX request */
			id |= XCAN_IDR_RTR_MASK;
	}

	pframe->can_id = id;

	pframe->can_dlc = pcan_info->data_len;
	pframe->can_dlc = (pframe->can_dlc & 0xf) << XCAN_DLCR_DLC_SHIFT;

	tmp_dw1 = *((unsigned long *)(pcan_info->data));
	pframe->data1 = htonl(tmp_dw1);
	if (pcan_info->data_len > 4) {
		tmp_dw2 = *((unsigned long *)(pcan_info->data + 4));
		pframe->data2 = htonl(tmp_dw2);
	}
}

#define ZYNQ_CAN_MAX_PACKET 64
int sf_can_read_multi(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode, int count)
{
	fpga_can_frame frame[ZYNQ_CAN_MAX_PACKET];
	int ret, nbytes;
	int i;

	if(pcan_info == NULL)
		return -1;

	if(count > ZYNQ_CAN_MAX_PACKET)
		return -1;

	memset(frame, 0, sizeof(fpga_can_frame)*count);

	//nbytes = sf_fpgacan_read(can_fd, &frame, sizeof(fpga_can_frame));
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_wait(sem);
#else
	pthread_mutex_lock(&mylock);
#endif
#endif
	nbytes = sf_fpgacan_read(can_fd, frame, count);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_post(sem);
#else
	pthread_mutex_unlock(&mylock);
#endif
#endif
	if (nbytes <= 0)
		return -1;
	else {
		//printf("\nread return %d.\n", nbytes);
		//fflush(stdout);
		for(i = 0; i < nbytes; i ++) {
			parse_frame(frame + i, pcan_info + i, mode);
		}
		return nbytes;
	}
}

int sf_can_read(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode, enum can_read_flag flag)
{
	fpga_can_frame frame;
	int ret, nbytes;

	//nbytes = sf_fpgacan_read(can_fd, &frame, sizeof(fpga_can_frame));
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_wait(sem);
#else
	pthread_mutex_lock(&mylock);
#endif
#endif
	nbytes = sf_fpgacan_read(can_fd, &frame, 1);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_post(sem);
#else
	pthread_mutex_unlock(&mylock);
#endif
#endif
	if (nbytes <= 0)
		return -1;
	else {
		parse_frame(&frame, pcan_info, mode);
		return 0;
	}
}

int sf_can_write_multi(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode, int frame_number)
{
	int nbytes;
	fpga_can_frame frame[ZYNQ_CAN_MAX_PACKET];
	fpga_can_frame *pframe;
	sf_can_info *ptmp;
	int i;

	if((ID_MODE_STANDARD != mode) && (ID_MODE_EXTENDED != mode))
	{
		#ifdef DEBUG
		perror("wrong id mode");
		#endif
		return -1;
	}

	if(frame_number > ZYNQ_CAN_MAX_PACKET) {
		#ifdef DEBUG
		perror("wrong frame numbers");
		#endif
		return -1;
	}

	for(i = 0; i < frame_number; i++) {
		ptmp   = pcan_info + i;
		pframe = frame + i;
		if(ptmp == NULL) {
#ifdef DEBUG
			perror("pcan_info is null");
			return -1;
#endif
		}

		if((FRAME_TYPE_REGULAR != ptmp->type) && (FRAME_TYPE_TAIL != ptmp->type))
		{
#ifdef DEBUG
			perror("wrong type");
#endif
			return -1;
		}

		memset(pframe, 0, sizeof(fpga_can_frame));
		construct_frame(pframe, ptmp, mode);
#if 0
		printf("\nseq: %d lib send(%p) %08x %08x %08x %08x \n", 
			ptmp->seq,
			pframe,
			pframe->can_id,
			pframe->can_dlc,
			pframe->data1,
			pframe->data2);
#endif
	}

	#ifdef DEBUG
	printf("id:%08x\n", frame.can_id);
	printf("dlc:%d\n", frame.can_dlc);
	#endif

	/* send frame */
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_wait(sem);
#else
	pthread_mutex_lock(&mylock);
#endif
#endif

	nbytes = sf_fpgacan_write(can_fd, frame, frame_number);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_post(sem);
#else
	pthread_mutex_unlock(&mylock);
#endif
#endif

	if(nbytes <= 0) {
		#ifdef DEBUG
		perror("sf_fpgacan_write");
		#endif
		return -1;
	}
#if 0
	else {
		if(frame.can_id & CAN_STATE_BUS_OFF) {
			perror("bus-off");
			usleep(100000);
		}
	}
#endif


	return nbytes;
}


int sf_can_write(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode)
{
	int nbytes;
	fpga_can_frame frame;

	if((ID_MODE_STANDARD != mode) && (ID_MODE_EXTENDED != mode))
	{
		#ifdef DEBUG
		perror("wrong id mode");
		#endif
		return -1;
	}
	if((FRAME_TYPE_REGULAR != pcan_info->type) && (FRAME_TYPE_TAIL != pcan_info->type))
	{
		#ifdef DEBUG
		perror("wrong type");
		#endif
		return -1;
	}

	memset(&frame, 0, sizeof(frame));
	construct_frame(&frame, pcan_info, mode);

	#ifdef DEBUG
	printf("id:%08x\n", frame.can_id);
	printf("dlc:%d\n", frame.can_dlc);
	#endif

	/* send frame */
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_wait(sem);
#else
	pthread_mutex_lock(&mylock);
#endif
#endif
	nbytes = sf_fpgacan_write(can_fd, &frame, 1);
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	sem_post(sem);
#else
	pthread_mutex_unlock(&mylock);
#endif
#endif
	if(nbytes <= 0) {
		#ifdef DEBUG
		perror("sf_fpgacan_write");
		#endif
		return -1;
	}
#if 0
	else {
		if(frame.can_id & CAN_STATE_BUS_OFF) {
			perror("bus-off");
			usleep(100000);
		}
	}
#endif


	return 0;
}

int sf_can_close(int can_fd)
{
	int i;

	for(i = 0; i < FPGACAN_OPEN_MAX_VALUE; i ++) {
		if(fpgacan_lib_dev[i].used_flag == 0)
			continue;
		else {
			if(can_fd == fpgacan_lib_dev[i].fd) {
				munmap(fpgacan_lib_dev[i].data_buf, fpgacan_lib_dev[i].map_size);
				fpgacan_lib_dev[i].used_flag = 0;
				break;
			} 
		}
	}

	fpgacan_open_count--;
#ifdef  SF_FPGACAN_USE_MUTEX
#ifdef SF_FPGACAN_LIB_PROCESS_MUX
	if(fpgacan_open_count == 0) {
		sem_unlink(FPGACAN_LIB_SEMNAME);
		if(sem)
			sem_close(sem);
	}
#endif
#endif

	return close(can_fd);
}

