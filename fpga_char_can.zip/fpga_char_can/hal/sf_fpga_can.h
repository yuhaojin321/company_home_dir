#ifndef SF_SOCKET_CAN_H
#define SF_SOCKET_CAN_H

#ifdef __cplusplus
extern "C" {
#endif



//数据类型
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

//ID模式
enum can_id_mode
{
	ID_MODE_STANDARD = 0,  	//标准ID模式11�
	ID_MODE_EXTENDED, 		//扩展ID模式29�
	ID_MODE_COUNT
};

enum can_ioctl_mode
{
	SET_SPEED = 0x11,  	//标准ID模式11�
	SET_LOOPBACK = 0x22, 		//扩展ID模式29�
	SET_START = 0x33,
	SET_FILTER = 0x44
};

enum can_speed
{
	SPEED_1M = 1000000,  	
	SPEED_200K = 200000 		
};

//帧类�
enum can_frame_type
{
	FRAME_TYPE_REGULAR = 0, //普通帧
	FRAME_TYPE_TAIL, 		//尾帧
	FRAME_TYPE_COUNT
};

//读取方式
enum can_read_flag
{
	READ_WAIT = 0, 			//阻塞模式
	READ_NOWAIT, 			//非阻塞模�
	READ_FLAG_COUNT
};

typedef struct
{
	uint8 	src_addr; 			//源地址
	uint8 	des_addr; 			//目的地址
	uint8 	data_len; 			//有效数据长度
	uint8 	data[8]; 			//有效数据
	uint8 	seq; 				//帧序�? 仅扩展模式有�
	enum can_frame_type type;
	uint8 	bak[3];
} sf_can_info;


/*
功能：启动接口�
参数�
 	name, 接口名称�
返回值：
	0, 表示成功�
	-1, 表示失败。错误原因打印在调试信息中�
 */
int sf_can_start(const char *name);


/*
功能：停止接口�
参数�
 	name, 接口名称�
返回值：
	0, 表示成功�
	-1, 表示失败。错误原因打印在调试信息中�
 */
int sf_can_stop(const char *name);

/*
功能：打开接口�
参数�
 	name, 接口名称�
	flag, 操作标志，目前设置为0�
返回值：
	can接口的文件描述符�
 */
int sf_can_open(const char *name, int speed);

/*
功能：关闭接口�
参数�
 	name, 接口名称�
返回值：
	0, 表示成功�
	-1, 表示失败。错误原因打印在调试信息中�
 */
int sf_can_close(int can_fd);

/*
功能：接收数据，每次调用读取一帧�
参数�
 	can_fd，can接口文件描述符�
	pcan_info, can网帧数据结构体指针�
	mode, ID模式, 11位或29位�
	flag，读取模式，阻塞或者非阻塞�
返回值：
	0, 表示成功�
	-1, 表示失败。错误原因打印在调试信息中�
 */
int sf_can_read(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode, enum can_read_flag flag);

/* reference the sf_can_read, just diff at last parameter, count means reading how many packet once time */
/* the return value is the can frames read from the can port */
int sf_can_read_multi(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode, int count);

/*
功能：发送数据，每次调用发送一帧�
参数�
 	can_fd，can接口文件描述符�
	pcan_info, can网帧数据结构体指针�
	mode, ID模式, 11位或29位�
返回值：
	0, 表示成功�
	-1, 表示失败。错误原因打印在调试信息中�
 */
int sf_can_write(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode);
/* reference the sf_can_write, just diff at last parameter, count means reading how many packet once time */
/* the return value is the can frames write to the buffers */
int sf_can_write_multi(int can_fd, sf_can_info *pcan_info, enum can_id_mode mode, int frame_number);

/* can_fd: can device id, get from sf_can_open
   filter_count: filter count, max value is 4
   filter: mask and id's value, format:
       mask1, id1, mask2, id2, ,,,,
   return 0: success, -1 failed
       */
int sf_can_set_filter(int can_fd, int filter_count, int *filter);

#ifdef __cplusplus
} /* endof extern "C" */
#endif

#endif
