#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <pthread.h>
#include <signal.h>
#include <sched.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <linux/unistd.h>
#include <assert.h>

#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <sys/mman.h>
//#include "sf_can.h"
#include "../hal/sf_fpga_can.h"

#define CAN_DEVICE0 "/dev/fpgacan0"
#define CAN_DEVICE1 "/dev/fpgacan1"
#define CAN_DEVICE2 "/dev/fpgacan2"

char CAN_RUNNING[3][20] = {CAN_DEVICE0, CAN_DEVICE1, CAN_DEVICE2};

#define RATE_200K 	200000
#define RATE_1M 	1000000

int main_loop = 1;
int can_fd = -1;
int flag;
int debug_flag = 1;
int sf_can_send_flag = 0;

#define CANAPP_USE_THREAD 
//#undef CANAPP_USE_THREAD 

void signal_handler(int sig)
{
	main_loop = 0;
	printf("SIGINT SIGTERM:My test received sig:%d, main_loop=%d\n", sig, main_loop);
	return ;
}

static char get_sum(char *data,int length)
{
	char sum=0;
	int i=0;
	for(i=0;i<length;i++)
		sum += *(data+i);
	return sum;
}

void dump_packet(sf_can_info *info, int serial_no)
{
	int i;

	if(info == NULL)
		return;

	printf("\n");
	printf("(0x%08d): s 0x%02x d 0x%02x len %d seq %d type %d\n,", serial_no, info->src_addr, info->des_addr, 
	info->data_len, 
	info->seq, 				
	info->type); 
	for(i = 0;i < info->data_len;i++) {
		printf("0x%02x ", info->data[i]);
	}
	printf("\n");
}

#define CAN_TEST_RX_FRAME 8
typedef struct __can_test_rx_frame {
	char src_addr;
	char dst_addr;
	short frm_no;
	int test_count;
	int frame_count;
	int start_count;
	int dis_count;
	int err_count;
	int ret;
}can_test_rx_frame;

typedef struct __can_test_rx_value_frame {
	int addr_count;
	can_test_rx_frame addr[CAN_TEST_RX_FRAME];
}can_test_value_frame;

#ifdef CANAPP_USE_THREAD 
void *can_rx_thread(void *param)
{
	int read_count = 0;
	sf_can_info rx_info[64];
	int print_count = 0;
	int new_addr, i, j;
	can_test_value_frame r_frame;
	int total_f = 0, total_r = 0, total_e = 0;
	struct timeval tv;	

	memset(&r_frame, 0, sizeof(can_test_value_frame));

	for(i = 0; i < CAN_TEST_RX_FRAME; i ++)
		r_frame.addr[i].ret = 1;

	while(main_loop == 2)
	 {

		memset(&rx_info, 0, sizeof(sf_can_info)*64);
		read_count = sf_can_read_multi(can_fd, rx_info, ID_MODE_EXTENDED, 32);
		if(read_count > 0) {
			for(i = 0; i < read_count; i ++) {
				if(debug_flag == 1)
					dump_packet(&rx_info[i], 0);
			}
		}

		usleep(100000);
	}
	printf("exit_thread.\n");
	fflush(stdout);
	return;
}
#endif

#define CAN_TEST_SEND_COUNT 64 
void main(int argc, char *argv[])
{
	int ret, i, j;
	sf_can_info info[CAN_TEST_SEND_COUNT];
	sf_can_info *pinfo;
	uint8 *RptBuf;
	int count = 0, send_count = 0;
	int interval = 1000;
	int send_interval, time0, time1;
	char name[100];
#ifdef CANAPP_USE_THREAD 
	pthread_t  thread_rx;
#endif
	int *f_tmp;
	unsigned char test_addr[4][2] = {(0x00, 0x31), (0x00,0x39),(0x00, 0x33), (0x40, 0x78)};

	signal(SIGINT, signal_handler);

	if(argc >= 2) {
		memcpy(name, CAN_RUNNING[atoi(argv[1])], sizeof(CAN_RUNNING[atoi(argv[1])]));
	}
	else {
		memcpy(name, CAN_RUNNING[0], sizeof(CAN_RUNNING[0]));
	}

	if(argc >= 3) {
		send_interval = atoi(argv[2]);
	}
	else 
		send_interval = 5000;
	
	if(argc >= 4) 
		main_loop = atoi(argv[3]);
	
	if(main_loop == 1) {
		printf("TX Function run!\n");
	} else if(main_loop == 2) {
		printf("RX Function run!\n");
	} else {
		printf("Function Flag error!\n");
		return ;
	}
	
	printf("Using dev %s.send interval %d us\n", name, send_interval);
	fflush(stdout);
	
	can_fd = sf_can_open(name, RATE_1M);
	if(can_fd < 0) {
		printf("Open dev %s failed.\n", name);
		return;
	}
		
#ifdef CANAPP_USE_THREAD 
	if(pthread_create(&thread_rx, NULL, can_rx_thread, NULL) != 0) {
		printf("(%s): thread start failed.",__FUNCTION__);
		goto err_out;
	}
#endif
#ifdef CANAPP_USE_THREAD 
	pthread_join(thread_rx, NULL);
#endif
	do{
		for(i = 0; i < 4; i ++) 
		{
			pinfo = info + i*16;
			//pinfo = info;
			for(count = 0; count < 16; count ++, pinfo++)
			 {
				RptBuf = pinfo->data;
				pinfo->src_addr = test_addr[i][0];
				pinfo->des_addr = test_addr[i][1];
				pinfo->data_len = 8;
				pinfo->seq = count;
#if 0
				if(count == 15)
					info.type = FRAME_TYPE_TAIL;
				else
					info.type = 0;
#else 
				pinfo->type = FRAME_TYPE_TAIL;
#endif

				if(count == 0)
					RptBuf[0] = 0x06;
				else
					RptBuf[0] = 0;

				RptBuf[0] = 0x01;
				RptBuf[1] = 0x02;
				RptBuf[2] = 0x03;
				RptBuf[3] = 0x04;
				RptBuf[4] = 0x05;
				RptBuf[5] = 0x06;
				RptBuf[6] = 0x07;
				if(count == 15)
					RptBuf[7] = 6;
				else 
					RptBuf[7] = 0;
				RptBuf[7] = 0x08;
			}
		}
SEND_AGAIN:
			if (main_loop == 1) {
				ret = sf_can_write_multi(can_fd, info, ID_MODE_EXTENDED, CAN_TEST_SEND_COUNT);
				//ret = sf_can_write(can_fd, info, ID_MODE_EXTENDED);
				if(ret < 0) {
					printf("write failed ret %d, sendcount %d.\n", ret, send_count);
					fflush(stdout);
					usleep(200);
					goto SEND_AGAIN;
				}
				else if(ret != CAN_TEST_SEND_COUNT) {
		//			printf("Can't write all frame to drivers ret %d.\n", ret);
		//			fflush(stdout);
				}
			}
//			sf_can_reset(can_fd);
		send_count ++;
		usleep(send_interval);
	}while(main_loop);

err_out:
		

	ret = sf_can_close(can_fd);
	if(ret < 0) {
		printf("close error\n");
		return;
	}
}
