#ifndef _FPGA_ETHERNET_AMP_CFG_H_
#define _FPGA_ETHERNET_AMP_CFG_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

#define ACP_CONFIG_MAGIC 0xA5A5A5A5
#define AMP_ACP_VAL_CFG_LEN (18*4) 
#define AMP_ACP_CFG_LEN (0x200) 
#define MAX_RX_ACP_NUM	 16
#define MAX_TX_ACP_NUM	 16
#define MAX_ACP_NUM	 	 (MAX_RX_ACP_NUM+MAX_TX_ACP_NUM)

#define ACP_ATTRIB_ETH_TYP 		0x00010000
#define ACP_ATTRIB_CORE1   		0x00000100
#define ACP_ATTRIB_USED    		0x000000AA
#define ACP_ATTRIB_CORE1_ETH			(ACP_ATTRIB_ETH_TYP|ACP_ATTRIB_CORE1|ACP_ATTRIB_USED)
#define ACP_ATTRIB_CORE1_UNKNOW_TYPE					   (ACP_ATTRIB_CORE1|ACP_ATTRIB_USED)

typedef struct amp_acp_cfg_stru{	
	unsigned long pipe_no;
	unsigned long val;
	unsigned long attrib;
	unsigned long port_msk;
	unsigned long func_sel;
	unsigned long ethtype_num;
	unsigned long ethtype[8];
	unsigned long val_ext;
	unsigned long data_addr;
	unsigned long data_len;
	unsigned long bd_addr;
	unsigned long bd_len;
}amp_acp_cfg_t;

/// the return value is a point to structure array, which has MAX_ACP_NUM members
/// amp_acp_cfg_t xxx[MAX_ACP_NUM], return &xxx[0]
amp_acp_cfg_t * amp_get_pipe_cfg( void );

#endif /* _FPGA_ETHERNET_GP_H_ */