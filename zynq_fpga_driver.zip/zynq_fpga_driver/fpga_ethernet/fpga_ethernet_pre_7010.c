#ifndef _FPGA_ETHERNET_PRE_7010_C_
#define _FPGA_ETHERNET_PRE_7010_C_

#include <linux/kernel.h>	/*printk*/

#include "../inc/sf_fpga_gp.h"
#include "../inc/sf_fpga_acp.h"

#include "fpga_ethernet_gp.h"
#include "fpga_ethernet_pre_7010.h"
#include "fpga_ethernet_acp.h"


static int fpga_pre_proc_conf_7010(uint32 pipe_mask_index)
{
	static uint32 pre_lite_pipe_no = 0;
	int rs = RTN_ERR;
	uint32 gp_pre_7010_remap = 0;	
	uint32 port_mask = 0;
	uint32 pre_base_addr = 0;

	switch(pre_lite_pipe_no) {
		case 0: pre_base_addr=PRE_7010_CHAN0_BASE;	break;
		case 1: pre_base_addr=PRE_7010_CHAN1_BASE;	break;
		case 2: pre_base_addr=PRE_7010_CHAN2_BASE;	break;
		default:
			return(rs);
	}
	
	port_mask = get_rx_pipe_ports_mask(pipe_mask_index);

	gp_pre_7010_remap = get_gp_pre_7010_remap();
	if(gp_pre_7010_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}

	REG_WR(gp_pre_7010_remap+pre_base_addr+PRE_7010_CHAN_EN_OFFSET, port_mask);
	REG_WR(gp_pre_7010_remap+pre_base_addr+PRE_7010_CHAN_CTRL_OFFSET, PRE_7010_CTRL_CHAN_EN);	
	REG_WR(gp_pre_7010_remap+pre_base_addr+PRE_7010_CHAN_ETH_TPYE0_OFFSET, 0);	
	REG_WR(gp_pre_7010_remap+pre_base_addr+PRE_7010_CHAN_ETH_TPYE1_OFFSET, 0);
	REG_WR(gp_pre_7010_remap+pre_base_addr+PRE_7010_CHAN_ETH_TPYE2_OFFSET, 0);
	REG_WR(gp_pre_7010_remap+pre_base_addr+PRE_7010_CHAN_ETH_TPYE3_OFFSET, 0);

	printk("%s(%d): pre_base_addr:0x%08x port_mask:0x%08x pipe_mask_index:0x%08x\n"
			, __FUNCTION__
			, __LINE__
			, pre_base_addr
			, port_mask
			, pipe_mask_index);

	pre_lite_pipe_no++;
	rs = RTN_OK;
	return(rs);
}


int fpga_ethernet_pre_init_7010(uint32 rx_pipe_mask)
{
	int rs = RTN_ERR;
	int pipe_no = 0;

	printk("7010 PRE MODULE INIT rx_pipe_mask:0x%08x!\n", rx_pipe_mask);

	for(pipe_no=0; pipe_no<ACP_PIPE_MAX; pipe_no++) {

		if((rx_pipe_mask&(0x01<<pipe_no)) != 0) {
			fpga_pre_proc_conf_7010(pipe_no);
		}
	}

	return(rs);
}

#endif /* _FPGA_ETHERNET_PRE_7010_C_ */
