#ifndef _FPGA_ETHERNET_PRE_C_
#define _FPGA_ETHERNET_PRE_C_

#include <linux/kernel.h>	/*printk*/

#include "../inc/sf_fpga_gp.h"
#include "../inc/sf_fpga_acp.h"

#include "fpga_ethernet_gp.h"
#include "fpga_ethernet_pre.h"
#include "fpga_ethernet_acp.h"

static int xcast_enable = 0;
static int xcast_frame = 2;

static int bc_filter_enable = 0;
static uint32 bc_twind = 100000000;

int show_fpga_pre_conf(char *buf)
{	
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;
	
	rs = sprintf(ps, "\n#########FPGA PRE CONF#########\n");		
	len = len + rs;
	ps = ps + rs;

	rs = sprintf(ps, "%s %s xcast_frame:%d bc_twind:%d\n"
					, xcast_enable?"xcast_enable":"xcast_disable"
					, bc_filter_enable?"bc_filter_enable":"bc_filter_disable"
					, xcast_frame*1000
					, 1000000000/bc_twind);		
	len = len + rs;
	ps = ps + rs;

		
	return(len);
}


static int fpga_pre_proc_enable(void)
{
	int rs = RTN_ERR;
	uint32 gp_pre_remap = 0;
	
	gp_pre_remap = get_gp_pre_remap();
	if(gp_pre_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	REG_WR(gp_pre_remap+PRE_PROC_EN,0x01);
	REG_WR(gp_pre_remap+PRE_PROC_RST,0x01);
	
	rs = RTN_OK;
	return(rs);
}

static int fpga_pre_proc_reset(void)
{
	int rs = RTN_ERR;
	uint32 gp_pre_remap = 0;
	
	gp_pre_remap = get_gp_pre_remap();
	if(gp_pre_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	REG_WR(gp_pre_remap+PRE_PROC_RST,0x00);
	REG_WR(gp_pre_remap+PRE_PROC_RST,0x01);
	
	rs = RTN_OK;
	return(rs);
}

static int fpga_pre_xcast_conf(void)
{
	uint32 gp_pre_remap = 0;

	if(xcast_enable == 0)
		return(RTN_OK);

	gp_pre_remap = get_gp_pre_remap();
	if(gp_pre_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!\n"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}

	REG_WR(PRE_PROC_FLOW_CTRL_EN_BC, 0x01);
	REG_WR(PRE_PROC_FLOW_CTRL_PERIOD_BC, 1);	/* 1ms */
	REG_WR(PRE_PROC_FLOW_CTRL_NUM_BC, xcast_frame);		/* 2 frame*/

	return(RTN_OK);	
}

/* same boardcase frame 10frame/s */
static int fpga_pre_boardcast_conf(void)
{
	uint32 gp_pre_remap = 0;

	if(bc_filter_enable == 0)
		return(RTN_OK);

	gp_pre_remap = get_gp_pre_remap();
	if(gp_pre_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!\n"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	REG_WR(gp_pre_remap+PRE_PROC_BC_NSTORM_CTRL_EN, 0x01);
	REG_WR(gp_pre_remap+PRE_PROC_BC_NSTORM_CTRL_TWIND,bc_twind);

	return(RTN_OK);
}

static int fpga_pre_proc_conf(uint32 pipe_no)
{
	int rs = RTN_ERR;
	uint32 gp_pre_remap = 0;	
	uint8 logic_id = 0;
	uint32 port_mask = 0;
	
	
	gp_pre_remap = get_gp_pre_remap();
	if(gp_pre_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!\n"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
		
	logic_id = get_pipe_logic_ID(pipe_no);
	
	port_mask = get_rx_pipe_ports_mask(pipe_no);
	
	REG_WR(gp_pre_remap+PRE_PROC_EXPORT_CHAN, logic_id);
	REG_WR(gp_pre_remap+PRE_PROC_PORT_MASK, port_mask);
	
	REG_WR(gp_pre_remap+PRE_PROC_FUNC_SEL, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE_NUM, 0);
	
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE0, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE1, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE2, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE3, 0);
	
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE4, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE5, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE6, 0);
	REG_WR(gp_pre_remap+PRE_PROC_ETHTYPE7, 0);
	
	printk("%s(%d): pipe_%d:logic_id 0x%08x port_mask 0x%08x\n"
			, __FUNCTION__
			, __LINE__
			, pipe_no
			, logic_id
			, port_mask);
	rs = RTN_OK;
	return(rs);
}

int fpga_ethernet_pre_init(uint32 rx_pipe_mask)
{
	int rs = RTN_ERR;
	uint32 gp_pre_remap = 0;
	int pipe_no = 0;

	printk("7015 PRE MODULE INIT rx_pipe_mask:0x%08x!\n",rx_pipe_mask);

	gp_pre_remap = get_gp_pre_remap();
	if(gp_pre_remap == (uint32)NULL) {
		printk("%s(%d): GP PRE ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}

	fpga_pre_proc_reset();
	REG_WR(gp_pre_remap+PRE_PROC_CONFIG, PRE_PROC_CFG_START);
	fpga_pre_xcast_conf();
	fpga_pre_boardcast_conf();

	for(pipe_no=0; pipe_no<ACP_PIPE_MAX; pipe_no++) {
		if((rx_pipe_mask&(0x01<<pipe_no)) != 0)
			fpga_pre_proc_conf(pipe_no);
	}

	REG_WR(gp_pre_remap+PRE_PROC_CONFIG, PRE_PROC_CFG_END);
	fpga_pre_proc_enable();
	rs = RTN_OK;
	return(rs);
}

#endif /* _FPGA_ETHERNET_PRE_C_ */
