#ifndef _FPGA_ETHERNET_MAC_H_
#define _FPGA_ETHERNET_MAC_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

typedef enum {
	MAC_REG_FUNC_EN = 0x00,
	MAC_REG_RST_N	= 0x04,
	MAC_REG_RD_DATA	= 0x08,
	MAC_REG_WR_DATA	= 0x0C,
	MAC_REG_RD_ADDR	= 0x10,
	MAC_REG_WR_ADDR	= 0x14,
} _MAC_REG_OFFSET;

typedef enum {
	XILINX_MAC_RECEIVER_CONF	= 0x404,
	XILINX_MAC_MDIO_SET_WORD	= 0x500,
	XILINX_MAC_MDIO_CTRL_WORD	= 0x504,
	XILINX_MAC_MDIO_WR_DATA		= 0x508,
	XILINX_MAC_MDIO_RD_DATA		= 0x50c,
	
	XILINX_MAC_UNICAST_WORD0	= 0x700,
	XILINX_MAC_UNICAST_WORD1	= 0x704,
	XILINX_MAC_FILTER_CTRL		= 0x708,
	XILINX_MAC_FILTER_ENABLE	= 0x70C,
	XILINX_MAC_FILTER_DATA0		= 0x710,
	XILINX_MAC_FILTER_DATA1		= 0x714,
	XILINX_MAC_FILTER_MASK0		= 0x750,
	XILINX_MAC_FILTER_MASK1		= 0x754,
} _MAC_IP_OFFSET;

#define MAC_MDIO_CTRL_READY_MASK		0x00000080
#define MAC_MDIO_CTRL_INIT_MASK			0x00000800
#define MAC_MDIO_CTRL_OP_WR_MASK		0x00004000
#define MAC_MDIO_CTRL_OP_RD_MASK		0x00008000

#define MAC_MDIO_CTRL_REG_ADDR_SHIFT	16
#define MAC_MDIO_CTRL_PHY_ADDR_SHIFT	24
#define XILINX_MAC_MULTI_ALL		(0xFFFFFFFF)

extern int mdio_init(uint32 mac_no);
extern int phy_reg_rd(uint32 mac_no, uint32 phy_addr, uint32 reg_addr,uint32 *pData);
extern int phy_reg_wr(uint32 mac_no, uint32 phy_addr, uint32 reg_addr,uint32 pData);
extern int mac_addr_set(uint32 mac_no, void *addr, int is_promisc);
extern int mac_promisc_set(uint32 mac_no, int is_enable);
extern int mac_multi_set(uint32 mac_no, u8 *addr, u8 *mask, int filter_flag);
extern int mac_multi_disable(uint32 mac_no);
extern int mac_disable_LT_check(uint32 mac_no);

#endif /* _FPGA_ETHERNET_MAC_H_ */