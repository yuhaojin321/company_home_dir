#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xc398b520, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x337d701e, __VMLINUX_SYMBOL_STR(acp_pipe_write) },
	{ 0xadf42bd5, __VMLINUX_SYMBOL_STR(__request_region) },
	{ 0xf9afc1f1, __VMLINUX_SYMBOL_STR(class_remove_file_ns) },
	{ 0xe36fe2a1, __VMLINUX_SYMBOL_STR(acp_pipe_tx_init) },
	{ 0x27864d57, __VMLINUX_SYMBOL_STR(memparse) },
	{ 0x2e5810c6, __VMLINUX_SYMBOL_STR(__aeabi_unwind_cpp_pr1) },
	{ 0x788fe103, __VMLINUX_SYMBOL_STR(iomem_resource) },
	{ 0xe9bd9929, __VMLINUX_SYMBOL_STR(acp_pipe_rx_init) },
	{ 0x55c46f74, __VMLINUX_SYMBOL_STR(acp_pipe_read_processed) },
	{ 0xccd7307b, __VMLINUX_SYMBOL_STR(get_gp_mac_remap) },
	{ 0x7840b42c, __VMLINUX_SYMBOL_STR(hrtimer_cancel) },
	{ 0xf7802486, __VMLINUX_SYMBOL_STR(__aeabi_uidivmod) },
	{ 0x22e53be5, __VMLINUX_SYMBOL_STR(dcc_inner_data_write) },
	{ 0xbc3a4694, __VMLINUX_SYMBOL_STR(acp_pipe_unxmit_port_info) },
	{ 0x61d00e9b, __VMLINUX_SYMBOL_STR(get_gp_pre_remap) },
	{ 0x91715312, __VMLINUX_SYMBOL_STR(sprintf) },
	{ 0x9eb6e640, __VMLINUX_SYMBOL_STR(netif_napi_del) },
	{ 0x675b8b44, __VMLINUX_SYMBOL_STR(__netdev_alloc_skb) },
	{ 0x694dd8c1, __VMLINUX_SYMBOL_STR(netif_rx) },
	{ 0xb56117f, __VMLINUX_SYMBOL_STR(of_find_node_by_path) },
	{ 0xe707d823, __VMLINUX_SYMBOL_STR(__aeabi_uidiv) },
	{ 0x80a65392, __VMLINUX_SYMBOL_STR(tasklet_hrtimer_init) },
	{ 0xfa2a45e, __VMLINUX_SYMBOL_STR(__memzero) },
	{ 0x244a2dab, __VMLINUX_SYMBOL_STR(netif_rx_ni) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x71c90087, __VMLINUX_SYMBOL_STR(memcmp) },
	{ 0x58dd61cc, __VMLINUX_SYMBOL_STR(free_netdev) },
	{ 0x68b4f6af, __VMLINUX_SYMBOL_STR(register_netdev) },
	{ 0x97deeeb7, __VMLINUX_SYMBOL_STR(netif_napi_add) },
	{ 0x82072614, __VMLINUX_SYMBOL_STR(tasklet_kill) },
	{ 0xc2165d85, __VMLINUX_SYMBOL_STR(__arm_iounmap) },
	{ 0x94e1823c, __VMLINUX_SYMBOL_STR(hrtimer_start) },
	{ 0x9c995954, __VMLINUX_SYMBOL_STR(eth_type_trans) },
	{ 0x5f9f36a3, __VMLINUX_SYMBOL_STR(class_create_file_ns) },
	{ 0x260cf8f8, __VMLINUX_SYMBOL_STR(of_get_property) },
	{ 0x9bce482f, __VMLINUX_SYMBOL_STR(__release_region) },
	{ 0x42bc8367, __VMLINUX_SYMBOL_STR(ether_setup) },
	{ 0x9d669763, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0x503cb47a, __VMLINUX_SYMBOL_STR(class_destroy) },
	{ 0x49dd0c6a, __VMLINUX_SYMBOL_STR(dcc_inner_data_read) },
	{ 0xaaafcb00, __VMLINUX_SYMBOL_STR(get_gp_pre_7010_remap) },
	{ 0xfb961d14, __VMLINUX_SYMBOL_STR(__arm_ioremap) },
	{ 0xefd6cf06, __VMLINUX_SYMBOL_STR(__aeabi_unwind_cpp_pr0) },
	{ 0xe9e2eb80, __VMLINUX_SYMBOL_STR(consume_skb) },
	{ 0x49ebacbd, __VMLINUX_SYMBOL_STR(_clear_bit) },
	{ 0x15ed31cb, __VMLINUX_SYMBOL_STR(skb_put) },
	{ 0xac8f37b2, __VMLINUX_SYMBOL_STR(outer_cache) },
	{ 0xce791663, __VMLINUX_SYMBOL_STR(acp_pipe_read) },
	{ 0x72d1c38a, __VMLINUX_SYMBOL_STR(__class_create) },
	{ 0x61de1f43, __VMLINUX_SYMBOL_STR(get_gp_global_remap) },
	{ 0x9c89aec, __VMLINUX_SYMBOL_STR(alloc_etherdev_mqs) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=acp_pipe_module_amp,gp_base_module_amp,dcc_drv_512";

