#ifndef _FPGA_ETHERNET_AMP_CFG_C_
#define _FPGA_ETHERNET_AMP_CFG_C_

#include <linux/kernel.h>	/*printk*/
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/io.h>

#include "../inc/sf_fpga_gp.h"
#include "fpga_ethernet_main.h"
#include "fpga_ethernet_gp.h"
#include "fpga_ethernet_amp_cfg.h"

#define OF_DCC_MEM "dcc-mem"
amp_acp_cfg_t g_amp_acp_cfg[MAX_ACP_NUM];
uint8  g_amp_acp_used[MAX_ACP_NUM];

static fpga_ethernet_port_t g_port_attr_frm_amp[FPGA_PORT_MAX];
uint8 g_port_cnt=0;
uint8 g_reorder_port[FPGA_PORT_MAX];

int of_get_dcc_mem(const char *property, unsigned long *start, unsigned long *size)
{
	const char *name = NULL;
	char *retstr;
	unsigned long value;
	struct device_node *of_chosen;

	of_chosen = of_find_node_by_path("/chosen");
	if(of_chosen)
		name = of_get_property(of_chosen, property, NULL);
	else{
		pr_err("%s(%d) there is no of_chosen node\n", __FUNCTION__, __LINE__);
		return RTN_ERR;
	}

	value = memparse(name, &retstr);
	*start = value;
	pr_info("%s(%d) dcc-mem-start: %lx\n", __FUNCTION__, __LINE__, value);

	while(*retstr != '\0' && (*retstr == ',' || *retstr == ' '))
		retstr++;
	if(retstr == NULL)
		return RTN_ERR;
	name = retstr;

	value = memparse(name, &retstr);
	*size = value;
	pr_info("%s(%d) dcc-mem-size: %lx\n", __FUNCTION__, __LINE__, value);

	return RTN_OK;
}


int amp_get_cfg_mem(void)
{
	int result;
	unsigned long dcc_shr_mem_sz, dcc_shr_mem_base;
	unsigned long acp_spe_mem_base;
	int i;
	unsigned long val_flg;
		
	result = of_get_dcc_mem(OF_DCC_MEM, &dcc_shr_mem_base, &dcc_shr_mem_sz);
	if( result == RTN_ERR ){
		printk("%s(%d): special share_mem_base ioremap failed.\n"
				, __FUNCTION__
				, __LINE__);
		return RTN_ERR;
	}

	acp_spe_mem_base = (unsigned long)ioremap_cache(dcc_shr_mem_base + dcc_shr_mem_sz - 0x100000, 0x100000);
	if(acp_spe_mem_base == 0)  
		printk("%s(%d): special acp_spe_mem_base ioremap failed.\n"
				, __FUNCTION__
				, __LINE__);

	printk("special acp_spe_mem_base(0x%08lx) ioremap to 0x%08lx.\n"
			, dcc_shr_mem_base + dcc_shr_mem_sz - 0x100000
			, acp_spe_mem_base);

	val_flg = 0;
	for(i = 0; i < MAX_ACP_NUM; i ++) {
		val_flg = *(unsigned long *)(acp_spe_mem_base + 0x200*i);
		if( val_flg == ACP_CONFIG_MAGIC )
			break;
	}
	if( i == MAX_ACP_NUM )
		return RTN_ERR;

	return acp_spe_mem_base;
}


int amp_proc_cfg_mem(void)
{
	unsigned long acp_spe_mem_base;
	unsigned char ch;

	acp_spe_mem_base = amp_get_cfg_mem();
	if( acp_spe_mem_base == RTN_ERR ){
		printk("%s(%d): get amp cfg memory error.\n"
				, __FUNCTION__
				, __LINE__);
		return RTN_ERR;
	}

	for( ch=0; ch<MAX_ACP_NUM; ch++ ){
		g_amp_acp_cfg[ch].pipe_no = ch;
		memcpy((unsigned char*)(&(g_amp_acp_cfg[ch]))+4,(unsigned char*)(acp_spe_mem_base+ch*AMP_ACP_CFG_LEN),AMP_ACP_VAL_CFG_LEN);	// 4 is pipe_no offset
	}

	/*release iomem*/
	iounmap((void *)acp_spe_mem_base);
	return RTN_OK;	
}

void amp_port_reorder(void)
{
	unsigned char port;

	// get phy attribution
	for(port=0;port<FPGA_PORT_MAX;port++ ){	
		g_port_attr_frm_amp[port].port_no = port;
		get_port_attr(&g_port_attr_frm_amp[port]);
	}	

	g_port_cnt = 0;
	// mac0 always exist
	g_reorder_port[g_port_cnt++] = 0;	
	
	// find GE
	for(port=1;port<FPGA_PORT_MAX;port++ ){
		if( (g_port_attr_frm_amp[port].is_valid==0x0F)&&(g_port_attr_frm_amp[port].phy_type==PHY_GE) )
			g_reorder_port[g_port_cnt++] = port;
	}	
	
	// other 100M mac
	for(port=1;port<FPGA_PORT_MAX;port++ ){
		if( (g_port_attr_frm_amp[port].is_valid==0x0F)&&(g_port_attr_frm_amp[port].phy_type!=PHY_GE) )
			g_reorder_port[g_port_cnt++] = port;
	}	

}
	
// output to other module
amp_acp_cfg_t * amp_get_pipe_cfg( void )
{
	unsigned char port_ind;
	unsigned char port_no;
	unsigned char acp_ch;
	unsigned char lst_val_acp;
	
	if( amp_proc_cfg_mem() == RTN_ERR )
		return NULL;

	// allocate tx pipe for port,mac0>GE>other_100M
	amp_port_reorder();
	memset( g_amp_acp_used,0,sizeof(g_amp_acp_used));
	for(port_ind=0;port_ind<g_port_cnt;port_ind++ ){
		port_no = g_reorder_port[port_ind]; 
		for( acp_ch=MAX_TX_ACP_NUM;acp_ch<MAX_ACP_NUM;acp_ch++ ){
			if( g_amp_acp_cfg[acp_ch].val !=ACP_CONFIG_MAGIC )
				continue;
			if( (g_amp_acp_cfg[acp_ch].attrib!=ACP_ATTRIB_CORE1_ETH ) && (g_amp_acp_cfg[acp_ch].attrib!=ACP_ATTRIB_CORE1_UNKNOW_TYPE) )
				continue;			
			if( g_amp_acp_used[acp_ch] == 1 )
				continue;
			
			g_amp_acp_cfg[acp_ch].port_msk = (1<<port_no);
			g_amp_acp_used[acp_ch] = 1;
			lst_val_acp = acp_ch;
			break;
		}
		if(acp_ch==MAX_ACP_NUM){
			g_amp_acp_cfg[lst_val_acp].port_msk |= (1<<port_no);
		}
	}
	
	return g_amp_acp_cfg;
}
	
#endif /*_FPGA_ETHERNET_AMP_CFG_C_*/
