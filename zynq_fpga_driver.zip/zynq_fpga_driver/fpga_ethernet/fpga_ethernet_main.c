#ifndef _FPGA_ETHERNET_MAIN_C_
#define _FPGA_ETHERNET_MAIN_C_

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/skbuff.h>
#include <linux/ethtool.h>
#include <linux/if_ether.h>
#include <linux/crc32.h>
#include <linux/mii.h>
#include <linux/if.h>
#include <linux/if_vlan.h>
#include <linux/dma-mapping.h>
#include <linux/slab.h>
#include <linux/prefetch.h>
#include <linux/debugfs.h>
#include <linux/seq_file.h>
#include <linux/net_tstamp.h>
#include <linux/delay.h>

#include "../inc/sf_fpga_gp.h"
#include "../inc/sf_fpga_acp.h"

#include "fpga_ethernet_gp.h"
#include "fpga_ethernet_mac.h"
#include "fpga_ethernet_acp.h"
#include "fpga_ethernet_pre.h"
#include "fpga_ethernet_pre_7010.h"
#include "fpga_ethernet_sysfs.h"
#include "fpga_ethernet_main.h"

#include "./bpm_hooks/eth_bpm.h"

#ifdef CONFIG_SMP_ETHERNET
	#ifndef CONFIG_SMP_SCATTER_PIPE
		#pragma message("Complie fpga ethernet smp mode combining pipe mode!")
	#else
		#pragma message("Complie fpga ethernet smp mode scattering pipe mode!")
	#endif
#else
	#pragma message("Complie fpga ethernet amp mode!")
#endif

static fpga_ethernet_port_t g_port_attr[FPGA_PORT_MAX];
//static xmit_mac_info_t xmit_mac_info[FPGA_PORT_MAX];

static uint32 gp_global_remap = 0;
static int fpga_ethernet_rx(int port_no, uint32 *pdata);
#ifndef CONFIG_SMP_ETHERNET
#define SKB_RX_BUF_SIZE		(1536)

static int dcc_recv_proc(int id, int proc_cnt);
extern int dcc_inner_data_write(int id, char *buf, int count);
extern int dcc_inner_data_read(int id, char *buf, int count);

#endif

#define PORT1_ICMP		(0)

#if PORT1_ICMP
static int icmp_tx = 0;
static int icmp_tx_0 = 0;

static int icmp_rx = 0;
#endif

static int (*soft_ppt_cb)(int, char *) = NULL;

int soft_ppt_func_register(void *func, int flag)
{
	if(flag > 0) {
		soft_ppt_cb = func;
	} else {
		soft_ppt_cb = NULL;
	}
	
	return 0;
}
EXPORT_SYMBOL_GPL(soft_ppt_func_register);

fpga_ethernet_port_t* get_port_info(uint32 port_no)
{
	if(unlikely(port_no >= FPGA_PORT_MAX))
		return NULL;

	return(&g_port_attr[port_no]);
}

int show_port_info(char *buf)
{
	fpga_ethernet_port_t *port_attr = NULL;
	
	int port_no = 0;
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;
	
	char phy_info[4][16] = {
					"PHY_3082",
					"PHY_GE",
					"PHY_8041",
					"PHY_83849"
				};
	
	rs = sprintf(ps, "\nDRIVER:%s GIT_VER:%s\n",FPGA_ETHERNET_DEV_NAME,FPGA_ETHERNET_VER_INFO);		
	len = len + rs;
	ps = ps + rs;
	
	rs = sprintf(ps, "\n#########PORT INFO#########\n");	
	len = len + rs;
	ps = ps + rs;
	
	for(port_no=0; port_no<FPGA_PORT_MAX; port_no++) {
		
		port_attr = &g_port_attr[port_no];
		if(port_attr->is_valid != 0x0F)	continue;
		
		rs = sprintf(ps, "port_%d(mac_%d):rx_%d tx_%d	phyaddr:0x%x(%s)	mdio_mac_no:%d	is_shared_pipe:%d(%d)\n"
						, port_attr->port_no
						, port_attr->mac_no
						, port_attr->rx_pipe
						, port_attr->tx_pipe
						, port_attr->phy_addr
						, phy_info[port_attr->phy_type]
						, port_attr->mdio_mac_no
						, port_attr->is_shared_pipe
						, port_attr->shared_pipe_sequ);	
		len = len + rs;
		ps = ps + rs;
	}
	
#if PORT1_ICMP
	rs = sprintf(ps, "++ icmp_rx:%d icmp_tx:%d icmp_tx_0:%d ++\n"
			, icmp_rx
			, icmp_tx
			, icmp_tx_0);	
			
	len = len + rs;
	ps = ps + rs;
#endif	
	return(len);
}


int show_port_debug_info(char *buf)
{
	int len 	= 0;
#if 0
	int port_no = 0;
	char *ps 	= buf;
	int	rs 		= 0;


	for(port_no=0; port_no<FPGA_PORT_MAX; port_no++) {

		if(port2mac(port_no) == RTN_ERR) continue;
		
		rs = sprintf(ps, "port_%d: mac_match:0x%08x	mac_unmatch:0x%08x	arp_mac_unmatch:0x%08x	arp_req:0x%08x\n"
					, port_no
					, xmit_mac_info[port_no].mac_match
					, xmit_mac_info[port_no].mac_unmatch
					, xmit_mac_info[port_no].arp_mac_unmatch
					, xmit_mac_info[port_no].arp_req);		
		len = len + rs;
		ps = ps + rs;

	}
#endif	
	return(len);
}


static struct tasklet_hrtimer fpga_eth_poll_hrtimer;
static ktime_t kt;
static rx_pipe_info_t rx_pipe_info;

static enum hrtimer_restart fpga_eth_hrtimer_poll(struct hrtimer *timer)
{	
	int i = 0;
	int pipe_cnt = 0;
	int pipe_no = 0;
	
	acp_bd_t rx_bd;	/*not used*/
	int rx_cnt = 0;
	int proc_rx_cnt = 0;
	uint32 data_offset = 0;
	
	tasklet_hrtimer_start(&fpga_eth_poll_hrtimer, kt, HRTIMER_MODE_REL);

	pipe_cnt = rx_pipe_info.rx_pipe_cnt;
	
	for(i=0; i<pipe_cnt; i++) {
			pipe_no = rx_pipe_info.rx_pipe_list[i];
			data_offset = 0;			
			rx_cnt = acp_pipe_read(pipe_no,&rx_bd);
			if(rx_cnt > 0) {
				proc_rx_cnt = proc_acp_pipe_read(pipe_no,rx_cnt,&data_offset,fpga_ethernet_rx);
				data_offset = data_offset>>5;
				acp_pipe_read_processed(pipe_no,proc_rx_cnt,data_offset);
			}
	}
	vbd_to_bd();
	
/* Modified by zhengg */
#ifndef CONFIG_SMP_ETHERNET
	dcc_recv_proc(COMM_SV_PIPE_ID,128);

	dcc_recv_proc(COMM_GOOSE_PIPE_ID,128);
	
	dcc_recv_proc(COMM_CORE0_PIPE_ID,128);
#endif

	return HRTIMER_NORESTART;
}


static int fpga_ethernet_open(struct net_device *dev)
{
	fpga_ethernet_dev_t *priv = netdev_priv(dev);
	/* TODO: Copy the MAC addr into the HW  */
	/* TODO: Initialize the MAC Core */

        /* napi enable */
	netif_start_queue(dev);

	priv->port_attr->is_opened = 1;

	return 0;
}

static int fpga_ethernet_release(struct net_device *dev)
{
	int32 rs = 0;
	fpga_ethernet_dev_t *priv = netdev_priv(dev);
	
	priv->port_attr->is_opened = 0;
	return(rs);
}

#if 0
int dump_mem(unsigned int *buf, int length)
{
	int i;
	int buf_addr = (int)buf;
	int len = length>>2;

	printk("\ndump the mem, length: %d:\n<0x%08x>: ", length,buf_addr);
	
	for(i = 0; i < len; i ++) {
		if(i != 0)
			if(!(i%8)){
				buf_addr = buf_addr+0x20;
				printk("\n<0x%08x>: ",buf_addr);
			}
		printk("0x%08x ", buf[i]);
	}
	printk("\n");

	return 0;
}
#endif

#ifndef CONFIG_SMP_ETHERNET
static int dcc_recv_proc(int id, int proc_cnt)
{
	struct sk_buff *new_skb = NULL;
	fpga_ethernet_port_t *port_attr = &g_port_attr[0];
	uint32 valid_len = 0;
	uint32 i = 0;
	fpga_ethernet_dev_t *lp = netdev_priv(port_attr->ndev);

	for(i=0; i<proc_cnt; i++) {
		new_skb = netdev_alloc_skb_ip_align(port_attr->ndev, SKB_RX_BUF_SIZE);
		if (!new_skb)
			return RTN_ERR;

		valid_len = dcc_inner_data_read(id, new_skb->data, SKB_RX_BUF_SIZE);
		if(valid_len > 0) {
			skb_put(new_skb, valid_len);
			new_skb->protocol = eth_type_trans(new_skb, port_attr->ndev);
			new_skb->ip_summed = CHECKSUM_UNNECESSARY;
		} else {
			dev_kfree_skb(new_skb);
			return(RTN_OK);
		}

		if(in_interrupt())
			netif_rx(new_skb);
		else
			netif_rx_ni(new_skb);

		lp->stats.rx_packets += 1;
		lp->stats.rx_bytes += valid_len;

	}
	return(RTN_OK);
}
#endif

static int fpga_ethernet_rx(int port_no, uint32 *pdata)
{
	struct sk_buff *new_skb = NULL;
	fpga_ethernet_port_t *port_attr = &g_port_attr[port_no];
	uint32 valid_len = 0;
	uint8 *pu8_data = (uint8 *)pdata;
	uint32 *skb_buf = NULL;
	uint32 *src_buf = NULL;
	uint32 i = 0;
	uint32 copy_cnt = 0;
	fpga_ethernet_dev_t *lp = NULL;
	int32	rs = 0;

	lp = netdev_priv(port_attr->ndev);

	if(soft_ppt_cb != NULL) {
		rs = soft_ppt_cb(port_no,&pu8_data[2]);
		if(rs < 0) {
			lp->stats.rx_dropped += 1;
			return(RTN_OK);
		}
	}
	
#define SKB_RX_BUF_SIZE		(1536)
	new_skb = netdev_alloc_skb_ip_align(port_attr->ndev, SKB_RX_BUF_SIZE);
	if (!new_skb)
		return RTN_ERR;

	valid_len = pu8_data[0]<<8|pu8_data[1];

	new_skb->data[0] = pu8_data[2];
	new_skb->data[1] = pu8_data[3];

	skb_buf = (uint32 *)(&(new_skb->data[2]));
	src_buf = &pdata[1];
		
	copy_cnt = valid_len>>2;
	copy_cnt = copy_cnt + 1;
	for(i=0; i<copy_cnt; i++)
		skb_buf[i] = src_buf[i];

#if PORT1_ICMP	
	if(port_no == 1) {
		if((new_skb->data[12] == 0x08) && (new_skb->data[13] == 0x00) && (new_skb->data[23] == 0x01))
			icmp_rx++;
	}
#endif

	skb_put(new_skb, valid_len);
	new_skb->protocol = eth_type_trans(new_skb, port_attr->ndev);
	new_skb->ip_summed = CHECKSUM_UNNECESSARY;

	mb();

	if(in_interrupt())	
		netif_rx(new_skb);
	else
       	netif_rx_ni(new_skb);
	
	lp->stats.rx_packets += 1;
	lp->stats.rx_bytes += valid_len;
	
	return(RTN_OK);
}

/* Modified by zhengg */
#ifndef CONFIG_SMP_ETHERNET
#define NET_MAC_LEN 6
#define DCC_MAC_TXPIPE 130
#define DCC_GOOSE_TXPIPE 129
#define DCC_SV_TXPIPE 128
int mac_tx_fit(struct sk_buff *skb, struct net_device *ndev, int *id)
{
        int trans_flag = -1;
        unsigned short protocol;
        unsigned long vlan;
        unsigned char laddr[NET_MAC_LEN];
        unsigned char *addr;

	if((skb == NULL) || (ndev == NULL))
		return -1;

        addr = skb->data;
        vlan = htonl(*(unsigned long *)(skb->data + 2*NET_MAC_LEN));
        if(((vlan>>16)&0xffff) == 0x8100) {
                protocol = vlan & 0xffff;
        }
        else
                protocol = (vlan>>16) & 0xffff;

        /* if((protocol == PACKET_MULTICAST) || (protocol == PACKET_BROADCAST))  */
        if((addr[0] & 0x3) != 0) {
                trans_flag = 0;
                *id = DCC_MAC_TXPIPE;
        }
        else if(protocol == 0x88b8){ /* goose */
                trans_flag = 0;
                *id = DCC_GOOSE_TXPIPE;
        }
        else if((protocol == 0x48b8) || (protocol == 0x88ba)){ /* sv */
                trans_flag = 0;
                *id = DCC_SV_TXPIPE;
        }
        else {
                /* compare the dst mac to core0 mac */
                memcpy(laddr, ndev->dev_addr, NET_MAC_LEN);
                laddr[5] -= 20;
                if(memcmp(skb->data, laddr, NET_MAC_LEN) == 0) {
                        trans_flag = 0;
                        addr = skb->data;
                        *id = DCC_MAC_TXPIPE;
                }
        }

        return trans_flag;
}
#endif

/* Modified by zhengg */
#ifndef CONFIG_SMP_ETHERNET 
static unsigned char  inner_xmit_header[1800];
#endif
#define MAC_MIN_LEN			(60)
#define PADDING_BUF_LEN		(64)
static char g_padding_buf[FPGA_PORT_MAX][PADDING_BUF_LEN];
static netdev_tx_t fpga_ethernet_xmit(struct sk_buff *skb, struct net_device *ndev)
{	
	int rs = RTN_ERR;
	fpga_ethernet_dev_t *lp = netdev_priv(ndev);
	uint32 port_no = lp->port_attr->port_no;
	uint32 tx_pipe_no = lp->port_attr->tx_pipe;
	char *xmit_data = NULL;
	int xmit_len = 0; 

/* Modified by zhengg */
#ifndef CONFIG_SMP_ETHERNET
	int pipe_id;
	int pad;
	unsigned short *raw_len = NULL;
#define PADDING_4 4
#define PADDING_32 32
#define CNT_PADDING(len, pad) pad - ((len)&(pad-1))
#endif

//	if(unlikely(mac_is_full(port2mac(port_no),skb->len) == RTN_OK)) return(NETDEV_TX_BUSY);

#if PORT1_ICMP
	if(port_no == 1) {
		if((skb->data[12] == 0x08) && (skb->data[13] == 0x00) && (skb->data[23] == 0x01))
			icmp_tx++;
	}
#endif

	if(unlikely(0 == atomic_read(&(g_port_attr[port_no].tx_port_atomic)))) {
		return(NETDEV_TX_BUSY);
	}

	atomic_set(&(g_port_attr[port_no].tx_port_atomic), 0);

	if(unlikely((skb->len) < MAC_MIN_LEN)) {
		xmit_data = g_padding_buf[port_no];
		memset(xmit_data,0,PADDING_BUF_LEN);
		memcpy(xmit_data,skb->data,skb->len);
		xmit_len = MAC_MIN_LEN;
	} else {
		xmit_data = skb->data;
		xmit_len = skb->len;
	}
	
	if(lp->port_attr->is_shared_pipe == 1)
		rs = eth_acp_pipe_write(port_no,tx_pipe_no,xmit_data,xmit_len,to_vbd);
	else
		rs = eth_acp_pipe_write(port_no,tx_pipe_no,xmit_data,xmit_len,to_vbd);
	
	if(rs == RTN_ERR) {
		lp->stats.tx_errors += 1;
		atomic_set(&(g_port_attr[port_no].tx_port_atomic), 1);
		return(NETDEV_TX_BUSY);
	}

#if PORT1_ICMP
	if(port_no == 1) {
		if((skb->data[12] == 0x08) && (skb->data[13] == 0x00) && (skb->data[23] == 0x01))
			icmp_tx_0++;
	}
#endif

	lp->stats.tx_packets += 1;
	lp->stats.tx_bytes += skb->len;

/* Modified by zhengg */
#ifndef CONFIG_SMP_ETHERNET
	/* Send inner net port packet */
	if(port_no == 0) {
		rs = mac_tx_fit(skb, ndev, &pipe_id);
		if(rs == 0) {
			pad = CNT_PADDING(xmit_len + 2, PADDING_4);
   			memset(inner_xmit_header, 0, sizeof(ether_header) + 2 + xmit_len + pad);
			memcpy(inner_xmit_header+sizeof(ether_header)+2, skb->data, xmit_len);
			raw_len = (unsigned short *)(inner_xmit_header + sizeof(ether_header));
			*raw_len = ((xmit_len >> 8) & 0x00ff) + ((xmit_len << 8)& 0xff00);
			rs = dcc_inner_data_write(pipe_id, inner_xmit_header, sizeof(ether_header)+2+xmit_len+pad);
        }
    }
#endif

	dev_kfree_skb(skb);
	atomic_set(&(g_port_attr[port_no].tx_port_atomic), 1);
	return(NETDEV_TX_OK);
}

static int fpga_ethernet_change_mtu(struct net_device *dev, int new_mtu)
{
	int rs = 0;
	
	return(rs);
}

static netdev_features_t fpga_ethernet_fix_features(struct net_device *dev, netdev_features_t features)
{
//	struct fpgamac_priv *priv = netdev_priv(dev);

	return features;
}

static void fpga_ethernet_set_rx_mode(struct net_device *ndev)
{
#ifdef CONFIG_SMP_ETHERNET
	fpga_ethernet_dev_t *lp = netdev_priv(ndev);
	int mc_ents = 0;
	struct netdev_hw_addr *curr = NULL;
	u8 *mc_addr = NULL;
	u8 filter0_cnt = 0;
	u8 filter1_cnt = 0;
	u8 pre_multi_addr0[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	u8 pre_multi_addr1[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	u8 multi_addr0[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	u8 multi_addr1[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	u8 multi_mask0[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	u8 multi_mask1[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
	
	/* promisc mode */
	if (ndev->flags & IFF_PROMISC) {
		/* Enable promisc*/
		mac_promisc_set(lp->port_attr->mac_no, 1);
	}
	if (!(ndev->flags & IFF_PROMISC)) {
		/* Disable promisc*/
		mac_promisc_set(lp->port_attr->mac_no, 0);
	}

	/* multicast mode */
	if (ndev->flags & IFF_ALLMULTI) {
		/* All multicast mode */
		mac_multi_set(lp->port_attr->mac_no, NULL, NULL, XILINX_MAC_MULTI_ALL);
	} else if (ndev->flags & IFF_MULTICAST) {
		/* Specific multicast mode */
		mc_ents = netdev_mc_count(ndev);
		if(mc_ents > 7) {
			printk("Multicast count %d outof range!\n",mc_ents);
			return;
		}
#if 1
		netdev_for_each_mc_addr(curr, ndev) {
			if (!curr)	/* end of list */
				break;
			mc_addr = curr->addr;

			/* use 2 filter group */
			if(mc_addr[0] == 0x01) {

				if(filter1_cnt != 0) {
					/*same bit mask*/
					multi_mask1[0] &= ~(mc_addr[0]^pre_multi_addr1[0]);
					multi_mask1[1] &= ~(mc_addr[1]^pre_multi_addr1[1]);
					multi_mask1[2] &= ~(mc_addr[2]^pre_multi_addr1[2]);
					multi_mask1[3] &= ~(mc_addr[3]^pre_multi_addr1[3]);
					multi_mask1[4] &= ~(mc_addr[4]^pre_multi_addr1[4]);
					multi_mask1[5] &= ~(mc_addr[5]^pre_multi_addr1[5]);
				}
					/*get same bit address*/
				multi_addr1[0] = mc_addr[0] & multi_mask1[0];
				multi_addr1[1] = mc_addr[1] & multi_mask1[1];
				multi_addr1[2] = mc_addr[2] & multi_mask1[2];
				multi_addr1[3] = mc_addr[3] & multi_mask1[3];
				multi_addr1[4] = mc_addr[4] & multi_mask1[4];
				multi_addr1[5] = mc_addr[5] & multi_mask1[5];

				pre_multi_addr1[0] = mc_addr[0];
				pre_multi_addr1[1] = mc_addr[1];
				pre_multi_addr1[2] = mc_addr[2];
				pre_multi_addr1[3] = mc_addr[3];
				pre_multi_addr1[4] = mc_addr[4];
				pre_multi_addr1[5] = mc_addr[5];

				filter1_cnt++;
			} else {
				if(filter0_cnt != 0) {
					/*same bit mask*/
					multi_mask0[0] &= ~(mc_addr[0]^pre_multi_addr0[0]);
					multi_mask0[1] &= ~(mc_addr[1]^pre_multi_addr0[1]);
					multi_mask0[2] &= ~(mc_addr[2]^pre_multi_addr0[2]);
					multi_mask0[3] &= ~(mc_addr[3]^pre_multi_addr0[3]);
					multi_mask0[4] &= ~(mc_addr[4]^pre_multi_addr0[4]);
					multi_mask0[5] &= ~(mc_addr[5]^pre_multi_addr0[5]);	
				}
					/*get same bit address*/
				multi_addr0[0] = mc_addr[0] & multi_mask0[0];
				multi_addr0[1] = mc_addr[1] & multi_mask0[1];
				multi_addr0[2] = mc_addr[2] & multi_mask0[2];
				multi_addr0[3] = mc_addr[3] & multi_mask0[3];
				multi_addr0[4] = mc_addr[4] & multi_mask0[4];
				multi_addr0[5] = mc_addr[5] & multi_mask0[5];

				pre_multi_addr0[0] = mc_addr[0];
				pre_multi_addr0[1] = mc_addr[1];
				pre_multi_addr0[2] = mc_addr[2];
				pre_multi_addr0[3] = mc_addr[3];
				pre_multi_addr0[4] = mc_addr[4];
				pre_multi_addr0[5] = mc_addr[5];

				filter0_cnt++;
			}
		}
		mac_multi_set(lp->port_attr->mac_no, multi_addr0, multi_mask0, 0);
		mac_multi_set(lp->port_attr->mac_no, multi_addr1, multi_mask1, 1);
#endif
	} else {
		/* Disable multicast mode */
		mac_multi_disable(lp->port_attr->mac_no);
	}

	/* broadcast mode */
	if (ndev->flags & IFF_BROADCAST) {
	}

	if (!(ndev->flags & IFF_BROADCAST)) {
		/* No broadcast */
	}

#else

#endif
	
	return;
}

static void fpga_ethernet_tx_timeout(struct net_device *dev)
{
//	struct fpgamac_priv *priv = netdev_priv(dev);

	/* Clear Tx resources and restart transmitting again */
	return;
}

#ifdef CONFIG_SMP_ETHERNET	
static int fpga_ethernet_ioctl_smp(struct net_device *dev, struct ifreq *rq, int cmd)
{
	int ret = -EOPNOTSUPP;
	
	fpga_ethernet_dev_t *lp = netdev_priv(dev);
	uint32 port_no = lp->port_attr->port_no;
	struct mii_ioctl_data *mii_data = if_mii(rq);
	uint32 phy_reg = 0;

	switch (cmd) {	
	case SIOCGMIIPHY:
		mii_data->phy_id = g_port_attr[port_no].phy_addr;
		ret = 0;
		break;
	case SIOCGMIIREG:
		phy_reg_rd(g_port_attr[port_no].mdio_mac_no, g_port_attr[port_no].phy_addr,mii_data->reg_num,&phy_reg);
		mii_data->val_out = phy_reg&0xFFFF;
		printk("rd:phy_addr:0x%d reg_addr:0x%x val:0x%x\n"
				, g_port_attr[port_no].phy_addr
				, mii_data->reg_num
				, mii_data->val_out);
		ret = 0;
		break;
	case SIOCSMIIREG:
		phy_reg_wr(g_port_attr[port_no].mdio_mac_no, g_port_attr[port_no].phy_addr,mii_data->reg_num,mii_data->val_in);
		printk("wr:phy_addr:0x%d reg_addr:0x%x val:0x%x\n"
				, g_port_attr[port_no].phy_addr
				, mii_data->reg_num
				, mii_data->val_in);
		ret = 0;
		break;
	case SIOCSHWTSTAMP:
                /* TODO:  */
		break;
					
	default:
		break;
	}

	return ret;
}

#else
 
static int fpga_ethernet_ioctl_amp(struct net_device *dev, struct ifreq *rq, int cmd)
{
	int ret = -EOPNOTSUPP;

typedef struct bc_user_argu_stru {
		unsigned long  devnum;
		unsigned long  set_ms;
		unsigned long  set_count;
		unsigned long  set_time;
} bc_user_argu_t;
	
	bc_user_argu_t bc_user_argu;
	fpga_ethernet_dev_t *lp = netdev_priv(dev);
	uint32 port_no = lp->port_attr->port_no;

	/*for delete fpga frame ctrl*/
	return(ret);
	
	if(!IS_7010_LITE())
		return -EINVAL;

	if(dev == NULL)
		return -EINVAL;
	
	if (!netif_running(dev))
		return -EINVAL;

	printk("%s(%d) called net%1d\n", __FUNCTION__, cmd, port_no);

	if(port_no == 0) {
		printk("%s(%d) called net%1d, NOT support ioctl!!\n", __FUNCTION__, cmd, port_no);
                return -EFAULT;
	}
 
	switch (cmd) {
		case SIOCDEVPRIVATE: /* read info */
			copy_to_user(rq->ifr_data, &bc_user_argu, sizeof(bc_user_argu_t));
			ret = 0;
			break;
		case SIOCDEVPRIVATE + 1: /* set info */
			if (copy_from_user(&bc_user_argu, rq->ifr_data, sizeof(bc_user_argu_t)))
				return -EFAULT;
			ret = 0;
			break;

		default:
			printk("sf fpga net:ioctl %d not implemented.\n", cmd);
	}
	
	return(ret);
}

#endif

static int fpga_ethernet_config(struct net_device *dev, struct ifmap *map)
{
	if (dev->flags & IFF_UP)	/* can't act on a running interface */
		return -EBUSY;

	return 0;
}

#ifdef CONFIG_NET_POLL_CONTROLLER
static void fpga_ethernet_poll_controller(struct net_device *dev)
{
	disable_irq(dev->irq);
//	fpgamac_interrupt(dev->irq, dev);
	enable_irq(dev->irq);
}
#endif

static int fpga_ethernet_poll(struct napi_struct *napi, int budget)
{
	int work_done = 0;
	
	return(work_done);
}

static struct net_device_stats *fpga_ethernet_get_stats(struct net_device *ndev)
{
	fpga_ethernet_dev_t *lp = netdev_priv(ndev);
	struct net_device_stats *nstat = &(lp->stats);

	return nstat;
}

static int fpga_ethernet_mac_address(struct net_device *ndev, void *addr)
{
	fpga_ethernet_dev_t *lp = netdev_priv(ndev);
	struct sockaddr *hwaddr = (struct sockaddr *)addr;

	if (netif_running(ndev))
		return -EBUSY;

	if (!is_valid_ether_addr(hwaddr->sa_data))
		return -EADDRNOTAVAIL;

	printk("hwaddr 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n"
			, hwaddr->sa_data[0], hwaddr->sa_data[1], hwaddr->sa_data[2]
			, hwaddr->sa_data[3], hwaddr->sa_data[4], hwaddr->sa_data[5]);

	memcpy(ndev->dev_addr, hwaddr->sa_data, ndev->addr_len);

	mac_addr_set(lp->port_attr->mac_no, addr, 0xffffffff);

	return 0;
}

static const struct net_device_ops fpga_ethernet_ops = {
	.ndo_open = fpga_ethernet_open,
	.ndo_start_xmit = fpga_ethernet_xmit,
	.ndo_stop = fpga_ethernet_release,
	.ndo_change_mtu = fpga_ethernet_change_mtu,
	.ndo_fix_features = fpga_ethernet_fix_features,
	.ndo_set_rx_mode = fpga_ethernet_set_rx_mode,
	.ndo_tx_timeout = fpga_ethernet_tx_timeout,
#ifdef CONFIG_SMP_ETHERNET	
	.ndo_do_ioctl = fpga_ethernet_ioctl_smp,
#else
	.ndo_do_ioctl = fpga_ethernet_ioctl_amp,
#endif
	.ndo_set_config = fpga_ethernet_config,
#ifdef CONFIG_NET_POLL_CONTROLLER
	.ndo_poll_controller = fpga_ethernet_poll_controller,
#endif
	.ndo_set_mac_address = fpga_ethernet_mac_address,
	.ndo_get_stats	= fpga_ethernet_get_stats,
};

static int fpga_ethernet_hw_init(fpga_ethernet_port_t *port_attr)
{
	int rs = RTN_ERR;
	
	get_port_attr(port_attr);
#ifdef CONFIG_SMP_ETHERNET
	rs = fpga_ethernet_port_connect_pipe_smp(port_attr);
#else
	rs = fpga_ethernet_port_connect_pipe_amp(port_attr);
#endif
	return(rs);
}

static int fpga_ethernet_drv_probe(int port_no)
{
	int rs = RTN_ERR;
	int mac_no = 0;
	struct net_device *ndev = NULL;
	fpga_ethernet_dev_t *priv = NULL;
	
	mac_no = port2mac(port_no);
	if(mac_no == RTN_ERR) {
		g_port_attr[port_no].mac_no = -1;
		return(RTN_ERR);
	} 
		
	ndev = alloc_etherdev(sizeof(fpga_ethernet_dev_t));
	if (!ndev)
		return -ENOMEM;
		
	sprintf(ndev->name, "net%d", port2mac(port_no));
			
	priv = netdev_priv(ndev);
	priv->ndev = ndev;
	priv->port_attr = &(g_port_attr[port_no]);

	priv->port_attr->ndev = ndev;
	priv->port_attr->port_no = port_no;
	priv->port_attr->mac_no = mac_no;
		
	rs = fpga_ethernet_hw_init(priv->port_attr);
	if(rs == RTN_ERR)
		goto free_fail_dev;
	
	ndev->watchdog_timeo = TX_TIMEOUT;
	ndev->hw_features = NETIF_F_IP_CSUM | NETIF_F_RXCSUM;
	
	ether_setup(ndev);
	
	ndev->netdev_ops = &fpga_ethernet_ops;

	netif_napi_add(ndev, &priv->napi, fpga_ethernet_poll, 64);
	
	rs = register_netdev(ndev);
	if (rs) {
		pr_err("<%d>%s ERROR %d registering the device\n", __LINE__, __FUNCTION__, rs);
		goto error_netdev_register;
	}

	atomic_set(&(g_port_attr[port_no].tx_port_atomic), 1);
	atomic_set(&(g_port_attr[port_no].rx_port_atomic), 1);
	
	rs = RTN_OK;
	return(rs);	
	
error_netdev_register:
	netif_napi_del(&priv->napi);
free_fail_dev:	
	free_netdev(ndev);	
	return(rs);
} 

int __init fpga_ethernet_init(void)
{
	sint32 rs = RTN_ERR;
	uint32 mac_cnt = 0;
	uint32 port_no = 0;
	uint32 rx_pipe_mask = 0;
	uint32 mac_type_info = 0;
	uint32 utmp = 0;
	uint32 mac_no = 0;
	
#ifdef CONFIG_SMP_ETHERNET		
	uint32 phy_reg = 0;
#endif

	mac_switich(MAC_SW_TO_FPGA);
	
	fpga_ethernet_sysfs_create(FPGA_ETHERNET_DEV_NAME);
	
	gp_global_remap = get_gp_global_remap();
	if(gp_global_remap == (uint32)NULL) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	mac_cnt = REG_RD(gp_global_remap+GP_GLOBAL_USED_PMAC_NUM);
	printk("mac_cnt:%d \n",mac_cnt);

	printk("%s COMPILE TIME:%s %s@0x%08x\n"
			, FPGA_ETHERNET_DEV_NAME
			, __DATE__
			, __TIME__
			, get_fpga_id());
	printk("VER:%s\n",FPGA_ETHERNET_VER_INFO);

	mac_type_info = REG_RD(gp_global_remap+GP_GLOBAL_MAC_TYPE_MASK_ADD);
	utmp = REG_RD(gp_global_remap+GP_GLOBAL_MAC_TYPE_MASK);
	printk("mac_type_info:0x%08x 0x%08x\n",mac_type_info,utmp);
	
	for(port_no=0; port_no<FPGA_PORT_MAX; port_no++) {
		fpga_ethernet_drv_probe(port_no);
		if((g_port_attr[port_no].is_valid == 0x0F) 
			&& (g_port_attr[port_no].rx_pipe != 0xFFFFFFFF)
			&& ((rx_pipe_mask & 0x01<<g_port_attr[port_no].rx_pipe)==0)
			) {
			rx_pipe_mask |= 0x01<<g_port_attr[port_no].rx_pipe;

			rx_pipe_info.rx_pipe_list[rx_pipe_info.rx_pipe_cnt] = g_port_attr[port_no].rx_pipe;
			rx_pipe_info.rx_pipe_cnt++;			
		}

		if(g_port_attr[port_no].is_valid == 0x0F) {

			mac_no = g_port_attr[port_no].mac_no;
			if(mac_type_info == 0xDEADBEEF) {
				if((utmp&(0x01<<mac_no)) == 0) 
					mac_disable_LT_check(mac_no);
			} else {
				if((utmp&(0x01<<mac_no)) == 0 && (mac_type_info&(0x01<<mac_no)) == 0)
					mac_disable_LT_check(mac_no);
			}
		}
		
#ifdef CONFIG_SMP_ETHERNET
		mdio_init(g_port_attr[port_no].mdio_mac_no);
		if(g_port_attr[port_no].phy_type == PHY_GE) {
			printk("PORT_%d is GE!\n",port_no);
			phy_reg_rd(g_port_attr[port_no].mdio_mac_no, g_port_attr[port_no].phy_addr,0,&phy_reg);
			phy_reg &= ~0x400;
			phy_reg_wr(g_port_attr[port_no].mdio_mac_no, g_port_attr[port_no].phy_addr,0,phy_reg);
		}
#else
	/*amp mode mdio function*/


	/*init open bc receive for software reboot*/
	if(IS_7010_LITE()) {
		utmp = REG_RD(gp_global_remap+GP_GLOBAL_BC_SHUTDOWN_C1);
		utmp &= ~(0x01<<port_no);
		REG_WR(gp_global_remap+GP_GLOBAL_BC_SHUTDOWN_C1, utmp);
	}
#endif
	}

	eth_bpm_init();
	
#ifdef CONFIG_SMP_ETHERNET
	if(IS_7010_LITE()) {
		fpga_ethernet_pre_init_7010(rx_pipe_mask);
	} else {
		fpga_ethernet_pre_init(rx_pipe_mask);
	}
#else

#endif	
	fpga_ethernet_acp_init();
	
	kt = ns_to_ktime(POLLING_FREQ);
	tasklet_hrtimer_init(&fpga_eth_poll_hrtimer, fpga_eth_hrtimer_poll, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	tasklet_hrtimer_start(&fpga_eth_poll_hrtimer, kt, HRTIMER_MODE_REL);
	
	printk("%s init finish Poll freq:%d HZ!\n"
			, FPGA_ETHERNET_DEV_NAME
			, 1000000000/POLLING_FREQ);
	
	rs = RTN_OK;

	return(rs);
}

void __exit fpga_ethernet_exit(void)
{
	tasklet_hrtimer_cancel(&fpga_eth_poll_hrtimer);
	fpga_ethernet_sysfs_release();
	mac_switich(MAC_SW_TO_GEM);
	return;
}

module_init(fpga_ethernet_init);
module_exit(fpga_ethernet_exit);

MODULE_AUTHOR("cuijinjin@sf-auto");
MODULE_DESCRIPTION("zynq fpga ethernet:"FPGA_ETHERNET_VER_INFO);
MODULE_LICENSE("Dual BSD/GPL");

#endif /* _FPGA_ETHERNET_MAIN_C_ */
