#ifndef _FPGA_ETHERNET_GP_H_
#define _FPGA_ETHERNET_GP_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

#include "fpga_ethernet_main.h"

typedef enum {
	MAC_SW_TO_FPGA	= 0,
	MAC_SW_TO_GEM	= 1,
	MAC_SW_OFFSET	= 0x280,
} _MAC_SW_T;

typedef enum {
	GP_GLOBAL_FPGA_ID		 	= 0,
	GP_GLOBAL_USED_PMAC_NUM 	= 0x0040,
	GP_GLOBAL_TX_BUF_UNIT	 	= 0x004C,
	GP_GLOBAL_MAC_PORT_MAP0		= 0x0050,
	GP_GLOBAL_MAC_PORT_MAP1		= 0x0054,
	GP_GLOBAL_MAC_PORT_MAP2		= 0x0058,
	GP_GLOBAL_MAC_PORT_MAP3		= 0x005C,
	GP_GLOBAL_TX_BUF_SIZE0		= 0x0070,
	GP_GLOBAL_TX_BUF_SIZE1		= 0x0074,
	GP_GLOBAL_TX_BUF_SIZE2		= 0x0078,
	GP_GLOBAL_TX_BUF_SIZE3		= 0x007C,
	GP_GLOBAL_ACP_TUNNEL_BASE	= 0x00E0,
	
	GP_GLOBAL_PORT_CFG_BASE		= 0x0200,
	GP_GLOBAL_MAC_TYPE_MASK_ADD	= 0x0318,
	GP_GLOBAL_MAC_TYPE_MASK		= 0x031C,
	GP_GLOBAL_BC_SHUTDOWN_C1	= 0x0840,
} _MAC_INFO_ON_GP_T;

extern int get_pipe_logic_ID(uint32 pipe_no);
extern int port2mac(uint32 port_no);
extern int get_port_attr(fpga_ethernet_port_t *port_attr);
extern int mac_switich(uint32 val);
extern uint32 get_fpga_id(void);
extern int mac_is_full(uint32 mac_no,uint32 len);

#define IS_7010_LITE()		((get_fpga_id()&0xFFFF0001) == 0x70100001)

#endif /* _FPGA_ETHERNET_GP_H_ */