#ifndef _FPGA_ETHERNET_SYSFS_H_
#define _FPGA_ETHERNET_SYSFS_H_

extern int fpga_ethernet_sysfs_create(const char *dev_name);
extern int fpga_ethernet_sysfs_release(void);

#endif /*_FPGA_ETHERNET_SYSFS_H_*/