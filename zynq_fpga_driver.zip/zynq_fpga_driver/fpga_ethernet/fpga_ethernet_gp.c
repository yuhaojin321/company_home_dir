#ifndef _FPGA_ETHERNET_GP_C_
#define _FPGA_ETHERNET_GP_C_

#include<linux/kernel.h>	/*printk*/

#include "../inc/sf_fpga_gp.h"

#include "fpga_ethernet_gp.h"

static uint32 g_gp_global_remap = 0;

int get_pipe_logic_ID(uint32 pipe_no)
{
	uint32 gp_global_remap = 0;
	uint32 reg_val = 0;
	uint32 reg_div = 0;
	uint32 reg_mod = 0;
	uint32 logic_id = 0;
	
	gp_global_remap = get_gp_global_remap();
	if(gp_global_remap == (uint32)NULL) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}

	reg_div = pipe_no/4;
	reg_mod = pipe_no%4;	
	reg_val = REG_RD(gp_global_remap+GP_GLOBAL_ACP_TUNNEL_BASE+(4*reg_div));
	logic_id = (reg_val>>(8*reg_mod)) & 0xFF;

	return(logic_id);
}

static uint32 m2p_tbl_flag = 0;
static uint32 m2p_tbl[4] = {0};

static int m2p_tbl_init(void)
{	
	g_gp_global_remap = get_gp_global_remap();
	if(unlikely(g_gp_global_remap == (uint32)NULL)) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	m2p_tbl[0] = REG_RD(g_gp_global_remap+GP_GLOBAL_MAC_PORT_MAP0);
	m2p_tbl[1] = REG_RD(g_gp_global_remap+GP_GLOBAL_MAC_PORT_MAP1);
	m2p_tbl[2] = REG_RD(g_gp_global_remap+GP_GLOBAL_MAC_PORT_MAP2);
	m2p_tbl[3] = REG_RD(g_gp_global_remap+GP_GLOBAL_MAC_PORT_MAP3);
	
	return(RTN_OK);
}

int port2mac(uint32 port_no)
{
	uint32 mac_no = 0;
	uint8 *pu8_addr = NULL;

	if(unlikely(port_no >= FPGA_PORT_MAX))
		return(RTN_ERR);

	if(unlikely(0 == m2p_tbl_flag)) {
		m2p_tbl_init();
		m2p_tbl_flag = 1;
	}

	pu8_addr = (uint8*)m2p_tbl;
	for(mac_no=0; mac_no<FPGA_PORT_MAX; mac_no++) {
		if(pu8_addr[mac_no] ==port_no)
			return(mac_no);
	}
	
	mac_no = RTN_ERR;
	return(mac_no);
}

int get_port_attr(fpga_ethernet_port_t *port_attr)
{
	int rs = RTN_ERR;
	int port_no = port_attr->port_no;
	uint32 gp_global_remap = 0;
	uint32 reg_val = 0;
	
	if(port_attr == NULL)
		return(RTN_ERR);
	
	gp_global_remap = get_gp_global_remap();
	if(unlikely(gp_global_remap == (uint32)NULL)) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	reg_val = REG_RD(gp_global_remap+GP_GLOBAL_PORT_CFG_BASE+(port_no*4));
	
	port_attr->is_valid = (reg_val>>12) & 0x0F;
	port_attr->phy_type = (reg_val>>10) & 0x3;
	port_attr->mdio_mac_no = (reg_val>>5) & 0x1F;
	port_attr->phy_addr = (reg_val) & 0x1F;
	
	rs = RTN_OK;
	return(rs);
}

int mac_switich(uint32 val)
{
	uint32 gp_global_remap = 0;
	
	gp_global_remap = get_gp_global_remap();
	if(unlikely(gp_global_remap == (uint32)NULL)) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	REG_WR(gp_global_remap+MAC_SW_OFFSET, val);

	return(RTN_OK);
}

static uint32 g_fpga_id = 0;
uint32 get_fpga_id(void)
{
	uint32 gp_global_remap = 0;
	if(g_fpga_id == 0) {	
		gp_global_remap = get_gp_global_remap();
		if(unlikely(gp_global_remap == (uint32)NULL)) {
			printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
			return(RTN_ERR);
		}
		g_fpga_id = REG_RD(gp_global_remap+GP_GLOBAL_FPGA_ID);
	}
	
	return(g_fpga_id);
}

int mac_is_full(uint32 mac_no,uint32 len)
{
	uint32 tx_buf_size = 0;
	uint32 val = 0;
	uint32 tmp = 0;
	
	tx_buf_size = REG_RD(g_gp_global_remap+GP_GLOBAL_TX_BUF_UNIT);
	
	tmp = REG_RD(g_gp_global_remap+GP_GLOBAL_TX_BUF_SIZE0+(mac_no/4*4));
	val = (tmp>>(mac_no%4*8)) & 0xff;

	val = val*tx_buf_size;

	if(val <= len)
		return RTN_OK;

	return RTN_ERR;
}
#endif /*_FPGA_ETHERNET_GP_C_*/