#ifndef _FPGA_ETHERNET_MAIN_H_
#define _FPGA_ETHERNET_MAIN_H_

#include <linux/netdevice.h>

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "../ver_inc/git_ver.h"

#define FPGA_ETHERNET_DEV_NAME	"fpga_ethernet"
#define FPGA_ETHERNET_VER_INFO	GIT_COMMIT_ID_STR

#define FPGA_PORT_MAX	(0x10)

#define POLLING_FREQ	(500000)

#define TX_TIMEOUT		(60*HZ)		/* Tx timeout is 60 seconds. */

        
#define COMM_SV_PIPE_ID  0
#define COMM_GOOSE_PIPE_ID  1
#define COMM_CORE0_PIPE_ID  2
        
typedef struct __comm_mac_header {
        unsigned char  reserve1[3]; /* include padding area length */
        unsigned char  mac_number;
        unsigned long  mac_mask;/* include buf header/checksum/data length but not padding data */
        unsigned short reserve2;
        unsigned short xmit_ctl;
        unsigned long  reserver3; 
}ether_header;

typedef enum {
	PHY_3082 	= 0x00,
	PHY_GE		= 0x01,
	PHY_8041	= 0x02,
	PHY_83849	= 0x03,
} _PHY_TYPE;

typedef struct fpga_ethernet_port_stru {
	uint32 port_no;
	int32 mac_no;
	uint32 phy_addr;
	uint32 phy_type;
	uint32 mdio_mac_no;
	int32 is_valid;
	int32 is_opened;
	
	uint32 rx_pipe;
	uint32 tx_pipe;

	uint32 is_shared_pipe;
	uint32 shared_pipe_sequ;

	struct net_device *ndev;
	
	atomic_t tx_port_atomic;
	atomic_t rx_port_atomic;
} fpga_ethernet_port_t;

typedef struct fpga_ethernet_dev_stru {
	struct net_device *ndev;
	struct net_device_stats stats;
	struct napi_struct napi ____cacheline_aligned_in_smp;
	
	fpga_ethernet_port_t *port_attr;
} fpga_ethernet_dev_t;

typedef struct rx_pipe_info_stru {
	int rx_pipe_cnt;
	int rx_pipe_list[FPGA_PORT_MAX];
} rx_pipe_info_t;

typedef struct fpga_ethernet_port_debug_stru {
	uint32 rxproc_data_out;
	uint32 rxproc_sn_unmatch;
	uint32 rxproc_len_unmatch;
	
} fpga_ethernet_port_debug_t;

#define MAC_CMP(mac1, mac2)	memcmp(mac1, mac2, 6)

typedef struct xmit_mac_info_stru {
	uint32 mac_unmatch;
	uint32 mac_match;
	uint32 arp_mac_unmatch;
	uint32 arp_req;
} xmit_mac_info_t;

extern fpga_ethernet_port_t* get_port_info(uint32 port_no);

#endif /* _FPGA_ETHERNET_MAIN_H_ */
