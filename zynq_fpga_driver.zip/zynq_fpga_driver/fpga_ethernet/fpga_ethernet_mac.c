#ifndef _FPGA_ETHERNET_MAC_C_
#define _FPGA_ETHERNET_MAC_C_

#include <linux/kernel.h>	/*printk*/
#include <linux/socket.h>

#include "../inc/sf_fpga_gp.h"

#include "fpga_ethernet_mac.h"

extern int port2mac(uint32 port_no);

static int mac_reg_rd(uint32 mac_no, uint32 reg_addr, uint32 *val)
{
	uint32 mac_remap = 0;
	
	mac_remap = get_gp_mac_remap(mac_no);
	if(unlikely(mac_remap == (uint32)NULL)) {
		return(RTN_ERR);
	}
	
	REG_WR(mac_remap+MAC_REG_RD_ADDR, reg_addr);
	
	*val = REG_RD(mac_remap+MAC_REG_RD_DATA);
	return (RTN_OK);
}

static int mac_reg_wr(uint32 mac_no, uint32 reg_addr, uint32 val)
{
	uint32 mac_remap = 0;
	
	mac_remap = get_gp_mac_remap(mac_no);
	if(unlikely(mac_remap == (uint32)NULL)) {
		return(RTN_ERR);
	}
	
	REG_WR(mac_remap+MAC_REG_WR_ADDR, reg_addr);
	
	REG_WR(mac_remap+MAC_REG_WR_DATA, val);
	return (RTN_OK);
}

int mac_disable_LT_check(uint32 mac_no)
{
	uint32 u32_reg = 0;
	
	mac_reg_rd(mac_no, XILINX_MAC_RECEIVER_CONF, &u32_reg);
	u32_reg |= 0x02000000;
	mac_reg_wr(mac_no, XILINX_MAC_RECEIVER_CONF, u32_reg);

	return (RTN_OK);
}

int mac_addr_set(uint32 mac_no, void *addr, int is_promisc)
{
	int rs = RTN_ERR;
	struct sockaddr *hwaddr = (struct sockaddr *)addr;
	uint32 mad_addr = 0;

	if(unlikely(addr == NULL)) {
		return(RTN_ERR);
	}

	printk("mac_%d set addr\n",mac_no);
	mad_addr= hwaddr->sa_data[3]<<24|hwaddr->sa_data[2]<<16|hwaddr->sa_data[1]<<8|hwaddr->sa_data[0];
	mac_reg_wr(mac_no, XILINX_MAC_UNICAST_WORD0, mad_addr);

	mad_addr = 0;
	mad_addr = hwaddr->sa_data[5]<<8|hwaddr->sa_data[4];
	mac_reg_wr(mac_no, XILINX_MAC_UNICAST_WORD1, mad_addr);

#if 0
	if(is_promisc == 1) {
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_CTRL, 0x80000000);

		/* Set no filter */
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA0, 0);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA1, 0);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK0, 0);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK1, 0);

		/* Enable the filter */
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_ENABLE, 0x01);
	} else {
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_CTRL, 0x0);

		/* Set multi broadcast filter */
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA0, 0xffffffff);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA1, 0xffffffff);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK0, 0x0000ffff);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK1, 0x0000ffff);

		/* Enable the filter */
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_ENABLE, 0x01);
	}
#endif
	rs = RTN_OK;
	return(rs);
}

int mac_promisc_set(uint32 mac_no, int is_enable)
{
	int rs = RTN_ERR;
	uint32 u32_reg = 0;
/*	
	printk("mac_%d set promisc %s\n"
			, mac_no
			, is_enable?"enable":"disable");
*/
	mac_reg_rd(mac_no, XILINX_MAC_FILTER_CTRL, &u32_reg);

	if(is_enable)
		u32_reg |= 0x80000000;
	else
		u32_reg &= (~0x80000000);
	
	mac_reg_wr(mac_no, XILINX_MAC_FILTER_CTRL, u32_reg);

	rs = RTN_OK;
	return(rs);
}

int mac_multi_set(uint32 mac_no, u8 *addr, u8 *mask, int filter_flag)
{
	int rs = RTN_ERR;
	uint32 u32_reg = 0;
	uint32 mac_addrLo = 0;
	uint32 mac_addrHi = 0;
	uint32 mask_addrLo = 0;
	uint32 mask_addrHi = 0;
	
	if(filter_flag == XILINX_MAC_MULTI_ALL) {
	/*	printk("mac_%d recv all multicast!\n", mac_no);	*/

		/* Disable the filter */
		mac_reg_rd(mac_no, XILINX_MAC_FILTER_CTRL, &u32_reg);
		u32_reg &= (~0x00000007);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_CTRL, u32_reg);

		/* Set multi broadcast filter */
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA0, 0x00000001);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA1, 0x00000000);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK0, 0x00000001);
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK1, 0x00000000);

		/* Enable the filter */
		mac_reg_rd(mac_no, XILINX_MAC_FILTER_ENABLE, &u32_reg);
		u32_reg |= 0x00000001;
		mac_reg_wr(mac_no, XILINX_MAC_FILTER_ENABLE, u32_reg);
		
		rs = RTN_OK;
		return(rs);
	}
#if 0
	printk("===================================================\n");
	printk("mac_%d set multi addr %02x-%02x-%02x-%02x"
		, mac_no
		, addr[0]
		, addr[1]
		, addr[2]
		, addr[3]);

	printk("-%02x-%02x @filter_flag_%d\n"
		, addr[4]
		, addr[5]
		, filter_flag);

	printk("mac_%d set mask addr %02x-%02x-%02x-%02x"
		, mac_no
		, mask[0]
		, mask[1]
		, mask[2]
		, mask[3]);

	printk("-%02x-%02x @filter_flag_%d\n"
		, mask[4]
		, mask[5]
		, filter_flag);
	printk("===================================================\n");
#endif
	mac_addrLo = (addr[3]<<24)|(addr[2]<<16)|(addr[1]<<8)|addr[0];
	mac_addrHi = (addr[5]<<8)|addr[4];

	mask_addrLo = (mask[3]<<24)|(mask[2]<<16)|(mask[1]<<8)|mask[0];
	mask_addrHi = (mask[5]<<8)|mask[4];

	mac_reg_rd(mac_no, XILINX_MAC_FILTER_CTRL, &u32_reg);
	u32_reg &= (~0x00000007);
	u32_reg |= (filter_flag&0x00000007);
	mac_reg_wr(mac_no, XILINX_MAC_FILTER_CTRL, u32_reg);

	mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA0, mac_addrLo);
	mac_reg_wr(mac_no, XILINX_MAC_FILTER_DATA0+4, mac_addrHi);

	mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK0, mask_addrLo);
	mac_reg_wr(mac_no, XILINX_MAC_FILTER_MASK0+4, mask_addrHi);

	/* Enable the filter */
	mac_reg_rd(mac_no, XILINX_MAC_FILTER_ENABLE, &u32_reg);
	u32_reg |= 0x00000001;
	mac_reg_wr(mac_no, XILINX_MAC_FILTER_ENABLE, u32_reg);
	
	rs = RTN_OK;
	return(rs);
}

int mac_multi_disable(uint32 mac_no)
{
	int rs = RTN_ERR;
	uint32 u32_reg = 0;

/*	printk("mac_%d disable multicast!\n", mac_no);	*/
	
	/* Disable the filter */
	mac_reg_rd(mac_no, XILINX_MAC_FILTER_CTRL, &u32_reg);
	u32_reg &= (~0x00000001);	
	mac_reg_wr(mac_no, XILINX_MAC_FILTER_CTRL, u32_reg);
	
	return(rs);
}

int mdio_init(uint32 mac_no)
{
	uint32 mdio_clk_div = 0;

#define MAX_MAC_AXI_CLK					150000000		//����MDIO��Ƶ��ʵ��125M��ȡ150M����ֹ�պ�����
#define MAX_MDID_CLK					2500000

#define MAC_MDIO_SETUP_EN_MASK			0x00000040

	mdio_clk_div = (MAX_MAC_AXI_CLK/MAX_MDID_CLK)/2-1;
	mdio_clk_div = (mdio_clk_div&0x3f) | MAC_MDIO_SETUP_EN_MASK;
	mac_reg_wr(mac_no, XILINX_MAC_MDIO_SET_WORD, mdio_clk_div);
	
	return(RTN_OK);
}

static int is_mdio_op_over(uint32 mac_no)
{
	uint32 u32_reg;
	uint32 rd_cnt = 0;

	mac_reg_rd(mac_no, XILINX_MAC_MDIO_CTRL_WORD, &u32_reg);
	while((u32_reg & MAC_MDIO_CTRL_READY_MASK) != MAC_MDIO_CTRL_READY_MASK)		// Bit7 of MDIO control word reg,ready
	{
		mac_reg_rd(mac_no, XILINX_MAC_MDIO_CTRL_WORD, &u32_reg);
		rd_cnt++;
		if(rd_cnt > 100000)
			goto RD_TIME_OUT;
	}

	return RTN_OK;
RD_TIME_OUT:
	return RTN_ERR;
}

int phy_reg_rd(uint32 mac_no, uint32 phy_addr, uint32 reg_addr,uint32 *pData)
{
	int rs = RTN_ERR;
	uint8 u8mac_no = 0;
	uint32 op_reg = 0;
	
	if((NULL == pData) || (reg_addr>31) || (phy_addr>31) )	// 8��phy+1��8841�����9��
		return(rs);
   

    u8mac_no = mac_no;
	op_reg =   MAC_MDIO_CTRL_INIT_MASK
					 | MAC_MDIO_CTRL_OP_RD_MASK
					 | ((phy_addr&0xff) << MAC_MDIO_CTRL_PHY_ADDR_SHIFT)
					 | ((reg_addr&0xff) << MAC_MDIO_CTRL_REG_ADDR_SHIFT);

	mac_reg_wr(mac_no, XILINX_MAC_MDIO_CTRL_WORD, op_reg);
	if(is_mdio_op_over(mac_no) == RTN_OK)
	{
		mac_reg_rd(mac_no, XILINX_MAC_MDIO_RD_DATA, pData);
		rs = RTN_OK;
	}

	return(rs);
}

int phy_reg_wr(uint32 mac_no, uint32 phy_addr, uint32 reg_addr,uint32 pData)
{
	int rs = RTN_ERR;
	uint8 u8mac_no = 0;
	uint32 op_reg = 0;
	if((reg_addr>31) || (phy_addr>31))
		return(rs);

    u8mac_no = mac_no;
	mac_reg_wr(mac_no, XILINX_MAC_MDIO_WR_DATA, pData);
	
	op_reg =   MAC_MDIO_CTRL_INIT_MASK
					 | MAC_MDIO_CTRL_OP_WR_MASK
					 | ((phy_addr&0xff) << MAC_MDIO_CTRL_PHY_ADDR_SHIFT)
					 | ((reg_addr&0xff) << MAC_MDIO_CTRL_REG_ADDR_SHIFT);
	mac_reg_wr(mac_no, XILINX_MAC_MDIO_CTRL_WORD, op_reg);
	if(is_mdio_op_over(mac_no) == RTN_OK)
	{
		rs = RTN_OK;
	}
	
	return(rs);
}


#endif /* _FPGA_ETHERNET_MAC_C_ */
