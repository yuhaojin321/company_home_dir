#ifndef _FPGA_ETHERNET_ACP_C_
#define _FPGA_ETHERNET_ACP_C_

#include<linux/kernel.h>	/*printk*/

#include "../inc/sf_fpga_gp.h"

#include "fpga_ethernet_main.h"
#include "fpga_ethernet_gp.h"
#include "fpga_ethernet_acp.h"
#include "fpga_ethernet_amp_cfg.h"

#include "./bpm_hooks/eth_bpm.h"

static acp_pipe_cfg_t acp_pipe_cfg[ACP_PIPE_MAX];
static uint32 pp_mask_list[ACP_PIPE_MAX];  /*pipe port mask list for fpga pre proc(0x0~0x10)*/

static sm_remap_info_t sm_remap_list[SM_REMAP_LIST_CNT];
static vbd_info_t vbd_buf[FPGA_PORT_MAX];
static fpga_ethernet_pipe_debug_t pipe_debug_info[ACP_PIPE_MAX];

static uint32 pipe_wr_sn[ACP_PIPE_MAX] = {0};
static uint32 share_pipe_data_offset = 0;
static atomic_t pipe_atomic[ACP_PIPE_MAX];

int show_sm_remap_list(char *buf)
{
	int pos 	= 0;
	
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;
	
	rs = sprintf(ps, "\n#########SHARE MEM REMAP INFO#########\n");
		
	len = len + rs;
	ps = ps + rs;

	rs = sprintf(ps, "share_pipe_data_offset:0x%08x\n",share_pipe_data_offset);
		
	len = len + rs;
	ps = ps + rs;
	
	for(pos=0; pos<SM_REMAP_LIST_CNT; pos++) {
		if(sm_remap_list[pos].is_used == 0)	continue;
		
		rs = sprintf(ps, "phy:0x%08x remap:0x%08x size:0x%08x\n"
					, sm_remap_list[pos].phy_addr
					, sm_remap_list[pos].remap_addr
					, sm_remap_list[pos].size);
		
		len = len + rs;
		ps = ps + rs;
	}
		
	return(len);
}

int show_pipe_port_mask(char *buf)
{
	int pipe_no = 0;
	
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;

	rs = sprintf(ps, "\n#########PIPE PORT MASK INFO#########\n");
		
	len = len + rs;
	ps = ps + rs;
	
	for(pipe_no=0; pipe_no<ACP_PIPE_MAX; pipe_no++) {
		if(pp_mask_list[pipe_no] == 0)	continue;
		
		rs = sprintf(ps, "pipe_%d pipe_mask:0x%08x\n"
					, pipe_no
					, pp_mask_list[pipe_no]);
		
		len = len + rs;
		ps = ps + rs;
	}
	
	return(len);
}

int show_pipe_debug_info(char *buf)
{
	int pipe_no = 0;
	
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;

	rs = sprintf(ps, "\n#########PIPE DEBUG INFO#########\n");
		
	len = len + rs;
	ps = ps + rs;
	
	for(pipe_no=0; pipe_no<ACP_PIPE_MAX; pipe_no++) {

		if(pp_mask_list[pipe_no] == 0)	continue;
		rs = sprintf(ps, "pipe_%d:	rxproc(d-o:0x%08x sn:0x%08x len:0x%08x) "
					, pipe_no
					, pipe_debug_info[pipe_no].rxproc_data_out
					, pipe_debug_info[pipe_no].rxproc_sn_unmatch
					, pipe_debug_info[pipe_no].rxproc_len_unmatch);
		
		len = len + rs;
		ps = ps + rs;

		rs = sprintf(ps, "txproc(d-u-e:0x%08x d-f:0x%08x) \n"
					, pipe_debug_info[pipe_no].txproc_data_unempty
					, pipe_debug_info[pipe_no].txproc_data_full);
		
		len = len + rs;
		ps = ps + rs;
	}
	
	return(len);
}

static int acp_rx_check(int pipe_no, acp_bd_t *rx_bd, uint32 data_addr)
{	
	uint32 checksum = 0;
	uint32 len = 0;
	uint32 i = 0;

	if(unlikely(BD_SN(rx_bd) != DATA_SN(data_addr))) {
		pipe_debug_info[pipe_no].rxproc_sn_unmatch++;
		return(RTN_ERR);
	}

	if(unlikely(BD_LEN(rx_bd) != DATA_LEN(data_addr))) {
		pipe_debug_info[pipe_no].rxproc_len_unmatch++;
		return(RTN_ERR);
	}

	len = DATA_VAL_LEN(data_addr);
	len = len>>2;  			/*	len/4	*/
	for(i=0; i<len; i++)
		checksum ^= ((uint32 *)data_addr)[i];

	if(unlikely(checksum != 0))
		return(RTN_ERR);
	
	return(RTN_OK);
}

extern int dump_mem(unsigned int *buf, int length);
int proc_acp_pipe_read(int pipe_no, int rx_bd_cnt, uint32 *data_offset,
							int (*eth_pack_callback)(int port_no, uint32* pdata))
{
	int proc_bd = 0;
	int port_no = 0;
	int bd_ps_rd = 0;
	int rs = 0;
	acp_bd_t *rx_bd = NULL;
	uint32 data_remap_addr = 0;
	fpga_ethernet_port_t* port_info = NULL;
	
	if(unlikely(pipe_no >= ACP_PIPE_MAX)) return (RTN_ERR);

	if(unlikely(0 == atomic_read(&pipe_atomic[pipe_no]))) {
		return(RTN_ERR);
	}

	atomic_set(&pipe_atomic[pipe_no], 0);

#define RX_PIPE_PROC_MAX	(128)
	if(unlikely(rx_bd_cnt>RX_PIPE_PROC_MAX))	rx_bd_cnt = RX_PIPE_PROC_MAX;

	for(proc_bd=0; proc_bd<rx_bd_cnt; proc_bd++) {

		mb();
		bd_ps_rd = acp_pipe_cfg[pipe_no].bd_rd + proc_bd;
		rx_bd = (acp_bd_t*)(acp_pipe_cfg[pipe_no].bd_vaddr + (bd_ps_rd<<4));

		*data_offset = BD_DATA_ADDR(rx_bd) - acp_pipe_cfg[pipe_no].data_baseaddr;
		if(unlikely(*data_offset >= (acp_pipe_cfg[pipe_no].data_size<<5))) {
			pipe_debug_info[pipe_no].rxproc_data_out++;
		}

		data_remap_addr = acp_pipe_cfg[pipe_no].data_vaddr + (*data_offset);

		mb();
		if(unlikely(acp_rx_check(pipe_no,rx_bd,data_remap_addr) != RTN_OK))	 {
			continue;
		}
/*		if(unlikely(DATA_TYPE(data_remap_addr) != ACP_ETHERNET_TYPE))	continue;	*/

		port_no = DATA_PORT_INFO(data_remap_addr);
		if(unlikely(port_no > FPGA_PORT_MAX)) {
			continue;
		}
		port_info = get_port_info(port_no);
		if(unlikely(port_info->is_valid == 0))	{
			continue;
		}
		mb();
		/*ETH BPM CALLED*/
	 
		rs = eth_bpm_recv_cb(port_no, port2mac(port_no), (char *)data_remap_addr);

		if(likely(rs == RTN_NO_CARE)) {
			rs = eth_pack_callback(port_no,DATA_VAL_DATA(data_remap_addr));	
			if(unlikely(rs == RTN_ERR))
				break;
		} else {
		}
	}

	bd_ps_rd = (acp_pipe_cfg[pipe_no].bd_rd+proc_bd)%acp_pipe_cfg[pipe_no].bd_size;
	acp_pipe_cfg[pipe_no].bd_rd = bd_ps_rd;

	atomic_set(&pipe_atomic[pipe_no], 1);
	return(proc_bd);
}

static int vbd_is_full(uint32 port_no)
{
	

	if(unlikely(vbd_buf[port_no].rd_bd== 0 && vbd_buf[port_no].wr_bd >= (MAC_VBD_MAX-1))) {
		return(TRUE);
	}
	
	if(unlikely((vbd_buf[port_no].rd_bd-1) == vbd_buf[port_no].wr_bd)) {
		return(TRUE);
	}

	return(FALSE);
}

#if 0
static int vbd_xmit_status(uint32 port_no, uint32 pipe_no, int32 *xmited_data_pos)
{
	int32 bd_rd = 0;
	int32 bd_wr = 0;

	acp_bd_t *bd_vaddr = NULL;

	bd_rd = vbd_buf[port_no].rd_bd;
	bd_wr = vbd_buf[port_no].wr_bd;

	*xmited_data_pos = 0;
	if(likely(bd_rd == bd_wr))
		return(RTN_OK);

	if(likely(bd_rd == 0))
		bd_vaddr = &(vbd_buf[port_no].bd[MAC_VBD_MAX]);
	else
		bd_vaddr = &(vbd_buf[port_no].bd[bd_rd-1]);

	*xmited_data_pos = ((uint32)(bd_vaddr->pu32_DataAddr)) - acp_pipe_cfg[pipe_no].data_baseaddr;
	
	return(RTN_ERR);
	
}
#endif

int eth_acp_pipe_write(uint32 port_no, uint32 tx_pipe_no, 
							char* wr_buf, int len, uint32 xmit_status)
{
	int rs = RTN_ERR;
	int acp_valid_data_len = 0;
	int acp_pipe_data_len = 0;			/*not include fill 0*/
	int acp_pipe_data_len_all = 0;		/*include fill 0*/
	uint32 tx_data_pos = 0;
	uint32 *pipe_data_header = NULL;
	uint32 *pipe_data_cf_header = NULL;	/*checksum & fill 0 header*/
	uint32 *u32_wr_buf = NULL;
	char *u8_wr_buf = NULL;
	uint32 copy_cnt = 0;
	uint32 len_mod = 0;
	uint32 pipe_data_size = 0;
	int i = 0;
	acp_bd_t *v_bd = NULL;

	uint32 checksum = 0;
	uint32 checksum_len = 0;
	uint32 sn = pipe_wr_sn[tx_pipe_no];
	uint32 mac_no = 0;
	uint32 data_mac_offset = 0;
	uint32 tmp = 0;
	int32 unxmited_data_pos = 0;
	fpga_ethernet_port_t* port_info = NULL;
	
	if(unlikely(tx_pipe_no >= ACP_PIPE_MAX))
		return(rs);

	port_info = get_port_info(port_no);
	if(unlikely(port_info == NULL)) {
		printk("Get port_%d attr fail!\n",port_no);
		return(rs);
	}

#ifdef CONFIG_SMP_ETHERNET
	pipe_data_size = ACP_DATA_SIZE_SPM;
#else
	if(port_info->is_shared_pipe == 1)
		pipe_data_size = share_pipe_data_offset;
	else
		pipe_data_size = acp_pipe_cfg[tx_pipe_no].data_size<<5;
#endif
	
	mac_no = port2mac(port_no);
	if(unlikely(mac_no == RTN_ERR)) {
		return(RTN_ERR);
	}
	
	if(acp_pipe_cfg[tx_pipe_no].is_valid != ACP_PIPE_VALID) {
		return(rs);
	}
	
	if(unlikely(0 == atomic_read(&pipe_atomic[tx_pipe_no]))) {
		return(rs);
	}

	atomic_set(&pipe_atomic[tx_pipe_no], 0);
	
	if(unlikely(vbd_is_full(mac_no) == TRUE)) {
		atomic_set(&pipe_atomic[tx_pipe_no], 1);
		return(rs);
	}

	acp_valid_data_len = len+2;  /*fill valid len byte*/
	rs = acp_valid_data_len&0x03;
	if(rs != 0)
		acp_valid_data_len = acp_valid_data_len+(4-rs);	/*valid 4 byte align*/


	acp_pipe_data_len = acp_valid_data_len+28;	/* fill acp pipe header*/
	rs = acp_pipe_data_len&0x1f;
	if(rs != 0)
		acp_pipe_data_len_all = acp_pipe_data_len+(32-rs);	/*valid 32 byte align*/
	else
		acp_pipe_data_len_all = acp_pipe_data_len;

	tx_data_pos = vbd_buf[port_no].wr_data;

	if(port_info->is_shared_pipe == 1)
		data_mac_offset = ((port_info->shared_pipe_sequ)*pipe_data_size)>>5;

#ifdef CONFIG_SMP_SCATTER_PIPE
#pragma message("Use gp date pos!")
	if(acp_pipe_data_is_full(tx_pipe_no, acp_pipe_data_len_all, &tx_data_pos) == TRUE) {
		atomic_set(&pipe_atomic[tx_pipe_no], 1);
		return(RTN_ERR);
	}
#else
#pragma message("Use bd date pos!")
	rs = acp_pipe_unxmit_port_info(tx_pipe_no, port_no, &unxmited_data_pos);
	if(likely(vbd_buf[port_no].first_flag != 0)) {
		if(unlikely(rs == RTN_ERR)) {
			atomic_set(&pipe_atomic[tx_pipe_no], 1);
			return(RTN_ERR);
		}
	} 
	
	if(likely(unxmited_data_pos == 0)) {
		/*All BD of this port is xmited.*/	
		if(((tx_data_pos<<5)+acp_pipe_data_len_all) >= pipe_data_size)
			tx_data_pos = 0;
	} else {
	
		pipe_debug_info[tx_pipe_no].txproc_data_unempty++;
		if(unlikely((unxmited_data_pos&0x1f) != 0)) {
#if 1		
			printk("%s(%d): port_%d 0x%08x data non-aligned error!\n"
					, __FUNCTION__
					, __LINE__
					, port_no
					, unxmited_data_pos);
#endif
			atomic_set(&pipe_atomic[tx_pipe_no], 1);
			return(RTN_ERR);
		}
				/*revise mac offset*/
		unxmited_data_pos = ((unxmited_data_pos>>5) - data_mac_offset)<<5;
				
		if(unlikely((tx_data_pos<<5) < unxmited_data_pos)) {
			
			if(((tx_data_pos<<5)+acp_pipe_data_len_all) >= unxmited_data_pos) {
				pipe_debug_info[tx_pipe_no].txproc_data_full++;
				atomic_set(&pipe_atomic[tx_pipe_no], 1);
				return(RTN_ERR);
			}
			
		} else {
			if(((tx_data_pos<<5)+acp_pipe_data_len_all) >= pipe_data_size) {
				tx_data_pos = 0;
				if(acp_pipe_data_len_all >= unxmited_data_pos) {
					pipe_debug_info[tx_pipe_no].txproc_data_full++;
					atomic_set(&pipe_atomic[tx_pipe_no], 1);
					return(RTN_ERR);
				}
			}
		}
	}
#endif
	
	/* Occupation Data resources before used */
	vbd_buf[port_no].wr_data = tx_data_pos + (acp_pipe_data_len_all>>5);
#if 0	
	printk("<%d> mac_%d tx_data_pos:0x%08x	acp_pipe_data_len_all:0x%08x	unxmited_data_pos:0x%08x\n"
				, __LINE__
				, mac_no
				, tx_data_pos
				, acp_pipe_data_len_all >>5
				, unxmited_data_pos >> 5);
#endif
	tx_data_pos = tx_data_pos + data_mac_offset;
	pipe_data_header = (uint32 *)(acp_pipe_cfg[tx_pipe_no].data_vaddr + (tx_data_pos<<5));	
	pipe_data_header[0] = ((sn&0x0000ffff)<<16)|(acp_pipe_data_len_all&0x0000ffff);
	pipe_data_header[1] = ((ACP_ETHERNET_TYPE<<24) | (acp_pipe_data_len & 0x0000ffff));
	pipe_data_header[2] = 0;
	pipe_data_header[3] = 0x01<<port_no;
	pipe_data_header[4] = 0x00000000;
	pipe_data_header[5] = 0x00000000;
	pipe_data_header[6] = wr_buf[1]<<24|wr_buf[0]<<16|((len&0xff)<<8)|((len>>8)&0xff);	//data[0~1] & len
	u32_wr_buf =(uint32*)&wr_buf[2];
	copy_cnt = (len-2)>>2;
	for(i=0; i<copy_cnt; i++) {
		pipe_data_header[7+i] = u32_wr_buf[i];
	}

	u8_wr_buf =(char*)&u32_wr_buf[copy_cnt];
	len_mod = (len-2)&0x03;
	switch(len_mod) {
		case 1:
			pipe_data_header[7+copy_cnt] = u8_wr_buf[0];
			pipe_data_cf_header = &pipe_data_header[8+copy_cnt];
			break;
		case 2:
			pipe_data_header[7+copy_cnt] = (u8_wr_buf[0]) | (u8_wr_buf[1]<<8);
			pipe_data_cf_header = &pipe_data_header[8+copy_cnt];
			break;
		case 3:
			pipe_data_header[7+copy_cnt] = (u8_wr_buf[0]) | (u8_wr_buf[1]<<8) | (u8_wr_buf[2]<<16);
			pipe_data_cf_header = &pipe_data_header[8+copy_cnt];
			break;
		default:
			pipe_data_cf_header = &pipe_data_header[7+copy_cnt];
			break;
	}

	/*BEFORE CALCULATE CHECKSUM,CALL ETH BPM*/
	if((xmit_status & XMIT_STA_MASK) != is_rebound) {
		rs = eth_bpm_xmit_cb(port2mac(port_no),(char *)pipe_data_header);
		if(rs == RTN_TX_PROCED) {
		}
	}

	pipe_data_cf_header[0] = 0;
	checksum_len = acp_pipe_data_len>>2;
	for(i=0; i<checksum_len; i++) {
		checksum ^= pipe_data_header[i];
	}
	pipe_data_cf_header[0] = checksum;

	/*packet fill 0*/
	len_mod = acp_pipe_data_len&0x1f;
	copy_cnt = (32-len_mod)>>2;
	for(i=0; i<copy_cnt; i++)
		pipe_data_cf_header[1+i] = 0;
	vbd_buf[port_no].tx_pipe_no = tx_pipe_no;
	
	v_bd = &(vbd_buf[port_no].bd[vbd_buf[port_no].wr_bd]);

	u8_wr_buf = &(vbd_buf[port_no].is_xmited[vbd_buf[port_no].wr_bd]);
	*u8_wr_buf = (xmit_status & XMIT_OPT_MASK);
	
	v_bd->pu32_DataAddr  = (uint32*)(acp_pipe_cfg[tx_pipe_no].data_baseaddr+(tx_data_pos<<5));
	v_bd->u32_SN_Whllen = ((sn&0x0000ffff)<<16)|(acp_pipe_data_len_all&0x0000ffff);
	v_bd->u32_PortMask = 0x01<<port_no;
	v_bd->u32_CtrlInfo = ACP_ETHERNET_TYPE;
	mb();
	tmp = vbd_buf[port_no].wr_bd + 1;
	tmp = tmp % MAC_VBD_MAX;
	vbd_buf[port_no].wr_bd = tmp;

	if((xmit_status & XMIT_OPT_MASK) == to_vbd) {
		rs = RTN_OK;
	} else if((xmit_status & XMIT_OPT_MASK) == to_pipe) {

		rs = acp_pipe_write(tx_pipe_no, v_bd);
		if(unlikely(rs==RTN_ERR)) 
			/*if to pipe fail,xmit by vbd*/
			*u8_wr_buf = to_vbd;

	} else {

	}
	
	pipe_wr_sn[tx_pipe_no]++;
	atomic_set(&pipe_atomic[tx_pipe_no], 1);

	if(unlikely(vbd_buf[port_no].first_flag == 0)) {
		vbd_buf[port_no].first_flag = 1;
	}
	
	return(rs);
}

int vbd_to_bd(void)
{
	int rs = RTN_OK;
	uint32 port_no = 0;
	int loop_cnt = 8;
	uint32 rb_bd = 0;
	int32 mac_no = 0;

	while(loop_cnt--) {
		for(port_no=0; port_no<FPGA_PORT_MAX; port_no++) {

			mac_no = get_port_info(port_no)->mac_no;
			if(mac_no == -1) continue;
			
			rb_bd = vbd_buf[port_no].rd_bd;
			
			if(vbd_buf[port_no].wr_bd != rb_bd) {
				if(unlikely(mac_is_full(mac_no,(vbd_buf[port_no].bd[rb_bd].u32_SN_Whllen&0xFFFF)) == RTN_OK)) continue;
				
				if(vbd_buf[port_no].is_xmited[rb_bd] != 0) {
					rs = acp_pipe_write(vbd_buf[port_no].tx_pipe_no, &(vbd_buf[port_no].bd[rb_bd]));
					if(unlikely(rs == RTN_ERR))	continue;
				}
				rb_bd = rb_bd + 1;
				rb_bd = rb_bd % MAC_VBD_MAX;
				vbd_buf[port_no].rd_bd = rb_bd;
			}				
		}			
	}
		
	rs = RTN_OK;
	return(rs);
}

int get_rx_pipe_ports_mask(int32 pipe_no)
{
	if(unlikely(pipe_no >= ACP_PIPE_MAX))	return RTN_ERR;
	return(pp_mask_list[pipe_no]);
}

static int acp_mem_map(uint32 phyaddr, uint32 size, uint32 *vaddr, const char *name)
{
	int pos = 0;
	
	if (!request_mem_region(phyaddr, size, name)) {
		pr_err("%s(%d) %s request_mem_region fail.\n", __FUNCTION__, __LINE__, name);
			return -EBUSY;
	}

	*vaddr = (uint32)__arm_ioremap(phyaddr, size, MT_DEVICE_CACHED);
	if (!*vaddr) {
		pr_err("%s(%d)ioremap() failed\n", __FUNCTION__, __LINE__);
		release_mem_region(phyaddr, size);
		return -EFAULT;
	}
	
	for(pos=0; pos<SM_REMAP_LIST_CNT; pos++) {
		if(sm_remap_list[pos].is_used == 0)	break;
	}
	
	if(pos != SM_REMAP_LIST_CNT) {
		sm_remap_list[pos].is_used 		= 1;
		sm_remap_list[pos].phy_addr 	= phyaddr;
		sm_remap_list[pos].remap_addr	= *vaddr;
		sm_remap_list[pos].size 		= size;
	}

	return(RTN_OK);
}

static void acp_mem_unmap(uint32 phyaddr, uint32 size, uint32 vaddr, const char *name)
{
	int pos = 0;
	
	iounmap((void *)vaddr);
	release_mem_region(phyaddr, size);
	
	for(pos=0; pos<SM_REMAP_LIST_CNT; pos++) {
		if(sm_remap_list[pos].phy_addr == phyaddr)	break;
	}
	
	if(pos != SM_REMAP_LIST_CNT) {
		sm_remap_list[pos].is_used 	= 0;
	}
	
	return;
}

#ifdef CONFIG_SMP_ETHERNET
int fpga_ethernet_port_connect_pipe_smp(fpga_ethernet_port_t *port_attr)
{
	static uint32	pipe_rx_used = 0;
	static uint32	outer_fe_inited = 0;
	static uint32	outer_fe_rx_pipe = 0;
	static uint32	outer_fe_tx_pipe = 0;
	static uint32 	shared_pipe_sequ = 0;
	
	int32	rs = RTN_ERR;
	int32	pipe_rx_no = 0;
	int32	pipe_tx_no = 0;
	int32	mac_no = port_attr->mac_no;
	int32 	port_no = port_attr->port_no;

	uint32	acp_data_size = 0;
	port_attr->rx_pipe = 0xFFFFFFFF;
	port_attr->tx_pipe = 0xFFFFFFFF;

	vbd_buf[port_no].first_flag = 0;
	
	if((mac_no!=0) && (port_attr->phy_type!=PHY_GE) && (outer_fe_inited!=0)) {

		/*int CONFIG_SMP_SCATTER_PIPE MODE outer_fe_inited always 0*/
		/*inited outer FE port*/
		port_attr->rx_pipe = outer_fe_rx_pipe;
		port_attr->tx_pipe = outer_fe_tx_pipe;
		port_attr->is_shared_pipe = 1;
		port_attr->shared_pipe_sequ = shared_pipe_sequ;
		shared_pipe_sequ++;
			
		pp_mask_list[port_attr->rx_pipe] |= (1<<port_no);
		pp_mask_list[port_attr->tx_pipe] |= (1<<mac_no);
		share_pipe_data_offset = ACP_DATA_SIZE_SPM;
		return(RTN_OK);
	}
		
#define ETHNERNET_ACP_RX		(0x40)

#ifndef CONFIG_SMP_SCATTER_PIPE
		/* combining pipe mode*/
	if((mac_no==0) || (port_attr->phy_type==PHY_GE) || (outer_fe_inited==0)) {
#else
	{
		/* scattering pipe mode*/
#endif	
		/*rx_pipe*/
		pipe_rx_no = get_rx_pipe(ETHNERNET_ACP_RX+pipe_rx_used);
		if(pipe_rx_no == RTN_ERR)
			return(RTN_ERR);

		port_attr->is_shared_pipe = 0;	
		acp_data_size = ACP_DATA_SIZE;
		
#ifndef CONFIG_SMP_SCATTER_PIPE
		/* combining pipe mode*/
		if((mac_no!=0) && (port_attr->phy_type!=PHY_GE)) {
			/*outer FE port,just init once*/	
			outer_fe_inited = 1;
			outer_fe_rx_pipe = pipe_rx_no;
			port_attr->is_shared_pipe = 1;
			port_attr->shared_pipe_sequ = shared_pipe_sequ;
			shared_pipe_sequ++;

			acp_data_size = ACP_DATA_SIZE_SHARE;
		}
#else
		 /* scattering pipe mode*/
#endif
		if(port_attr->phy_type == PHY_GE) {		
			acp_data_size = ACP_DATA_SIZE<<3;	
		}
		
		acp_pipe_cfg[pipe_rx_no].pipe_no = pipe_rx_no;
		
		acp_pipe_cfg[pipe_rx_no].bd_size = ACP_BD_SIZE;
		acp_pipe_cfg[pipe_rx_no].bd_baseaddr = (uint32)alloc_acp_bd_mem(sizeof(acp_bd_t)*ACP_BD_SIZE);
		if((void *)acp_pipe_cfg[pipe_rx_no].bd_baseaddr == NULL) {
			printk("%s(%d): Mac_%d get acp bd mem fail!\n"		
					, __FUNCTION__
					, __LINE__
					, mac_no);
		}
 
		acp_pipe_cfg[pipe_rx_no].data_size = acp_data_size>>5;	/* aligned (32)*/
		acp_pipe_cfg[pipe_rx_no].data_baseaddr = (uint32)alloc_acp_data_mem(acp_data_size);
		if((void *)acp_pipe_cfg[pipe_rx_no].data_baseaddr == NULL) {
			printk("%s(%d): Mac_%d get acp data mem fail!\n"
					, __FUNCTION__
					, __LINE__
					, mac_no);
		}
		
		acp_pipe_cfg[pipe_rx_no].bd_rd = 0;
		acp_pipe_cfg[pipe_rx_no].bd_wr = 0xFFFFC000;
		acp_pipe_cfg[pipe_rx_no].pipe_attr = (ACP_ETHERNET_TYPE<<16)|0xAA;
		
		pipe_rx_used++;
		
		/*tx pipe*/
		pipe_tx_no = get_tx_pipe();
		if(pipe_tx_no == RTN_ERR)
			return(RTN_ERR);
		
#ifndef CONFIG_SMP_SCATTER_PIPE
		/* combining pipe mode*/
		if((mac_no!=0) && (port_attr->phy_type!=PHY_GE)) {
			/* outer FE port,record tx pipe no */	
			/* just once ctrl by outer_fe_inited */
			outer_fe_tx_pipe = pipe_tx_no;
		}
#else
		 /* scattering pipe mode*/
#endif

		
		acp_pipe_cfg[pipe_tx_no].pipe_no = pipe_tx_no;
		
		acp_pipe_cfg[pipe_tx_no].bd_size = ACP_BD_SIZE;
		acp_pipe_cfg[pipe_tx_no].bd_baseaddr = (uint32)alloc_acp_bd_mem(sizeof(acp_bd_t)*ACP_BD_SIZE);
		if((void *)acp_pipe_cfg[pipe_tx_no].bd_baseaddr == NULL) {
			printk("%s(%d): Mac_%d get acp bd mem fail!\n"
					, __FUNCTION__
					, __LINE__
					, mac_no);
		}
		
		acp_pipe_cfg[pipe_tx_no].data_size = acp_data_size>>5;	/* aligned (32)*/
		acp_pipe_cfg[pipe_tx_no].data_baseaddr = (uint32)alloc_acp_data_mem(acp_data_size);
		if((void *)acp_pipe_cfg[pipe_tx_no].data_baseaddr == NULL) {
			printk("%s(%d): Mac_%d get acp data mem fail!\n"		
					, __FUNCTION__
					, __LINE__
					, mac_no);
		}
		
		acp_pipe_cfg[pipe_tx_no].bd_rd = 0;
		acp_pipe_cfg[pipe_tx_no].bd_wr = 0;
		acp_pipe_cfg[pipe_tx_no].pipe_attr = (ACP_ETHERNET_TYPE<<16)|0xAA;
		
	}
		
	port_attr->rx_pipe = acp_pipe_cfg[pipe_rx_no].pipe_no;
	port_attr->tx_pipe = acp_pipe_cfg[pipe_tx_no].pipe_no;
	
	rs = acp_mem_map(acp_pipe_cfg[pipe_rx_no].bd_baseaddr, sizeof(acp_bd_t)*ACP_BD_SIZE, 
					&(acp_pipe_cfg[pipe_rx_no].bd_vaddr),FPGA_ETHERNET_DEV_NAME);
	if(rs != RTN_OK) {
		printk("%s(%d): acp mem map rx bd fail!\n"
				, __FUNCTION__
				, __LINE__);
		return(rs);
	} else
	memset((void *)acp_pipe_cfg[pipe_rx_no].bd_vaddr, 0, sizeof(acp_bd_t)*ACP_BD_SIZE);
	
	rs = acp_mem_map(acp_pipe_cfg[pipe_rx_no].data_baseaddr, acp_data_size, 
					&(acp_pipe_cfg[pipe_rx_no].data_vaddr),FPGA_ETHERNET_DEV_NAME);
	if(rs != RTN_OK) {
		printk("%s(%d): acp mem map rx data fail!\n"
				, __FUNCTION__
				, __LINE__);
		goto mem_map_step1;
	}
	memset((void *)acp_pipe_cfg[pipe_rx_no].data_vaddr, 0, acp_data_size);
 	
	rs = acp_mem_map(acp_pipe_cfg[pipe_tx_no].bd_baseaddr, sizeof(acp_bd_t)*ACP_BD_SIZE, 
					&(acp_pipe_cfg[pipe_tx_no].bd_vaddr),FPGA_ETHERNET_DEV_NAME);
	if(rs != RTN_OK) {
		printk("%s(%d): acp mem map tx bd fail!\n"
				, __FUNCTION__
				, __LINE__);
		goto mem_map_step2;
	}
	memset((void *)acp_pipe_cfg[pipe_tx_no].bd_vaddr, 0, sizeof(acp_bd_t)*ACP_BD_SIZE);
	
	rs = acp_mem_map(acp_pipe_cfg[pipe_tx_no].data_baseaddr, acp_data_size, 
					&(acp_pipe_cfg[pipe_tx_no].data_vaddr),FPGA_ETHERNET_DEV_NAME);
	if(rs != RTN_OK) {
		printk("%s(%d): acp mem map tx data fail!\n"
				, __FUNCTION__
				, __LINE__);
		goto mem_map_step3;
	}
	memset((void *)acp_pipe_cfg[pipe_tx_no].data_vaddr, 0, acp_data_size);

	acp_pipe_cfg[pipe_rx_no].is_valid = ACP_PIPE_VALID;
	acp_pipe_cfg[pipe_tx_no].is_valid = ACP_PIPE_VALID;
	
	pp_mask_list[port_attr->rx_pipe] |= (1<<port_no);
	pp_mask_list[port_attr->tx_pipe] |= (1<<mac_no);
	
	rs = RTN_OK;
	return(rs);
	
mem_map_step3:
	acp_mem_unmap(acp_pipe_cfg[pipe_tx_no].bd_baseaddr, sizeof(acp_bd_t)*ACP_BD_SIZE, 
					acp_pipe_cfg[pipe_tx_no].bd_vaddr, FPGA_ETHERNET_DEV_NAME);
mem_map_step2:
	acp_mem_unmap(acp_pipe_cfg[pipe_rx_no].data_baseaddr, (acp_pipe_cfg[pipe_rx_no].data_size)<<5, 
					acp_pipe_cfg[pipe_rx_no].data_vaddr, FPGA_ETHERNET_DEV_NAME);
mem_map_step1:
	acp_mem_unmap(acp_pipe_cfg[pipe_rx_no].bd_baseaddr, sizeof(acp_bd_t)*ACP_BD_SIZE, 
					acp_pipe_cfg[pipe_rx_no].bd_vaddr, FPGA_ETHERNET_DEV_NAME);
	
	return(rs);
}
#else /*CONFIG_SMP_ETHERNET*/

int get_pipe_port_cnt(int pipe_no)
{
	int32	rs 			= RTN_ERR;
	int32 	count 		= 0;
	int32	port_mask 	= 0;

	amp_acp_cfg_t *amp_acp_cfg_info = NULL;

	amp_acp_cfg_info = amp_get_pipe_cfg();
	if(amp_acp_cfg_info == NULL) {
		printk("%s(%d): AMP ACP CONFIG INFO GET ERROR!\n"
				, __FUNCTION__
				, __LINE__);
		return(rs);
	}


	if(amp_acp_cfg_info[pipe_no].val != ACP_CONFIG_MAGIC) {
		printk("%s(%d): PIPE_%d is invalid 0x%08x!\n"
				, __FUNCTION__
				, __LINE__
				, pipe_no
				, (uint32)amp_acp_cfg_info[pipe_no].val);
		return(rs);
	}
	
	port_mask = amp_acp_cfg_info[pipe_no].port_msk;

	while(port_mask) {
		port_mask = port_mask&(port_mask-1);  
		count++;   
	}
	
	return(count);
}

#if 0
int print_amp_acp_info(amp_acp_cfg_t *info)
{
	int i = 0;
	int pipe_no = 32;

	if(info == NULL) {
		printk("%s info is NULL\n", __FUNCTION__);
		return 0;
	}

	for(pipe_no=0; pipe_no<32; pipe_no++, info++) {
		printk("==============================\n");
		printk("port no:       0x%lx\n", info->pipe_no);
		printk("port val:      0x%lx\n", info->val);
		printk("port atrrib:   0x%lx\n", info->attrib);
		printk("port port_mask:0x%lx\n", info->port_msk);
		printk("port func_sel: 0x%lx\n", info->func_sel);
		printk("port eth_num:  0x%lx\n", info->ethtype_num);
		for(i = 0; i < 8; i ++) {
			printk("   %d type 0x%lx\n", i, info->ethtype[i]);
		}
		printk("port val_ext:  0x%lx\n", info->val_ext);
		printk("port data_adr: 0x%lx\n", info->data_addr);
		printk("port data_len: 0x%lx\n", info->data_len);
		printk("port bd_adr:   0x%lx\n", info->bd_addr);
		printk("port bd_len:   0x%lx\n", info->bd_len);
		printk("==============================\n");
	}
	
	return 0;
}
#endif

int fpga_ethernet_port_connect_pipe_amp(fpga_ethernet_port_t *port_attr)
{
	static uint32 	shared_pipe_sequ = 0;
	static amp_acp_cfg_t *amp_acp_cfg_info = NULL;

	int32	rs = RTN_ERR;
	int32	pipe_rx_no = 0;
	int32	pipe_tx_no = 0;
	int32	mac_no = port_attr->mac_no;
	int32 	port_no = port_attr->port_no;
	int32 	pipe_no = 0;
	int32 	mem_map_size = 0;

	vbd_buf[port_no].first_flag = 0;

	if(amp_acp_cfg_info == NULL) {
		amp_acp_cfg_info = amp_get_pipe_cfg();
		if(amp_acp_cfg_info == NULL) {
			printk("%s(%d): AMP ACP CONFIG INFO GET ERROR!\n"
					, __FUNCTION__
					, __LINE__);
			return(rs);
		}
	}

//	print_amp_acp_info(amp_acp_cfg_info);

	port_attr->rx_pipe = 0xFFFFFFFF;
	port_attr->tx_pipe = 0xFFFFFFFF;

	for(pipe_no=0; pipe_no<0x10; pipe_no++) {
		/* RX PIPE*/
		if(	(amp_acp_cfg_info[pipe_no].val == ACP_CONFIG_MAGIC) 	&& 
			((amp_acp_cfg_info[pipe_no].attrib & 0x00FEFFFF) == ACP_ATTRIB_CORE1_UNKNOW_TYPE)	&&
			((amp_acp_cfg_info[pipe_no].port_msk & (0x01<<port_no)) != 0)) {
			
			pipe_rx_no = amp_acp_cfg_info[pipe_no].pipe_no;
			port_attr->rx_pipe = pipe_rx_no;

			if(acp_pipe_cfg[pipe_rx_no].bd_size == 0) {
				/*This is un_inited pipe.*/
				acp_pipe_cfg[pipe_rx_no].pipe_no = pipe_rx_no;
			
				acp_pipe_cfg[pipe_rx_no].bd_size = amp_acp_cfg_info[pipe_no].bd_len;
				acp_pipe_cfg[pipe_rx_no].bd_baseaddr = amp_acp_cfg_info[pipe_no].bd_addr;
 
				acp_pipe_cfg[pipe_rx_no].data_size = amp_acp_cfg_info[pipe_no].data_len;	
				acp_pipe_cfg[pipe_rx_no].data_baseaddr = amp_acp_cfg_info[pipe_no].data_addr;
			}
			break;
		} else {
			
		}
	}

	if(port_attr->rx_pipe == 0xFFFFFFFF) {
		printk("%s(%d): Port_%d can't find rx pipe!\n"
				, __FUNCTION__
				, __LINE__
				, port_no);
		return(rs);
	}

	for(pipe_no=0x10; pipe_no<0x20; pipe_no++) {
		/* TX PIPE*/
		if(	(amp_acp_cfg_info[pipe_no].val == ACP_CONFIG_MAGIC) 	&& 
			((amp_acp_cfg_info[pipe_no].attrib & 0x00FEFFFF) == ACP_ATTRIB_CORE1_UNKNOW_TYPE)	&&
			((amp_acp_cfg_info[pipe_no].port_msk & (0x01<<port_no)) != 0)) {
			
			port_attr->tx_pipe = amp_acp_cfg_info[pipe_no].pipe_no;
			if((amp_acp_cfg_info[pipe_no].port_msk & ~(0x01<<port_no)) != 0) {

				port_attr->is_shared_pipe = 1;
				port_attr->shared_pipe_sequ = shared_pipe_sequ;
				shared_pipe_sequ++;

				share_pipe_data_offset = (amp_acp_cfg_info[pipe_no].data_len/shared_pipe_sequ)<<5;
				printk("%s(%d): port_%d share_pipe data_size:%d div %d as %d\n"
						, __FUNCTION__
						, __LINE__
						, port_no
						, (uint32)amp_acp_cfg_info[pipe_no].data_len
						, shared_pipe_sequ
						, share_pipe_data_offset>>5);
			}
			pipe_tx_no = amp_acp_cfg_info[pipe_no].pipe_no;
			port_attr->tx_pipe = pipe_tx_no;

			if(acp_pipe_cfg[pipe_tx_no].bd_size == 0) {
				/*This is un_inited pipe.*/
				acp_pipe_cfg[pipe_tx_no].pipe_no = pipe_tx_no;
			
				acp_pipe_cfg[pipe_tx_no].bd_size = amp_acp_cfg_info[pipe_no].bd_len;
				acp_pipe_cfg[pipe_tx_no].bd_baseaddr = amp_acp_cfg_info[pipe_no].bd_addr;
 
				acp_pipe_cfg[pipe_tx_no].data_size = amp_acp_cfg_info[pipe_no].data_len;	
				acp_pipe_cfg[pipe_tx_no].data_baseaddr = amp_acp_cfg_info[pipe_no].data_addr;
			}
			break;
		}
	}

	if(port_attr->tx_pipe == 0xFFFFFFFF) {
		printk("%s(%d): Port_%d can't find tx pipe!\n"
				, __FUNCTION__
				, __LINE__
				, port_no);
		return(rs);
	}

	if(acp_pipe_cfg[pipe_rx_no].bd_vaddr == 0) {
		mem_map_size = sizeof(acp_bd_t)*(acp_pipe_cfg[pipe_rx_no].bd_size);
		rs = acp_mem_map(acp_pipe_cfg[pipe_rx_no].bd_baseaddr, mem_map_size, 
						&(acp_pipe_cfg[pipe_rx_no].bd_vaddr),FPGA_ETHERNET_DEV_NAME);	
		if(rs != RTN_OK) {
			printk("%s(%d) acp pipe_%d rx bd mem(0x%08x<0x%08x>) map fail!\n"
					, __FUNCTION__
					, __LINE__
					, pipe_rx_no
					, acp_pipe_cfg[pipe_rx_no].bd_baseaddr
					, mem_map_size);
			return(rs);
		}
		memset((void *)acp_pipe_cfg[pipe_rx_no].bd_vaddr, 0, mem_map_size);
	}

	if(acp_pipe_cfg[pipe_rx_no].data_vaddr == 0) {
		mem_map_size = (acp_pipe_cfg[pipe_rx_no].data_size)<<5;
		rs = acp_mem_map(acp_pipe_cfg[pipe_rx_no].data_baseaddr, mem_map_size, 
						&(acp_pipe_cfg[pipe_rx_no].data_vaddr),FPGA_ETHERNET_DEV_NAME);
		if(rs != RTN_OK) {
			printk("%s(%d) acp pipe_%d rx data mem(0x%08x<0x%08x>) map fail!\n"
					, __FUNCTION__
					, __LINE__
					, pipe_rx_no
					, acp_pipe_cfg[pipe_rx_no].data_baseaddr
					, mem_map_size);
			goto mem_map_step1;
		}
		memset((void *)acp_pipe_cfg[pipe_rx_no].data_vaddr, 0, mem_map_size);
	}
	
	if(acp_pipe_cfg[pipe_tx_no].bd_vaddr == 0) {
		mem_map_size = sizeof(acp_bd_t)*(acp_pipe_cfg[pipe_tx_no].bd_size);
		rs = acp_mem_map(acp_pipe_cfg[pipe_tx_no].bd_baseaddr, mem_map_size, 
						&(acp_pipe_cfg[pipe_tx_no].bd_vaddr),FPGA_ETHERNET_DEV_NAME);
		if(rs != RTN_OK) {
			printk("%s(%d) acp pipe_%d tx bd mem(0x%08x<0x%08x>) map fail!\n"
					, __FUNCTION__
					, __LINE__
					, pipe_tx_no
					, acp_pipe_cfg[pipe_tx_no].bd_baseaddr
					, mem_map_size);
			goto mem_map_step2;
		}
		memset((void *)acp_pipe_cfg[pipe_tx_no].bd_vaddr, 0, mem_map_size);
	}

	if(acp_pipe_cfg[pipe_tx_no].data_vaddr == 0) {
		mem_map_size = (acp_pipe_cfg[pipe_tx_no].data_size)<<5;
		rs = acp_mem_map(acp_pipe_cfg[pipe_tx_no].data_baseaddr, mem_map_size, 
						&(acp_pipe_cfg[pipe_tx_no].data_vaddr),FPGA_ETHERNET_DEV_NAME);
		if(rs != RTN_OK) {
			printk("%s(%d) acp pipe_%d tx data mem(0x%08x<0x%08x>) map fail!\n"
					, __FUNCTION__
					, __LINE__
					, pipe_tx_no
					, acp_pipe_cfg[pipe_tx_no].data_baseaddr
					, mem_map_size);
			goto mem_map_step3;
		}
		memset((void *)acp_pipe_cfg[pipe_tx_no].data_vaddr, 0, mem_map_size);
	}

	acp_pipe_cfg[port_attr->rx_pipe].is_valid = ACP_PIPE_VALID;
	acp_pipe_cfg[port_attr->rx_pipe].bd_rd = 0;
	acp_pipe_cfg[port_attr->rx_pipe].bd_wr = 0xFFFFC000;
	acp_pipe_cfg[port_attr->rx_pipe].pipe_attr = (ACP_ETHERNET_TYPE<<16)|0xAA;

	acp_pipe_cfg[port_attr->tx_pipe].is_valid = ACP_PIPE_VALID;
	acp_pipe_cfg[port_attr->tx_pipe].bd_rd = 0;
	acp_pipe_cfg[port_attr->tx_pipe].bd_wr = 0;
	acp_pipe_cfg[port_attr->tx_pipe].pipe_attr = (ACP_ETHERNET_TYPE<<16)|0xAA;

	pp_mask_list[port_attr->rx_pipe] |= (1<<port_no);
	pp_mask_list[port_attr->tx_pipe] |= (1<<mac_no);
	
	rs = RTN_OK;
	return(rs);
	
mem_map_step3:
	acp_mem_unmap(acp_pipe_cfg[pipe_tx_no].bd_baseaddr, sizeof(acp_bd_t)*acp_pipe_cfg[pipe_tx_no].bd_size, 
					acp_pipe_cfg[pipe_tx_no].bd_vaddr, FPGA_ETHERNET_DEV_NAME);
mem_map_step2:
	acp_mem_unmap(acp_pipe_cfg[pipe_rx_no].data_baseaddr, (acp_pipe_cfg[pipe_rx_no].data_size)<<5, 
					acp_pipe_cfg[pipe_rx_no].data_vaddr, FPGA_ETHERNET_DEV_NAME);
mem_map_step1:
	acp_mem_unmap(acp_pipe_cfg[pipe_rx_no].bd_baseaddr, sizeof(acp_bd_t)*acp_pipe_cfg[pipe_rx_no].bd_size, 
					acp_pipe_cfg[pipe_rx_no].bd_vaddr, FPGA_ETHERNET_DEV_NAME);
	return(rs);
}
#endif /*CONFIG_SMP_ETHERNET*/

int fpga_ethernet_acp_init(void)
{
	int32	rs 		= RTN_ERR;
	int 	pipe_no = 0;
	int 	i 		= 0;

	printk("==========================================\n");
	for(pipe_no=0; pipe_no<0x10; pipe_no++) {
		/* RX PIPE*/
		if(acp_pipe_cfg[pipe_no].is_valid == ACP_PIPE_VALID) {
			
			atomic_set(&(pipe_atomic[pipe_no]), 1);
			
			acp_pipe_rx_init(&acp_pipe_cfg[pipe_no]);
			printk("rx_pipe_%d init for port:",pipe_no);
			for(i=0; i<16; i++) {
				if(pp_mask_list[pipe_no]&(0x01<<i))
					printk(" port_%d",i);
			}
			printk("\n");
		}
	}

	printk("==========================================\n");
	for(pipe_no=0x10; pipe_no<0x20; pipe_no++) {
		/* TX PIPE*/
		if(acp_pipe_cfg[pipe_no].is_valid == ACP_PIPE_VALID) {

			atomic_set(&(pipe_atomic[pipe_no]), 1);
			
			acp_pipe_tx_init(&acp_pipe_cfg[pipe_no]);
			printk("tx_pipe_%d init for mac:",pipe_no);
			for(i=0; i<16; i++) {
				if(pp_mask_list[pipe_no]&(0x01<<i))
					printk(" mac_%d",i);
			}
			printk("\n");
		}
	}
	printk("==========================================\n");

	rs = RTN_OK;
	return(rs);
}

#endif /* _FPGA_ETHERNET_ACP_C_ */
