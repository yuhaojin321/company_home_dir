#ifndef _FPGA_ETHERNET_SYSFS_C_
#define _FPGA_ETHERNET_SYSFS_C_

/*
 * Implement FPGA GP information use sysfs.
 * Copyright (C) 2017 sf-auto Ltd. 
 *
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

#include "fpga_ethernet_sysfs.h"
#include "fpga_ethernet_acp.h"

extern int show_port_info(char *buf);
extern int show_pipe_port_mask(char *buf);
extern int show_pipe_debug_info(char *buf);
extern int show_port_debug_info(char *buf);
extern int show_bpm_debug_info(char *buf);
extern int show_fpga_pre_conf(char *buf);
extern int show_port_bc_ctrl_info(char *buf);

static struct class *_sf_fpga_eth_class = NULL;

static ssize_t fpga_ethernet_show(struct class *class, struct class_attribute *attr, char *buf)
{
	int rs = 0;
	int len = 0;
	
	rs = show_port_info(buf);
	len = len + rs;
	
//	rs = show_sm_remap_list(buf+len);
//	len = len + rs;

//	rs = show_pipe_port_mask(buf+len);
//	len = len + rs;

	rs = show_pipe_debug_info(buf+len);
	len = len + rs;

	rs = show_fpga_pre_conf(buf+len);
	len = len + rs;

	rs = show_bpm_debug_info(buf+len);
	len = len + rs;

	rs = show_port_debug_info(buf+len);
	len = len + rs;

	return(len);
}

static ssize_t fpga_ethernet_store(struct class *class, struct class_attribute *attr, const char *buf, size_t count)
{
	return ~0;
}

static struct class_attribute dev_attr_fpga_ethernet = {
	.attr = {
		.name = NULL,
		.mode = S_IWUSR | S_IRUGO,
	},
	.show = fpga_ethernet_show,
	.store = fpga_ethernet_store,
};

int fpga_ethernet_sysfs_create(const char *dev_name)
{
	int rs = RTN_ERR;
	
	_sf_fpga_eth_class = class_create(THIS_MODULE, dev_name);
	if(IS_ERR(_sf_fpga_eth_class) != 0) {
		printk(KERN_ALERT"Failed to create device class.\n");
		return(RTN_ERR);
	}
	
	dev_attr_fpga_ethernet.attr.name = dev_name;
	rs = class_create_file(_sf_fpga_eth_class, &dev_attr_fpga_ethernet);
	if(rs < 0) {
		printk(KERN_ALERT"Failed to create attribute info device.\n");
		return(RTN_ERR);
	}
	
	return(RTN_OK);	
}

int fpga_ethernet_sysfs_release(void)
{
	class_remove_file(_sf_fpga_eth_class, &dev_attr_fpga_ethernet);
	class_destroy(_sf_fpga_eth_class);
	return(RTN_OK);
}

#endif /*_FPGA_ETHERNET_SYSFS_C_*/