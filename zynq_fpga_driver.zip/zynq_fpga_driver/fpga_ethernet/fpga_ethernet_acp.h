#ifndef _FPGA_ETHERNET_ACP_H_
#define _FPGA_ETHERNET_ACP_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "../inc/sf_fpga_acp.h"

#include "fpga_ethernet_main.h"


#define ACP_BD_SIZE			(0x1000)
#define ACP_DATA_SIZE		(0x80000)
#define ACP_DATA_SIZE_SHARE	(0x400000)

#define ACP_DATA_SIZE_SPM	(0x80000)		/*ACP_DATA_SIZE_SHARE_PRE_MAC*/

#define ACP_PIPE_MAX	(0x20)

#define ACP_ETHERNET_TYPE	(1)

#define ACP_TX_PIPE_BASE		(0x10)	
#define ETHNERNET_ACP_RX		(0x40)

#define SM_REMAP_LIST_CNT	(0x40)

#define BD_SN(p)			((*((volatile uint32*)p)>>16) & 0x0000FFFF)
#define BD_LEN(p)			((*(volatile uint32*)p) & 0x0000FFFF)
#define BD_DATA_ADDR(p)		((uint32)*((volatile uint32*)p+1))
#define BD_STATE_FLG(p)		((*(((volatile uint32*)p+2))>>28) & 0xF)
#define BD_DATA_TYPE(p)		(*(((volatile uint32*)p+2)) & 0xFF)
#define BD_NET_MASK(p)		(*((volatile uint32*)p+3))

#define DATA_SN(p)			((*((volatile uint32*)p)>>16) & 0x0000FFFF)
#define DATA_LEN(p)			((*(volatile uint32*)p) & 0x0000FFFF)
#define DATA_TYPE(p)		((*(((volatile uint32*)p+1))>>24) & 0x000000FF)
#define DATA_VAL_LEN(p)		((*((volatile uint32*)p+1)) & 0x0000FFFF)

#define ARRAYSIZEOF(a)   (sizeof(a)/sizeof(a[0]))

#define DATA_PORT_INFO(p)	((*(((volatile uint32*)p+2))>>24) & 0x000000FF)
#define DATA_VAL_DATA(p)	((uint32*)p+6)

#define XMIT_OPT_MASK	(0x01)
#define XMIT_STA_MASK	(0x02)
typedef enum {
	to_pipe		= 0,
	to_vbd 		= 0x01,
	is_rebound 	= 0x02,
} _XMIT_STATUS_;

typedef enum {
	ACP_PIPE_DATA_ADDR 		= 0x00,
	ACP_PIPE_DATA_DEPTH		= 0x04,
	ACP_PIPE_BD_ADDR 		= 0x08,
	ACP_PIPE_BD_DEPTH		= 0x0C,
	ACP_PIPE_IGR_PS_RD		= 0x10,
	ACP_PIPE_IGR_PL_BD_WR	= 0x14,
	ACP_PIPE_IGR_ATTRIB		= 0x18,
	ACP_PIPE_SEG_LENGTH		= 0x200,
	ACP_PIPE_BASE			= 0x1000,
} _PIPE_DATA_OFFSET_T;

#define MAC_VBD_MAX		(0x100)
typedef struct vbd_info_stru{
	acp_bd_t	bd[MAC_VBD_MAX];
	char		is_xmited[MAC_VBD_MAX];
	uint32		tx_pipe_no;
	uint32		wr_bd;
	uint32		rd_bd;
	uint32		wr_data;
	uint32		rd_data;
	uint32		first_flag;
} vbd_info_t;

typedef struct sm_remap_info_stru{
	uint32 phy_addr;
	uint32 remap_addr;
	uint32 size;
	uint32 is_used;
} sm_remap_info_t;

typedef struct fpga_ethernet_pipe_debug_stru {
	uint32 rxproc_data_out;
	uint32 rxproc_sn_unmatch;
	uint32 rxproc_len_unmatch;

	uint32 txproc_data_unempty;
	uint32 txproc_data_full;
	
} fpga_ethernet_pipe_debug_t;

extern int fpga_ethernet_port_connect_pipe_smp(fpga_ethernet_port_t *port_attr);
extern int fpga_ethernet_port_connect_pipe_amp(fpga_ethernet_port_t *port_attr);
extern int show_sm_remap_list(char *buf);
extern int get_rx_pipe_ports_mask(int32 pipe_no);
extern int proc_acp_pipe_read(int pipe_no, int rx_cnt, uint32 *data_offset,
							int (*eth_pack_callback)(int port_no, uint32* pdata));
extern int eth_acp_pipe_write(uint32 port_no, uint32 tx_pipe_no, char* wr_buf, int len, uint32 to_vbd);
extern int vbd_to_bd(void);
extern int fpga_ethernet_acp_init(void);
#endif /* _FPGA_ETHERNET_ACP_H_ */
