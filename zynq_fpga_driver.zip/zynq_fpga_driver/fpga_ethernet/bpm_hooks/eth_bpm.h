#ifndef _ETH_BPM_H_
#define _ETH_BPM_H_
/* sf back proc module*/

#include "../../inc/sf_fpga_acp.h"
#include "../../inc/sf_fpga_eth_bpm.h"
typedef struct eth_bpm_hook_stru{
    int eth_port_mask;
   	void *cb_func;
} eth_bpm_hook_t;

typedef struct eth_bpm_debug_stru{
    uint32 rx_rtn_drop;
	uint32 rx_rtn_no_care;
	uint32 rx_rtn_rebound;
	uint32 rx_rtn_unknow;
	
    uint32 tx_rtn_tx_proced;
	uint32 tx_rtn_no_care;
	uint32 tx_rtn_unknow;
} eth_bpm_debug_t;

extern int eth_bpm_init(void);
extern int eth_bpm_recv_cb(int eth_port,int eth_mac,char* recv_bd_data);
extern int eth_bpm_xmit_cb(int eth_port,char* xmit_bd_data);

#endif  /* _ETH_BPM_H_ */
