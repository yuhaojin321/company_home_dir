#include <linux/module.h>
#include <linux/kernel.h>

#include "../fpga_ethernet_main.h"
#include "../fpga_ethernet_acp.h"
#include "fpga_ethernet_gp.h"
#include "eth_bpm.h"

#define ETH_BPM_HOOK_CNT	(0x20)

static eth_bpm_hook_t eth_bpm_rx_hook_tal;
#define RX_HOOK_MASK()		(eth_bpm_rx_hook_tal.eth_port_mask)
#define RX_HOOK_FUNC()		(eth_bpm_rx_hook_tal.cb_func)

//static int tx_hook_pos = 0;
static eth_bpm_hook_t eth_bpm_tx_hook_tal;
#define TX_HOOK_MASK()		(eth_bpm_tx_hook_tal.eth_port_mask)
#define TX_HOOK_FUNC()		(eth_bpm_tx_hook_tal.cb_func)

static eth_bpm_debug_t eth_bpm_debug_info[FPGA_PORT_MAX];

int show_bpm_debug_info(char *buf)
{
	int port_no = 0;
	
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;

	rs = sprintf(ps, "\n#########BPM DEBUG INFO#########\n");	
	len = len + rs;
	ps = ps + rs;
	
	for(port_no=0; port_no<FPGA_PORT_MAX; port_no++) {

	if(port2mac(port_no) == RTN_ERR) continue;
	
	rs = sprintf(ps, "port_%d: rx(rtn_drop:%d rtn_no_care:%d rtn_rebound:%d rtn_unknow:%d) tx(rtn_tx_proced:%d rtn_no_care:%d rtn_unknow:%d)\n"
					, port_no
					, eth_bpm_debug_info[port_no].rx_rtn_drop
					, eth_bpm_debug_info[port_no].rx_rtn_no_care
					, eth_bpm_debug_info[port_no].rx_rtn_rebound
					, eth_bpm_debug_info[port_no].rx_rtn_unknow
					, eth_bpm_debug_info[port_no].tx_rtn_tx_proced
					, eth_bpm_debug_info[port_no].tx_rtn_no_care
					, eth_bpm_debug_info[port_no].tx_rtn_unknow);
	
		len = len + rs;
		ps = ps + rs;
	}
	
	return(len);
}

int  eth_bpm_init(void)
{

	eth_bpm_rx_hook_tal.eth_port_mask = 0;
	eth_bpm_rx_hook_tal.cb_func = NULL;
		
	eth_bpm_tx_hook_tal.eth_port_mask = 0;
	eth_bpm_tx_hook_tal.cb_func = NULL;

    return (RTN_OK);
}

int eth_bpm_rx_register(int eth_port_mask, void *rx_cb)
{
	
    if(rx_cb == NULL) {
        printk("Rx_cb is null!\n");
        return(RTN_ERR);
    }

    eth_bpm_rx_hook_tal.eth_port_mask = eth_port_mask;
    eth_bpm_rx_hook_tal.cb_func = rx_cb;

    return(RTN_OK);
}
EXPORT_SYMBOL_GPL(eth_bpm_rx_register);

int eth_bpm_tx_register(int eth_port_mask, void *tx_cb)
{
    if(tx_cb == NULL) {
        printk("Tx_cb is null!\n");
        return(RTN_ERR);
    }

    eth_bpm_tx_hook_tal.eth_port_mask = eth_port_mask;
    eth_bpm_tx_hook_tal.cb_func = tx_cb;

    return(RTN_OK);
}
EXPORT_SYMBOL_GPL(eth_bpm_tx_register);

#define REBOUND_DATA_LEN    (256)
static char rebound_data[REBOUND_DATA_LEN] = {0};

int eth_bpm_recv_cb(int eth_port, int eth_mac, char* recv_bd_data)
{
    int rs = RTN_NO_CARE;
	int port_mask = 1<<eth_port;
    CB_RTN (*eth_recv_cb)(int eth_port, char* recv_bd_data, char* rebound_skb_data) = NULL;
    fpga_ethernet_port_t* port_info = NULL;


	if((RX_HOOK_MASK()&port_mask) == 0)
		return(rs);
	
	eth_recv_cb = RX_HOOK_FUNC();

	rs = eth_recv_cb(eth_mac,recv_bd_data,rebound_data);

	if(rs == RTN_REBOUND) {
		eth_bpm_debug_info[eth_port].rx_rtn_rebound++;
	} else if(rs == RTN_NO_CARE) {
		eth_bpm_debug_info[eth_port].rx_rtn_no_care++;
	} else if(rs == RTN_DROP) {
		/*drop illegal sntp pkg*/
		eth_bpm_debug_info[eth_port].rx_rtn_drop++;
		return(rs);
	} else {
		eth_bpm_debug_info[eth_port].rx_rtn_unknow++;
	}
	
	if(unlikely(rs == RTN_REBOUND)) {
		port_info = get_port_info(eth_port);
		if(unlikely(port_info == NULL)) {
			printk("Get port_%d attr fail!\n",eth_port);
			return(RTN_ERR);
		}

		rs = eth_acp_pipe_write(eth_port,port_info->tx_pipe,rebound_data,90,(to_pipe|is_rebound));

		rs = RTN_DROP;
	} else {
		rs = RTN_NO_CARE;
	}

    return(rs);
}

int eth_bpm_xmit_cb(int eth_port, char* xmit_bd_data)
{
    int rs = RTN_NO_CARE;
	int port_mask = 1<<eth_port;
    CB_RTN (*eth_xmit_cb)(int eth_port, char* xmit_bd_data) = NULL;

	if((TX_HOOK_MASK()&port_mask) == 0)
	        return(rs);

	eth_xmit_cb = TX_HOOK_FUNC();

	rs = eth_xmit_cb(eth_port,xmit_bd_data);
	
	if(rs == RTN_TX_PROCED) {
		eth_bpm_debug_info[eth_port].tx_rtn_tx_proced++;
	} else if(rs == RTN_NO_CARE) {
		eth_bpm_debug_info[eth_port].tx_rtn_no_care++;
	} else {
		eth_bpm_debug_info[eth_port].tx_rtn_unknow++;
	}
	
    return(rs);
}
