#ifndef _GP_IOREMAP_H_
#define _GP_IOREMAP_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "gp_module_main.h"

typedef struct gp_remap_stru {
	uint32 gp_global;
	uint32 gp_pre;
	uint32 gp_pre_7010;
	uint32 gp_acp;
	uint32 gp_mac[MAX_MAC_CNT];
} gp_remap_t;

#define GP_REMAP_LIST_CNT	(0x40)
typedef struct gp_remap_info_stru{
	uint32 phy_addr;
	uint32 remap_addr;
	uint32 size;
	uint32 is_used;
} gp_remap_info_t;

extern sint32 gp_ioremap_init(uint32 gp_base_addr);
extern sint32 gp_addr_unmap(uint32 gp_base_addr);

extern uint32 get_gp_global_remap(void);
extern uint32 get_gp_pre_remap(void);
extern uint32 get_gp_acp_remap(void);
extern uint32 get_gp_mac_remap(int macN);
extern int show_gp_remap_list(char *buf);

#endif