#ifndef _GP_MODULE_C_
#define _GP_MODULE_C_

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioport.h>

#include "../inc/sf_fpga_gp.h"

#include "gp_module_sysfs.h"
#include "gp_ioremap.h"
#include "gp_module_main.h"

#ifdef CONFIG_SMP_GP
	#pragma message("Complie gp smp mode GP:0x40000000!")
#else
	#pragma message("Complie gp amp mode GP:0x80000000!")
#endif

static uint32 gp_baseAddr = 0;

int32 do_gp_info_show(char *buf)
{
	uint32 gp_global_vaddr = 0;
	uint32 tmp = 0;
       
	char *ps = buf;
	int len = 0;
	int rs = 0;
         
	gp_global_vaddr = get_gp_global_remap();
	if(gp_global_vaddr == (uint32)NULL) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!"
				, __FUNCTION__
				, __LINE__);
		return(len);
	}
      
	rs = sprintf(ps, "\nDRIVER:%s GIT_VER:%s\n",GP_MODULE_DEV_NAME,GP_MODULE_VER_INFO);		
	len = len + rs;
	ps = ps + rs;
	
	rs = sprintf(ps, "\n#########FPGA INFO#########\n");		
	len = len + rs;
	ps = ps + rs;

	rs = sprintf(ps, "FPGA_ID:0x%08x		FPGA_TICK:0x%08x @ZYNQ_%d\n",
				REG_RD(gp_global_vaddr+FPGA_ID_INFO_OFFSET),
				REG_RD(gp_global_vaddr+FPGA_HEART_BEAT_OFFSET),
				REG_RD(gp_global_vaddr+FPGA_CPU_INFO_OFFSET)&0x0F);
	len = len + rs;
	ps = ps + rs;
       
	tmp = REG_RD(gp_global_vaddr+FPGA_DATA_INFO_OFFSET);
	rs = sprintf(ps, "FPGA_YMD:%d-%d-%d", (tmp>>16)&0xffff, (tmp>>8)&0xff, tmp&0xff);
	len = len + rs;
	ps = ps + rs;
       
	tmp = REG_RD(gp_global_vaddr+FPGA_VER_INFO_OFFSET);
	rs = sprintf(ps, "		FPGA_VER:%02x.%02x.%02x.%02x\n", (tmp>>24)&0xff, (tmp>>16)&0xff, (tmp>>8)&0xff, tmp&0xff);
	len = len + rs;
	ps = ps + rs;
    
	rs = sprintf(ps, "#############################################################\n");
	len = len + rs;
	ps = ps + rs;
	
	return(len);
}

int __init sf_gp_module_init(void)
{
	int32 rs = 0;

#ifdef CONFIG_SMP_GP
	gp_baseAddr = 0x40000000;
#else
	gp_baseAddr = 0x80000000;
#endif
	
	printk("%s COMPILE TIME:%s %s\n",GP_MODULE_DEV_NAME,__DATE__,__TIME__);
	printk("VER:%s\n",GP_MODULE_VER_INFO);
	printk("GP BASE ADDR:0x%08x\n",gp_baseAddr);
	
	rs = gp_ioremap_init(gp_baseAddr);
	if(rs != RTN_OK) {
		printk("%s(%d): gp_ioremap_init error!\n"
				, __FUNCTION__
				, __LINE__);
	}

	gp_sysfs_create(GP_MODULE_DEV_NAME);
	
	return(RTN_OK);
}

void __exit sf_gp_module_exit(void)
{
	gp_sysfs_release();
	gp_addr_unmap(gp_baseAddr);
	
	return;
}

module_init(sf_gp_module_init);
module_exit(sf_gp_module_exit);

MODULE_AUTHOR("cuijinjin@sf-auto");
MODULE_DESCRIPTION("zynq fpga gp module:"GP_MODULE_VER_INFO);
MODULE_LICENSE("Dual BSD/GPL");

#endif