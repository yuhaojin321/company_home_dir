#ifndef _GP_MODULE_MAIN_H_
#define _GP_MODULE_MAIN_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "../ver_inc/git_ver.h"

#define GP_MODULE_DEV_NAME	"sf_gp_module"
#define GP_MODULE_VER_INFO	GIT_COMMIT_ID_STR

#define MAX_MAC_CNT			(16)
#define MAX_PORT_CNT		(16)

typedef enum {
	GP_GLOBAL_OFFSET 		= 0,
	GP_PRE_OFFSET			= 0x40000,
	GP_ACP_OFFSET			= 0x80000,
	GP_MAC_BASE_OFFSET		= 0x400000,
	GP_PRE_7010_OFFSET		= 0x1000000,
} _GP_OFFSET_T;

#define GP_MAC_OFFSET(x)     (GP_MAC_BASE_OFFSET + 0x40000 * x)

typedef enum {
	GP_GLOBAL_SIZE 		= 0x40000,
	GP_PRE_SIZE			= 0x40000,
	GP_ACP_SIZE			= 0x40000,
	GP_MAC_SIZE			= 0x40000,
} _GP_SIZE_T;

typedef enum {
	FPGA_ID_INFO_OFFSET			= GP_GLOBAL_OFFSET + 0,
	FPGA_VER_INFO_OFFSET		= GP_GLOBAL_OFFSET + 0x04,
	FPGA_DATA_INFO_OFFSET		= GP_GLOBAL_OFFSET + 0x08,
	FPGA_HEART_BEAT_OFFSET		= GP_GLOBAL_OFFSET + 0x0C,
	FPGA_CPU_INFO_OFFSET		= GP_GLOBAL_OFFSET + 0x34,
} _GP_GLOBAL_OFFSET_T;

extern int32 do_gp_info_show(char *buf);
#endif
