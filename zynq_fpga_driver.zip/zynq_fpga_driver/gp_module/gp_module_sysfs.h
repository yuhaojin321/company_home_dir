#ifndef _GP_MODULE_SYSFS_H_
#define _GP_MODULE_SYSFS_H_

extern int gp_sysfs_create(const char *dev_name);
extern int gp_sysfs_release(void);

#endif