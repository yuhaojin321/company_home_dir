#ifndef _GP_IOREMAP_C_
#define _GP_IOREMAP_C_

#include <linux/kernel.h>
#include <linux/gfp.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/blkdev.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/device.h>
#include <linux/of.h>

#include "gp_ioremap.h"

static gp_remap_info_t remap_list[GP_REMAP_LIST_CNT];

int show_gp_remap_list(char *buf)
{
	int pos 	= 0;
	
	char *ps 	= buf;
	int	rs 		= 0;
	int len 	= 0;
	
	rs = sprintf(ps, "\n#########GP REMAP INFO#########\n");	
	len = len + rs;
	ps = ps + rs;
	
	for(pos=0; pos<GP_REMAP_LIST_CNT; pos++) {
		if(remap_list[pos].is_used == 0)	continue;
		
		rs = sprintf(ps, "phy:0x%08x remap:0x%08x size:0x%08x\n"
						, remap_list[pos].phy_addr
						, remap_list[pos].remap_addr
						, remap_list[pos].size);
		
		len = len + rs;
		ps = ps + rs;
	}
	
	return(len);
}

static int gp_module_map(uint32 phyaddr, uint32 size, uint32 *vaddr, const char *name)
{
	int pos = 0;
	
	if (!request_mem_region(phyaddr, size, name)) {
		pr_err("%s(%d) %s request_mem_region addr:0x%08x fail.\n", __FUNCTION__, __LINE__, name,phyaddr);
			return -EBUSY;
	}
#define GP_MT_UNCACHED		(4)
	*vaddr = (uint32)__arm_ioremap(phyaddr, size, GP_MT_UNCACHED);
	if (!*vaddr) {
		pr_err("%s(%d)ioremap() failed\n", __FUNCTION__, __LINE__);
		release_mem_region(phyaddr, size);
		return -EFAULT;
	}
	
	for(pos=0; pos<GP_REMAP_LIST_CNT; pos++) {
		if(remap_list[pos].is_used == 0)	break;
	}
	
	if(pos != GP_REMAP_LIST_CNT) {
		remap_list[pos].is_used 	= 1;
		remap_list[pos].phy_addr 	= phyaddr;
		remap_list[pos].remap_addr 	= *vaddr;
		remap_list[pos].size 		= size;
	}

	return(RTN_OK);
}

static void gp_module_unmap(uint32 phyaddr, uint32 size, uint32 vaddr, const char *name)
{
	int pos = 0;
	
	iounmap((void *)vaddr);
	release_mem_region(phyaddr, size);
	
	for(pos=0; pos<GP_REMAP_LIST_CNT; pos++) {
		if(remap_list[pos].phy_addr == phyaddr)	break;
	}
	
	if(pos != GP_REMAP_LIST_CNT) {
		remap_list[pos].is_used 	= 0;
	}
	
	return;
}

static gp_remap_t gp_remap = {
	.gp_global 	= (uint32)NULL,
	.gp_pre		= (uint32)NULL,
	.gp_pre_7010= (uint32)NULL,
	.gp_acp		= (uint32)NULL,
	.gp_mac		= {(uint32)NULL}
};

uint32 get_gp_global_remap(void)
{	
	return(gp_remap.gp_global);
}
EXPORT_SYMBOL_GPL(get_gp_global_remap);

uint32 get_gp_pre_remap(void)
{
	return(gp_remap.gp_pre);
}
EXPORT_SYMBOL_GPL(get_gp_pre_remap);

uint32 get_gp_pre_7010_remap(void)
{
	return(gp_remap.gp_pre_7010);
}
EXPORT_SYMBOL_GPL(get_gp_pre_7010_remap);

uint32 get_gp_acp_remap(void)
{
	return(gp_remap.gp_acp);
}
EXPORT_SYMBOL_GPL(get_gp_acp_remap);

uint32 get_gp_mac_remap(int macN)
{
	return(gp_remap.gp_mac[macN]);
}
EXPORT_SYMBOL_GPL(get_gp_mac_remap);

sint32 gp_ioremap_init(uint32 gp_base_addr)
{
	int rs = RTN_OK;
	int macN = 0;
	
	rs = gp_module_map(gp_base_addr+GP_GLOBAL_OFFSET,GP_GLOBAL_SIZE,&(gp_remap.gp_global),GP_MODULE_DEV_NAME);
	if(rs != RTN_OK) {
		gp_remap.gp_global = 0;
	}
	
	rs = gp_module_map(gp_base_addr+GP_PRE_OFFSET,GP_PRE_SIZE,&(gp_remap.gp_pre),GP_MODULE_DEV_NAME);
	if(rs != RTN_OK) {
		gp_remap.gp_pre = 0;
	}

	rs = gp_module_map(gp_base_addr+GP_PRE_7010_OFFSET,GP_PRE_SIZE,&(gp_remap.gp_pre_7010),GP_MODULE_DEV_NAME);
	if(rs != RTN_OK) {
		gp_remap.gp_pre_7010 = 0;
	}
	
	rs = gp_module_map(gp_base_addr+GP_ACP_OFFSET,GP_ACP_SIZE,&(gp_remap.gp_acp),GP_MODULE_DEV_NAME);
	if(rs != RTN_OK) {
		gp_remap.gp_acp = 0;
	}
	
	for(macN=0; macN<MAX_MAC_CNT; macN++) {
		rs = gp_module_map(gp_base_addr+GP_MAC_OFFSET(macN),GP_MAC_SIZE,&(gp_remap.gp_mac[macN]),GP_MODULE_DEV_NAME);
		if(rs != RTN_OK) {
			gp_remap.gp_mac[macN] = 0;
		}
	}	
	return(rs);
}

sint32 gp_addr_unmap(uint32 gp_base_addr)
{
	int i = 0;
	
	if(gp_remap.gp_global != 0) {
		gp_module_unmap(gp_base_addr+GP_GLOBAL_OFFSET,GP_GLOBAL_SIZE,gp_remap.gp_global,GP_MODULE_DEV_NAME);
	}
	
	if(gp_remap.gp_pre != 0) {
		gp_module_unmap(gp_base_addr+GP_PRE_OFFSET,GP_PRE_SIZE,gp_remap.gp_pre,GP_MODULE_DEV_NAME);
	}

	if(gp_remap.gp_pre_7010 != 0) {
		gp_module_unmap(gp_base_addr+GP_PRE_7010_OFFSET,GP_PRE_SIZE,gp_remap.gp_pre_7010,GP_MODULE_DEV_NAME);
	}
	
	if(gp_remap.gp_acp != 0) {
		gp_module_unmap(gp_base_addr+GP_ACP_OFFSET,GP_ACP_SIZE,gp_remap.gp_acp,GP_MODULE_DEV_NAME);
	}
	
	for(i=0; i<MAX_MAC_CNT; i++) {
		if(gp_remap.gp_mac[i] != 0) {
			gp_module_unmap(gp_base_addr+GP_MAC_OFFSET(i),GP_MAC_SIZE,gp_remap.gp_mac[i],GP_MODULE_DEV_NAME);
		}
	}
	return(RTN_OK);
	
}

#endif /*_GP_IOREMAP_C_*/