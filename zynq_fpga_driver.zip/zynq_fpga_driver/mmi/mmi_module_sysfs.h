#ifndef _MMI_MODULE_SYSFS_H_
#define _MMI_MODULE_SYSFS_H_

extern int mmi_sysfs_create(const char * dev_name);
extern int mmi_sysfs_release(void);

#endif