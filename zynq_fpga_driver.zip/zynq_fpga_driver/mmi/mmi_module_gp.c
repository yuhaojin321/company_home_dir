/*
 *  mmi gp info
 *  gpio also process in this module
 */

#include <linux/printk.h>
#include <linux/string.h>

#include "mmi_module_gp.h"

mmi_gp_remap_t g_mmi_gp_info;


int get_lcd_typ( void )
{
	uint32 reg;
		
	if( g_mmi_gp_info.init != 0xaa ){
		printk("%s(%d): get_lcd_typ error,gp not init!\n", __FUNCTION__, __LINE__);
		return -1;		
	}
	
	reg = REG_RD( g_mmi_gp_info.lcd_type );
	if( (reg==LCD_SMALL_FS8812)||(reg==LCD_BIG_GWMS11564) )
		return reg;
	else {
		printk("%s(%d): MMI LCD type reg error,g_mmi_gp_info.lcd_type 0x%x,reg 0x%x!\n", __FUNCTION__, __LINE__,g_mmi_gp_info.lcd_type,reg);
		return -1;
	}
}

void lcd_d_dir( uint8 dir )
{
	REG_WR(g_mmi_gp_info.lcd_data_dir, dir);
}

uint8 lcd_d_in( void )
{
	uint8 reg;
	
	reg = REG_RD(g_mmi_gp_info.lcd_data_in);
	return reg;
}

// must be called
#include <linux/ioport.h>
#include <asm/io.h>
int lcd_gp_init( void )
{
	memset(&g_mmi_gp_info,0,sizeof(g_mmi_gp_info));

#if 1	
	g_mmi_gp_info.gp_global = get_gp_global_remap();
	if(unlikely(g_mmi_gp_info.gp_global == (uint32)NULL)) {
		printk("%s(%d): GP GLOBAL ADDRESS ERROR!\n", __FUNCTION__, __LINE__);
		return -1;
	}
	g_mmi_gp_info.lcd_type = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_TYPE;
	g_mmi_gp_info.lcd_data_dir = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_DATA_DIR;
	g_mmi_gp_info.lcd_data_in= g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_DATA_IN;
	g_mmi_gp_info.lcd_data_out = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_DATA_OUT;
	g_mmi_gp_info.lcd_led_0 = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LED_OUT_0;
	g_mmi_gp_info.lcd_led_1 = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LED_OUT_1;
	g_mmi_gp_info.lcd_key = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_KEY_INPUT;
#else
	g_mmi_gp_info.gp_global = (uint32)sf_ioremap(0x40000880, 64);	
	if ( !g_mmi_gp_info.gp_global ) {
		printk("%s(%d)ioremap() failed\n", __FUNCTION__, __LINE__);
		release_mem_region(0x40000880, 64);
		return -1;
	}
	g_mmi_gp_info.lcd_type = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_TYPE-0x880;
	g_mmi_gp_info.lcd_data_dir = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_DATA_DIR-0x880;
	g_mmi_gp_info.lcd_data_in= g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_DATA_IN-0x880;
	g_mmi_gp_info.lcd_data_out = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LCD_DATA_OUT-0x880;
	g_mmi_gp_info.lcd_led_0 = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LED_OUT_0-0x880;
	g_mmi_gp_info.lcd_led_1 = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_LED_OUT_1-0x880;
	g_mmi_gp_info.lcd_key = g_mmi_gp_info.gp_global + GP_GLOBAL_MMI_KEY_INPUT-0x880;
#endif


	g_mmi_gp_info.init = 0xaa;
	lcd_d_dir(LCD_DATA_OUTPUT);		// enable output
	return 0;
}

