#ifndef __MMI_MODULE_GP_H__ 
#define __MMI_MODULE_GP_H__

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

#include "../inc/sf_fpga_gp.h"


typedef enum {
	GP_GLOBAL_MMI_LCD_TYPE		 	= 0x880,
	GP_GLOBAL_MMI_LCD_DATA_DIR		= 0x884,	
	GP_GLOBAL_MMI_LCD_DATA_IN		= 0x888,
	GP_GLOBAL_MMI_LCD_CTRL			= 0x88C,
	GP_GLOBAL_MMI_LED_OUT_0			= 0x890,
	GP_GLOBAL_MMI_LED_OUT_1			= 0x894,
	GP_GLOBAL_MMI_KEY_INPUT			= 0x898,
	GP_GLOBAL_MMI_LCD_DATA_OUT		= 0x89C,
} _MMI_REG_ON_GP_T;


typedef enum{
	LCD_SMALL_FS8812				= 0x11,
	LCD_BIG_GWMS11564				= 0x22,
}_MMI_LCD_TYPE_T;

typedef enum{
	LCD_DATA_INPUT					= 0,
	LCD_DATA_OUTPUT					= 1,
}_MMI_LCD_DIR_T;


typedef struct mmi_gp_remap
{
	uint8  init;
	uint32 gp_global;
	uint32 lcd_type;
	uint32 lcd_data_dir;
	uint32 lcd_data_in;
	uint32 lcd_data_out;
	//uint32 lcd_ctrl;
	uint32 lcd_led_0;;
	uint32 lcd_led_1;
	uint32 lcd_key;
}mmi_gp_remap_t;


int lcd_gp_init( void );
int get_lcd_typ( void );
void lcd_d_dir( uint8 dir ); // 0,input;1,output
uint8 lcd_d_in( void );

extern mmi_gp_remap_t g_mmi_gp_info;
static inline void lcd_d_out( uint8 data )
{
	REG_WR(g_mmi_gp_info.lcd_data_out, data);
}



#if 0
// bit_msk  to be set
static inline void lcd_ctl_set_bit( uint16 bit_msk )
{
	REG_WR(g_mmi_gp_info.lcd_ctrl, (bit_msk<<16)|bit_msk);
}

// bit_msk  to be clear
static inline void lcd_ctl_clr_bit( uint16 bit_msk )
{
	REG_WR(g_mmi_gp_info.lcd_ctrl, (bit_msk<<16)|(~bit_msk&0xFFFF));
}
#endif

#endif



