#ifndef __KEY_H__ 
#define __KEY_H__

#include "../inc/basedefine.h"
#include "../inc/basetype.h"


typedef struct key_operations
{
	int (*get_key)( void ); 
}key_operations_t;

typedef struct key_dev
{
	key_operations_t ops;
}key_dev_t;

int mmi_key_init(key_dev_t * dev);

#endif

