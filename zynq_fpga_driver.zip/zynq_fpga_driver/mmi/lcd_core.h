#ifndef __LCD_CORE_H__ 
#define __LCD_CORE_H__

#include "../inc/basedefine.h"
#include "../inc/basetype.h"


typedef struct lcd_operations
{
	int (*flush_fb)( uint8 * frame_buf );		// flush frame buffer to LCD	
	void (*ctrl_backlight)( uint8 isON );
	void (*release)( void );
	void (*wr_cmd_1)(uint8 cmd);
	void (*wr_cmd_2)(uint8 cmd);
	void (*wr_data_1)(uint8 data);
	void (*wr_data_2)(uint8 data);
	uint8 * busy;
}lcd_operations_t;

	
typedef struct lcd_dev
{
	uint8 lcd_typ;				//small:122*32,FS8812; big:240*160,GWMS11564C 	
	uint8 * frame_buf;
	lcd_operations_t ops;
}lcd_dev_t;


int lcd_init( lcd_dev_t * dev );
void lcd_exit( lcd_dev_t * dev );

#endif



