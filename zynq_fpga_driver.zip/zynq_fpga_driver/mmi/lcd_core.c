/*
 *  LCD core layer, standard interface for upper layer
 *  There are different LCDs in the system,they must register to LCD core layer.
 */

#include <linux/slab.h>

#include "lcd_core.h"
#include "lcd_hw_fs8812.h"
#include "../inc/sf_fpga_gp.h"
#include "mmi_module_gp.h"

 
int lcd_init( lcd_dev_t * dev )
{
	int lcd_type=0;

	if( dev == NULL )
		return -1;

	lcd_type = get_lcd_typ();
	if( LCD_SMALL_FS8812 == lcd_type ){		// detect lcd type
		dev->lcd_typ = LCD_SMALL_FS8812;
		if( fs8812_init(dev) < 0 ){
			printk("%s(%d): init lcd hw error\n", __FUNCTION__, __LINE__);	
			return -1;
		}
		else
			printk("%s(%d): small lcd(FS8812).\n", __FUNCTION__, __LINE__);
	}	
	else if( LCD_BIG_GWMS11564 == lcd_type ){
		dev->lcd_typ = LCD_BIG_GWMS11564;
		printk("%s(%d): big lcd(GWMS11564).\n", __FUNCTION__, __LINE__);
		return -1;	// support later
	}
	else{
		printk("%s(%d): unknow lcd type.\n", __FUNCTION__, __LINE__);
		return -1;
	}

	/* mmap buffer alloc */
	dev->frame_buf = kmalloc(PAGE_SIZE,GFP_KERNEL);
	if( dev->frame_buf == NULL ) {
		printk("%s(%d): malloc frame buffer error.\n", __FUNCTION__, __LINE__);
		return(RTN_ERR);
	}

	return 0;
}


void lcd_exit( lcd_dev_t * dev )
{
	if(dev->ops.release)
		dev->ops.release();
	kfree( dev->frame_buf );
}



















