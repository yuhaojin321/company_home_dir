#ifndef __LCD_HW_FS8812_H__
#define __LCD_HW_FS8812_H__

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "lcd_core.h"


/* bit of reg GP_GLOBAL_MMI_LCD_CTRL */
#define LCD_CTRL_RST_MASK			0x00000001
#define LCD_CTRL_CD_MASK			0x00000002
#define LCD_CTRL_RW_MASK			0x00000004
#define LCD_CTRL_E1_MASK			0x00000008
#define LCD_CTRL_E2_MASK			0x00000010
#define LCD_CTRL_LED_CSL_MASK		0x00000020


#define FS8812_REG_DISP_ON			0xAF
#define FS8812_REG_DISP_OFF			0xAE
#define FS8812_REG_DUTY_SEL_16		0xA8
#define FS8812_REG_DUTY_SEL_32		0xA9
#define FS8812_REG_PAGE_BASE		0xB8
#define FS8812_REG_COL_0			0x00


#define LCD_T_FR_MAX_NS			15
#define LCD_T_DS_MIN_NS			80		
#define LCD_T_DH_MIN_NS			10	
#define LCD_T_MARGIN_NS			5		

#define LCD_8812_ROW_BYTES		16
#define LCD_8812_PAGE_ROWS		8
#define LCD_PAGE_BYTES			(LCD_8812_ROW_BYTES*LCD_8812_PAGE_ROWS)

typedef struct
{
	int rst_pin;
	int cd_pin;
	int rw_pin;
	int e1_pin;
	int e2_pin;
	int lcd_csl_pin;
	uint8 busy;
}fs8812_info_t;


int fs8812_init( lcd_dev_t * dev );



#endif

