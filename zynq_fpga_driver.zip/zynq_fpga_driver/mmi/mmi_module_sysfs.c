#ifndef _LCD_MODULE_SYSFS_C_
#define _LCD_MODULE_SYSFS_C_

/*
 * Implement MMI information use sysfs.
 * Copyright (C) 2017 sf-auto Ltd. 
 *
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>

#include "mmi_module_main.h"
#include "mmi_module_sysfs.h"

static ssize_t mmi_info_show(struct class *class, struct class_attribute *attr, char *buf)
{
	int rs = 0;
	int len = 0;
	
	rs = do_mmi_info_show(buf);
	len = len + rs;
	
	return(len);
}

static ssize_t mmi_info_store(struct class *class, struct class_attribute *attr, const char *buf, size_t count)
{
	return ~0;
}

static struct class_attribute dev_attr_mmi_info = {
	.attr = {
		.name = MMI_MODULE_DEV_NAME"_info",		// must be different with dev name
		.mode = S_IWUSR | S_IRUGO,
	},
	.show = mmi_info_show,
	.store = mmi_info_store,
};

int mmi_sysfs_create(const char *dev_name)
{
	int rs = RTN_ERR;
	
	g_mmi_dev.class = class_create(THIS_MODULE, dev_name);
	if(IS_ERR( g_mmi_dev.class ) != 0) {
		printk(KERN_ALERT"Failed to create device class.\n");
		return(RTN_ERR);
	}
	
	//dev_attr_mmi_info.attr.name = dev_name;
	rs = class_create_file(g_mmi_dev.class, &dev_attr_mmi_info);
	if(rs < 0) {
		printk(KERN_ALERT"Failed to create attribute info device.\n");
		rs = RTN_ERR;
		goto CREAT_FILE_ERR;
	}
	return(RTN_OK);	

CREAT_FILE_ERR:
	class_destroy(g_mmi_dev.class);
	return rs;
}

int mmi_sysfs_release(void)
{
	class_remove_file(g_mmi_dev.class, &dev_attr_mmi_info);
	class_destroy(g_mmi_dev.class);
	return(RTN_OK);
}


#endif