#ifndef __LED_H__ 
#define __LED_H__

#include "../inc/basedefine.h"
#include "../inc/basetype.h"


#define MMI_LED0        0
#define MMI_LED15       15
#define MMI_LED16       16
#define MMI_LED17       17



typedef struct led_operations
{
	int (*led_ctrl)( uint8 led, uint8 ctrl ); 
	void (*led_all_red)(void);
	void (*led_all_green)(void);
	void (*led_all_rg)(void);
	void (*led_all_off)(void);	
}led_operations_t;

typedef struct led_dev
{
	led_operations_t ops;
}led_dev_t;


int led_init( led_dev_t * dev );

#endif
