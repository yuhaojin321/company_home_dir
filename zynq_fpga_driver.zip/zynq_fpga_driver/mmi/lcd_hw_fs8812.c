/*
 * LCD FS-8812S20022 module from JingHua company
 * 122*32 dot,driver IC is SBN1661G_xxx
 */
 
#include <linux/printk.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <asm/neon.h>
#include <linux/of.h>
#include <linux/of_gpio.h>

#include "lcd_hw_fs8812.h"
#include "mmi_module_gp.h"


uint8 * g_convert_buf;	
fs8812_info_t  g_fs8812_info;
uint8 g_busy;

// there are 2 driver chips in the lcd module
void write_cmd_1( uint8 cmd )
{
	gpio_set_value(g_fs8812_info.cd_pin,0);
	gpio_set_value(g_fs8812_info.rw_pin,0);
	lcd_d_out(cmd);
	gpio_set_value(g_fs8812_info.e1_pin,1);
	ndelay(LCD_T_DS_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);
	gpio_set_value(g_fs8812_info.e1_pin,0);
	ndelay(LCD_T_DH_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);
}


void write_data_1( uint8 data )
{
	gpio_set_value(g_fs8812_info.cd_pin,1);
	gpio_set_value(g_fs8812_info.rw_pin,0);
	lcd_d_out(data);
	gpio_set_value(g_fs8812_info.e1_pin,1);
	ndelay(LCD_T_DS_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);
	gpio_set_value(g_fs8812_info.e1_pin,0);
	ndelay(LCD_T_DH_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);	
}

void write_cmd_2( uint8 cmd )
{
	gpio_set_value(g_fs8812_info.cd_pin,0);
	gpio_set_value(g_fs8812_info.rw_pin,0);	
	lcd_d_out(cmd);
	gpio_set_value(g_fs8812_info.e2_pin,1);
	ndelay(LCD_T_DS_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);
	gpio_set_value(g_fs8812_info.e2_pin,0);
	ndelay(LCD_T_DH_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);	
}


void write_data_2( uint8 data )
{
	gpio_set_value(g_fs8812_info.cd_pin,1);
	gpio_set_value(g_fs8812_info.rw_pin,0);		
	lcd_d_out(data);
	gpio_set_value(g_fs8812_info.e2_pin,1);
	ndelay(LCD_T_DS_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);
	gpio_set_value(g_fs8812_info.e2_pin,0);
	ndelay(LCD_T_DH_MIN_NS+LCD_T_FR_MAX_NS+LCD_T_MARGIN_NS);	
}

	
// init the lcd signal,the delay time is from menufactor
void fs8812_init_cfg( void )
{
	gpio_direction_output(g_fs8812_info.rst_pin,1);
	gpio_direction_output(g_fs8812_info.cd_pin,0);
	gpio_direction_output(g_fs8812_info.rw_pin,0);
	gpio_direction_output(g_fs8812_info.e1_pin,0);
	gpio_direction_output(g_fs8812_info.e2_pin,0);
	gpio_direction_output(g_fs8812_info.lcd_csl_pin,1);

	// reset
	gpio_set_value(g_fs8812_info.rst_pin,1);
	mdelay(15);
	gpio_set_value(g_fs8812_info.rst_pin,0);
	mdelay(15);
	gpio_set_value(g_fs8812_info.rst_pin,1);

	// reg init
	write_cmd_1(FS8812_REG_DUTY_SEL_32);
	mdelay(3);
	write_cmd_2(FS8812_REG_DUTY_SEL_32);
	mdelay(3);
	write_cmd_1(FS8812_REG_DISP_ON);
	mdelay(3);
	write_cmd_2(FS8812_REG_DISP_ON);
	mdelay(3);	

}


extern int fs8812_cvt_buf( uint8 * dst, uint8 * src ); // from mmi_neon  module
int fs8812_flush_fb(uint8 * frame_buf )
{
	uint8 page,seg;

	g_busy = 1;
	// convert the frame_buf for fs8812
	kernel_neon_begin();
	fs8812_cvt_buf( g_convert_buf, frame_buf );
	kernel_neon_end();

    for(page=0;page<=3;page++)
    {
         write_cmd_1(FS8812_REG_PAGE_BASE+page);
         mdelay(1);
         write_cmd_2(FS8812_REG_PAGE_BASE+page);
         mdelay(1);
         write_cmd_1(FS8812_REG_COL_0);
         mdelay(1);
         write_cmd_2(FS8812_REG_COL_0);
         mdelay(1);
         for(seg=0;seg<61;seg++)		//122*32dot,2 chips
			   	write_data_1(g_convert_buf[seg]);
		 for(seg=61;seg<122;seg++)
		 		write_data_2(g_convert_buf[seg]);
    }
	g_busy = 0;
	return 0;
}


void fs8812_backlight( uint8 isON )
{
	if( isON )
		gpio_set_value(g_fs8812_info.lcd_csl_pin,1);
	else
		gpio_set_value(g_fs8812_info.lcd_csl_pin,0);
}

void fs8812_release( void )
{
	gpio_free(g_fs8812_info.lcd_csl_pin);
	gpio_free(g_fs8812_info.e2_pin);
	gpio_free(g_fs8812_info.e1_pin);
	gpio_free(g_fs8812_info.rw_pin);
	gpio_free(g_fs8812_info.cd_pin);
	gpio_free(g_fs8812_info.rst_pin);
}


int fs8812_init( lcd_dev_t * dev )
{
	struct device_node * np;
	
	if( dev == NULL )
		return -1;

	/* GPIO of control signals */
	np = of_find_compatible_node(NULL,NULL, "sf,mmi-ps");
	g_fs8812_info.rst_pin =of_get_named_gpio(np, "rst-gpio", 0);
	g_fs8812_info.cd_pin =of_get_named_gpio(np, "cd-gpio", 0);
	g_fs8812_info.rw_pin =of_get_named_gpio(np, "rw-gpio", 0);
	g_fs8812_info.e1_pin =of_get_named_gpio(np, "e1-gpio", 0);
	g_fs8812_info.e2_pin =of_get_named_gpio(np, "e2-gpio", 0);
	g_fs8812_info.lcd_csl_pin =of_get_named_gpio(np, "lcd-csl-gpio", 0);	
	if (g_fs8812_info.rst_pin  == -EPROBE_DEFER ||
		g_fs8812_info.cd_pin == -EPROBE_DEFER ||
		g_fs8812_info.rw_pin == -EPROBE_DEFER ||
		g_fs8812_info.e1_pin == -EPROBE_DEFER ||
		g_fs8812_info.e2_pin == -EPROBE_DEFER ||
		g_fs8812_info.lcd_csl_pin == -EPROBE_DEFER ){
		printk("\r\n%s(%d): of_get_named_gpio error", __FUNCTION__, __LINE__);
		return -EPROBE_DEFER;		
	}
	if (!gpio_is_valid(g_fs8812_info.rst_pin) ||
		!gpio_is_valid(g_fs8812_info.cd_pin) ||
		!gpio_is_valid(g_fs8812_info.rw_pin) ||
		!gpio_is_valid(g_fs8812_info.e1_pin) ||
		!gpio_is_valid(g_fs8812_info.e2_pin) ||
		!gpio_is_valid(g_fs8812_info.lcd_csl_pin) ) {
		printk("\r\n%s(%d): gpio valid error", __FUNCTION__, __LINE__);
		return(RTN_ERR);
	}

	if( gpio_request(g_fs8812_info.rst_pin, "mmi-rst") < 0 ) {
		printk("\r\n%s(%d): gpio_request mmi-rst error", __FUNCTION__, __LINE__);
		goto RST_GPIO_REQ_ERR;
	}
	if( gpio_request(g_fs8812_info.cd_pin, "mmi-cd") < 0 ) {
		printk("\r\n%s(%d): gpio_request mmi-cd error", __FUNCTION__, __LINE__);
		goto CD_GPIO_REQ_ERR;
	}
	if( gpio_request(g_fs8812_info.rw_pin, "mmi-rw") < 0 ) {
		printk("\r\n%s(%d): gpio_request mmi-rw error", __FUNCTION__, __LINE__);
		goto RW_GPIO_REQ_ERR;
	}
	if( gpio_request(g_fs8812_info.e1_pin, "mmi-e1") < 0 ) {
		printk("\r\n%s(%d): gpio_request mmi-e1 error", __FUNCTION__, __LINE__);
		goto E1_GPIO_REQ_ERR;
	}
	if( gpio_request(g_fs8812_info.e2_pin, "mmi-e2") < 0 ) {
		printk("\r\n%s(%d): gpio_request mmi-e2 error", __FUNCTION__, __LINE__);
		goto E2_GPIO_REQ_ERR;
	}
	if( gpio_request(g_fs8812_info.lcd_csl_pin, "mmi-csl") < 0 ) {
		printk("\r\n%s(%d): gpio_request mmi-csl error", __FUNCTION__, __LINE__);
		goto CSL_GPIO_REQ_ERR;
	}	

	fs8812_init_cfg();

	/* convert buffer alloc */
	g_convert_buf = kmalloc(PAGE_SIZE,GFP_KERNEL);
	if( g_convert_buf == NULL ) {
		printk("\r\n%s(%d): malloc convert buffer error", __FUNCTION__, __LINE__);
		return(RTN_ERR);
	}

	dev->ops.flush_fb = fs8812_flush_fb;
	dev->ops.ctrl_backlight = fs8812_backlight;
	dev->ops.release = fs8812_release;
	dev->ops.wr_cmd_1 = write_cmd_1;
	dev->ops.wr_cmd_2 = write_cmd_2;
	dev->ops.wr_data_1 = write_data_1;
	dev->ops.wr_data_2 = write_data_2;
	dev->ops.busy = &g_busy;
	return 0;

CSL_GPIO_REQ_ERR:
	gpio_free(g_fs8812_info.e2_pin);
E2_GPIO_REQ_ERR:
	gpio_free(g_fs8812_info.e1_pin);
E1_GPIO_REQ_ERR:
	gpio_free(g_fs8812_info.rw_pin);
RW_GPIO_REQ_ERR:
	gpio_free(g_fs8812_info.cd_pin);
CD_GPIO_REQ_ERR:
	gpio_free(g_fs8812_info.rst_pin);
RST_GPIO_REQ_ERR:
	return(RTN_ERR);
	
}

