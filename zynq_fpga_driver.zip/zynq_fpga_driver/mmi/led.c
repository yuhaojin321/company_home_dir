/*
 * led on the MMI
 */

/*
 * LED of mmi
 */
 
#include <linux/printk.h>

#include "led.h"
#include "mmi_module_gp.h"


int led_ctrl( uint8 led, uint8 ctrl )
{
	uint32 led_reg;
	uint8 shift_bit;
	uint32 val;
	
	if( (led>=MMI_LED0) && (led<=MMI_LED15) ) {
		led_reg = g_mmi_gp_info.lcd_led_0;
		shift_bit = led*2;
	}
	else if( (led>=MMI_LED16) && (led<=MMI_LED17) ) {
		led_reg = g_mmi_gp_info.lcd_led_1;
		shift_bit = (led-MMI_LED16)*2;
	}	
	else
		return RTN_ERR;

	val = REG_RD(led_reg);
	val &= ~(0x03<<shift_bit); 	// clear
	val |= (ctrl&0x03)<<shift_bit;
	REG_WR(led_reg, val);

	return RTN_OK;

}

void led_all_red(void)
{
	REG_WR(g_mmi_gp_info.lcd_led_0, 0x55555555);
	REG_WR(g_mmi_gp_info.lcd_led_1, 0x5);
}

void led_all_green(void)
{
	REG_WR(g_mmi_gp_info.lcd_led_0, 0xaaaaaaaa);
	REG_WR(g_mmi_gp_info.lcd_led_1, 0xa);	
}
void led_all_rg(void)
{
	REG_WR(g_mmi_gp_info.lcd_led_0, 0xffffffff);
	REG_WR(g_mmi_gp_info.lcd_led_1, 0xf);	
}

void led_all_off(void)
{
	REG_WR(g_mmi_gp_info.lcd_led_0, 0);
	REG_WR(g_mmi_gp_info.lcd_led_1, 0);		
}


int led_init( led_dev_t * dev )
{
	
	if( dev == NULL )
		return -1;

	dev->ops.led_ctrl = led_ctrl;
	dev->ops.led_all_red = led_all_red;
	dev->ops.led_all_green = led_all_green;
	dev->ops.led_all_rg = led_all_rg;
	dev->ops.led_all_off = led_all_off;

	return 0;
	
}



