/*
 * "v1.0.0,2018.05.29", lcd ok
 * "v1.0.1,2018.05.30", led&key ok
 */


#ifndef _MMI_MODULE_MAIN_H_
#define _MMI_MODULE_MAIN_H_

#include <linux/cdev.h>
#include <linux/types.h>

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "../ver_inc/git_ver.h"
#include "lcd_core.h"
#include "led.h"
#include "key.h"

#define MMI_MODULE_DEV_NAME	"sf_mmi_module"
#define MMI_MODULE_VER_INFO	GIT_COMMIT_ID_STR
#define MMI_MODULE_VER_HUMAN	"v1.0.1,2018.05.30"

typedef struct mmi_dev{
	struct cdev cdev;
	struct class * class;
	dev_t dev_no;
	lcd_dev_t lcd_dev;
	led_dev_t led_dev;
	key_dev_t key_dev;
}mmi_dev_t;

extern int32 do_mmi_info_show(char *buf);

extern mmi_dev_t g_mmi_dev;

#endif
