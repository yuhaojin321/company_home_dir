/*
 * key on the MMI
 */

#include <linux/printk.h>

#include "key.h"
#include "mmi_module_gp.h"


int mmi_get_key( void )
{
	uint32 reg_key;
	#if 1
	reg_key = REG_RD(g_mmi_gp_info.lcd_key);
	if( (~reg_key&0xFFFF) == ((reg_key>>16)&0xFFFF) )
		return reg_key&0xffff;
	return RTN_ERR;
	#else
	reg_key = REG_RD(g_mmi_gp_info.lcd_key);
	//reg_key = 0x55aa;;
	printk(" mmi_get_key 0x%x.\n",reg_key);
	return reg_key;
	#endif
	
}


int mmi_key_init( key_dev_t * dev )
{
	
	if( dev == NULL )
		return -1;

	dev->ops.get_key = mmi_get_key;

	return 0;	
}

