/*
 * the entrance of whole drives
 */


#ifndef _MMI_MODULE_C_
#define _MMI_MODULE_C_

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioport.h>
#include <linux/fs.h>
#include <linux/io.h>
#include <linux/mm.h>

#include "../inc/sf_fpga_gp.h"
#include "../inc/sf_mmi.h"

#include "mmi_module_sysfs.h"
#include "mmi_module_main.h"
#include "lcd_core.h"
#include "mmi_module_gp.h"


//static uint32 gp_baseAddr = 0;
mmi_dev_t g_mmi_dev;

int32 do_mmi_info_show(char *buf)
{       
	char *ps = buf;
	int len = 0;
	int rs = 0;
     
	rs = sprintf(ps, "\nDRIVER:%s GIT_VER:%s,%s\n",MMI_MODULE_DEV_NAME,MMI_MODULE_VER_INFO,MMI_MODULE_VER_HUMAN);		
	len = len + rs;
	ps = ps + rs;
	
	return(len);
}

int mmi_open(struct inode * inode, struct file * filp)
{
	filp->private_data = &g_mmi_dev;
	return 0;
}
#if 0	
ssize_t mmi_read (struct file * filp, char __user * buf, size_t len, loff_t *pos)
{
	printk("\r\nmmi_read\n");
	return 0;
}

ssize_t mmi_write (struct file * filp, const char __user * buf, size_t len, loff_t * pos)
{
	printk("\r\nmmi_write\n");
	return 0;
}
#endif
	
long mmi_ioctl(struct file * filp, unsigned int cmd, unsigned long arg )
{
	mmi_dev_t * mmi_dev = filp->private_data;
	uint8 led;
	uint8 ctrl;

	switch(cmd){
	/* lcd */
	case MMI_CMD_FLUSH_FRM_BUF:
		if(mmi_dev->lcd_dev.ops.flush_fb)
			mmi_dev->lcd_dev.ops.flush_fb( mmi_dev->lcd_dev.frame_buf );
		else
			return -ENODEV;
		break;
	case MMI_CMD_CTRL_BACKLIGH:
		if(mmi_dev->lcd_dev.ops.ctrl_backlight)
			mmi_dev->lcd_dev.ops.ctrl_backlight( arg );
		else
			return -ENODEV;		
		break;
	case MMI_CMD_GET_STATUS:
		if(mmi_dev->lcd_dev.ops.busy)
			return *(mmi_dev->lcd_dev.ops.busy);
		else
			return -ENODEV;		
		break;		

	/* led */
	case MMI_CMD_LED_CTRL:
		if(mmi_dev->led_dev.ops.led_ctrl){
			led = (arg>>8)&0xff;
			ctrl = arg&0x0f;
			mmi_dev->led_dev.ops.led_ctrl(led,ctrl);
		} 
		else
			return -ENODEV;		
		break;
	case MMI_CMD_LED_ALL_OFF:
		if(mmi_dev->led_dev.ops.led_all_off)
			mmi_dev->led_dev.ops.led_all_off();
		else
			return -ENODEV;		
		break;	
	case MMI_CMD_LED_ALL_RED:
		if(mmi_dev->led_dev.ops.led_all_red)
			mmi_dev->led_dev.ops.led_all_red();
		else
			return -ENODEV;		
		break;	
	case MMI_CMD_LED_ALL_GREEN:
		if(mmi_dev->led_dev.ops.led_all_green)
			mmi_dev->led_dev.ops.led_all_green();
		else
			return -ENODEV;		
		break;
	case MMI_CMD_LED_ALL_RG:
		if(mmi_dev->led_dev.ops.led_all_rg)
			mmi_dev->led_dev.ops.led_all_rg();
		else
			return -ENODEV;		
		break;

	/* key */
	case MMI_CMD_KEY_VAL:
		if(mmi_dev->key_dev.ops.get_key)
			return mmi_dev->key_dev.ops.get_key();
		else
			return -ENODEV;		
		break;	
		
	/* just for debug */		
	case MMI_CMD_WR_CMD1:
		if(mmi_dev->lcd_dev.ops.wr_cmd_1)
			mmi_dev->lcd_dev.ops.wr_cmd_1( arg );
		else
			return -ENODEV;		
		break;		
	case MMI_CMD_WR_CMD2:
		if(mmi_dev->lcd_dev.ops.wr_cmd_2)
			mmi_dev->lcd_dev.ops.wr_cmd_2( arg );
		else
			return -ENODEV;		
		break;	
	case MMI_CMD_WR_DATA1:
		if(mmi_dev->lcd_dev.ops.wr_data_1)
			mmi_dev->lcd_dev.ops.wr_data_1( arg );
		else
			return -ENODEV;		
		break;	
	case MMI_CMD_WR_DATA2:
		if(mmi_dev->lcd_dev.ops.wr_data_2)
			mmi_dev->lcd_dev.ops.wr_data_2( arg );
		else
			return -ENODEV;		
		break;			
	
	default:
		printk("unknow mmi command 0x%x.\n",cmd);
		return -ENODEV;
		break;	
	}

	return 0;
}

int mmi_mmap (struct file *filp, struct vm_area_struct * vma)
{
	mmi_dev_t * mmi_dev = filp->private_data;

	if( remap_pfn_range(vma, vma->vm_start,virt_to_phys(mmi_dev->lcd_dev.frame_buf)>>PAGE_SHIFT,vma->vm_end-vma->vm_start,vma->vm_page_prot) ){
		return -EAGAIN;
	}

	return 0;
}


	
int mmi_release(struct inode *inode, struct file *filp)
{
	return 0;
}

struct file_operations g_mmi_fops = {
	.owner = THIS_MODULE,
	.open = mmi_open,
	//.read = mmi_read,
	//.write = mmi_write,
	.mmap = mmi_mmap,
	.unlocked_ioctl = mmi_ioctl,
	.release = mmi_release,
};

int __init sf_mmi_module_init(void)
{
	int ret = 0;
	struct device *class_dev = NULL;

	printk("mmi module ver:%s\n",MMI_MODULE_VER_HUMAN);
	
	ret = lcd_gp_init();
	if( ret<0 ){
		printk("\r\n%s(%d): lcd_gp_init err.", __FUNCTION__, __LINE__);
		return ret;
	}	

	ret = lcd_init(&g_mmi_dev.lcd_dev);
	if( ret<0 ){
		printk("\r\n%s(%d): lcd_init err.", __FUNCTION__, __LINE__);
		return ret;
	}
	ret = led_init(&g_mmi_dev.led_dev);
	if( ret<0 ){
		printk("\r\n%s(%d): led_init err.", __FUNCTION__, __LINE__);
		return ret;
	}
	ret = mmi_key_init(&g_mmi_dev.key_dev);
	if( ret<0 ){
		printk("\r\n%s(%d): key_init err.", __FUNCTION__, __LINE__);
		return ret;
	}
	
	/* char device init */
	mmi_sysfs_create(MMI_MODULE_DEV_NAME);
	cdev_init(&g_mmi_dev.cdev, &g_mmi_fops);
	g_mmi_dev.cdev.owner = THIS_MODULE;
	ret=alloc_chrdev_region(&g_mmi_dev.dev_no, 0, 1, MMI_MODULE_DEV_NAME);
	if( ret < 0 ){
		printk("\r\n%s(%d): alloc dev no err.", __FUNCTION__, __LINE__);
		goto ALLOC_DEV_ERR;
	}
	ret = cdev_add(&g_mmi_dev.cdev, g_mmi_dev.dev_no, 1);
	if(ret){
		printk("\r\n%s(%d): cdev add err.", __FUNCTION__, __LINE__);
		ret=RTN_ERR;
		goto CDEV_ADD_ERR;
	}	
	/* create /dev/xxx file */
	class_dev = device_create(g_mmi_dev.class, NULL, g_mmi_dev.dev_no, NULL, MMI_MODULE_DEV_NAME"0");
	if (IS_ERR(class_dev)) {
		printk("\r\n%s(%d) device_create err!\n", __FUNCTION__, __LINE__);
		ret=RTN_ERR;
		goto DEVICE_CREATE_ERR;	
	}
	
	return(RTN_OK);

DEVICE_CREATE_ERR:
	cdev_del(&g_mmi_dev.cdev);
CDEV_ADD_ERR:
	unregister_chrdev_region(g_mmi_dev.dev_no, 1);
ALLOC_DEV_ERR:
	mmi_sysfs_release();
	
	return ret;	
}

void __exit sf_mmi_module_exit(void)
{
	printk("exit mmi module\n");
	lcd_exit(&g_mmi_dev.lcd_dev);
	device_destroy(g_mmi_dev.class, g_mmi_dev.dev_no);
	unregister_chrdev_region(g_mmi_dev.dev_no, 1);
	cdev_del(&g_mmi_dev.cdev);
	//ClearPageReserved(virt_to_phys(g_mmi_dev.frame_buf));
	mmi_sysfs_release();
	return;
}

module_init(sf_mmi_module_init);
module_exit(sf_mmi_module_exit);

MODULE_AUTHOR("liuwanpeng@sf-auto");
MODULE_DESCRIPTION("zynq fpga mmi module:"MMI_MODULE_VER_INFO);
MODULE_LICENSE("Dual BSD/GPL");

#endif
