#!/bin/sh

git rev-list HEAD | sort > git.info.tmp-hash
LOCALVER=`wc -l git.info.tmp-hash | awk '{print $1}'`
if [ $LOCALVER \> 1 ] ; then
	VER=`git rev-list master | sort | join git.info.tmp-hash - | wc -l | awk '{print $1}'`
   
	if [ $VER != $LOCALVER ] ; then
		VER="$VER+$(($LOCALVER-$VER))"
	fi

	if git status | grep -q "modified:" ; then
		VER="${VER}M"
	fi
	
	VER="$VER $(git rev-list HEAD -n 1 | cut -c 1-8)"

	GIT_VERSION="0x$(git rev-list HEAD -n 1 | cut -c 1-8)"
else
	GIT_VERSION="0xFFFFFFFF"
	VER="x"
fi

rm -f git.info.tmp-hash
 
rm -rf ./ver_inc
mkdir ./ver_inc

VER_INC_PATH="./ver_inc/git_ver.h"

echo "#ifndef __GIT_VERSION_H__" > $VER_INC_PATH
echo  >> $VER_INC_PATH

echo "/*" >> $VER_INC_PATH
echo "* auto generate. Don't edit!" >> $VER_INC_PATH
echo "*/" >> $VER_INC_PATH

echo >> $VER_INC_PATH

echo "#define __GIT_VERSION_H__" >> $VER_INC_PATH
echo  >> $VER_INC_PATH
echo "#define GIT_COMMIT_ID	$GIT_VERSION" >> $VER_INC_PATH
echo "#define GIT_COMMIT_ID_STR	\"$GIT_VERSION\" ">> $VER_INC_PATH

echo  >> $VER_INC_PATH

echo "#endif" >> $VER_INC_PATH

