#ifndef __GIT_VERSION_H__

/*
* auto generate. Don't edit!
*/

#define __GIT_VERSION_H__

#define GIT_COMMIT_ID	0xd1cc8fdd
#define GIT_COMMIT_ID_STR	"0xd1cc8fdd" 

#endif
