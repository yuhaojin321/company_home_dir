# ZYNQ FPGA DRIVER INTERFACE #
#
## 更新记录 ##
    2018-05-09  cuijinjin   初版上传
    
## 缩写解释 ##
	FPGA GLB	:		FPGA GLOBAL地址
	S_O			:		FPGA STRONG ORDER访问模式
	BPM			:		后端处理模块
## GP FUNCTION ##
	include file	:	sf_fpga_gp.h
	depend module 	:	gp_base_module.ko
### GP DATETYPE ###
	无;
	
### GP INTERFACE ###
	
	/*
	 * 功能描述:获取__arm_ioremap(S_O模式)FPGA GLB地址;
	 * 输入参数:无;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -1- uint32 get_gp_global_remap(void);

	/*
	 * 功能描述:获取__arm_ioremap(S_O模式)FPGA 前端处理模块地址;
	 * 输入参数:无;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -2- uint32 get_gp_pre_remap(void);

	/*
	 * 功能描述:获取__arm_ioremap(S_O模式)FPGA ACP处理模块地址;
	 * 输入参数:无;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -3- uint32 get_gp_acp_remap(void);

	/*
	 * 功能描述:获取__arm_ioremap(S_O模式)FPGA MAC(7015)地址;
	 * 输入参数:
	 * 			macN:		mac号;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -4- uint32 get_gp_mac_remap(int macN);

	/*
	 * 功能描述:获取__arm_ioremap(S_O模式)FPGA 前端处理模块(7010)地址;
	 * 输入参数:无;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -5- uint32 get_gp_pre_7010_remap(void);


## ACP FUNCTION ##
	include file	:	sf_fpga_acp.h
	depend module 	:	acp_pipe_module.ko
### ACP DATETYPE ###
	typedef struct acp_bd_stru
	{
		uint32 u32_SN_Whllen;
		uint32* pu32_DataAddr;
		uint32 u32_CtrlInfo;
		uint32 u32_PortMask;
	} acp_bd_t;
	
	typedef struct acp_pipe_cfg_stru
	{
		uint32 pipe_no;
		uint32 is_valid;
		uint32 pipe_attr;

		uint32 bd_baseaddr;
		uint32 bd_vaddr;
		uint32 bd_size;
		uint32 bd_rd;
		uint32 bd_wr;
	
		uint32 data_baseaddr;
		uint32 data_vaddr;
		uint32 data_size;
		uint32 data_rd;
		uint32 data_wr;
	} acp_pipe_cfg_t;

### ACP INTERFACE ###
	/*
	 * 获取acp bd空间地址;
	 * 输出参数:
	 * 			size:		空间大小;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -1- void* alloc_acp_bd_mem(int size);

	/*
	 * 获取acp data空间地址;
	 * 输出参数:
	 * 			size:		空间大小;
	 * 返回值:异常(NULL)/非NULL地址;
	 */
	 -2- void* alloc_acp_data_mem(int size);

	/*
	 * 获取acp pipe数据;
	 * 输出参数:
	 * 			pipe_no:	接收管道号;
	 * 			bd:			未处理BD地址;
	 * 返回值:未处理BD数量;
	 */
	 -3- int acp_pipe_read(int pipe_no, acp_bd_t *bd);

	/*
	 * 已处理acp pipe数据;
	 * 输出参数:
	 * 			pipe_no:	接收管道号;
	 * 			bd_no:		处理后bd索引;
	 * 			data_offset:处理后数据区索引;
	 * 返回值:RTN_OK/RTN_ERR;
	 */
	 -4- int acp_pipe_read_processed(int pipe_no, int bd_no, int data_offset);

	/*
	 * 发送acp pipe数据;
	 * 输出参数:
	 * 			pipe_no:	发送管道号;
	 * 			bd:			待发送bd;
	 * 返回值:RTN_OK/RTN_ERR;
	 */
	 -5- int acp_pipe_write(int pipe_no, acp_bd_t *bd);

	/*
	 * 接收管道配置;
	 * 输出参数:
	 * 			cfg:	接收管道配置参数;
	 * 返回值:RTN_OK/RTN_ERR;
	 */
	 -6- int acp_pipe_rx_init(acp_pipe_cfg_t *cfg);

	/*
	 * 发送管道配置;
	 * 输出参数:
	 * 			cfg:	发送管道配置参数;
	 * 返回值:RTN_OK/RTN_ERR;
	 */
	 -7- int acp_pipe_tx_init(acp_pipe_cfg_t *cfg);

	/*
	 * acp pipe bd是否满；
	 * 输出参数:
	 * 			pipe_no:	发送管道号;
	 * 返回值:TRUE(1)/FALSE(0);
	 */
	 -8- int acp_pipe_bd_is_full(int pipe_no);

	/*
	 * acp pipe data是否满；
	 * 输出参数:
	 * 			pipe_no:	发送管道号;
	 * 			data_len:	待发送数据长度;
	 * 			tx_data_pos:可发送数据位置；
	 * 返回值:TRUE(1)/FALSE(0);
	 */
	 -9- int acp_pipe_data_is_full(int pipe_no, int data_len, uint32 *tx_data_pos);

	/*
	 * 获取acp pipe bd剩余数量；
	 * 输出参数:
	 * 			pipe_no:	管道号;
	 * 返回值:acp pipe bd剩余数量;
	 */
	 -10- int acp_pipe_bd_remainder(int pipe_no);

	/*
	 * 获取acp pipe bd使用数量；
	 * 输出参数:
	 * 			pipe_no:	管道号;
	 * 返回值:acp pipe bd使用数量;
	 */
	 -11- int acp_pipe_bd_used(int pipe_no);

## ETHERNET BPM ##
	include file	:	sf_fpga_eth_bpm.h
	depend module 	:	fpga_ethernet.ko
### ETHERNET BPM DATETYPE ###
	typedef enum {
		RTN_DROP = 0,
		RTN_NO_CARE = 1,
		RTN_REBOUND = 2,
	} CB_RTN;
###  ETHERNET BPM INTERFACE ###
	/*
	 * 注册以太网接收函数回调；
	 * 输出参数:
	 * 			eth_port:	以太网口号;
	 * 			rx_cb:		回调函数;
	 * 		 			CB_RTN func_name(int eth_port, char* recv_bd_data, char* rebound_skb_data);
	 * 			 			eth_port:		接收以太网口号;
	 *			 			recv_bd_data:	接收数据内容;
	 *			 			rebound_skb_data:发送数据内容;
	 * 返回值:RTN_OK/RTN_ERR;
	 */
	 -1- int eth_bpm_rx_register(int eth_port, void *rx_cb);

	/*
	 * 注册以太网发送函数回调；
	 * 输出参数:
	 * 			eth_port:	以太网口号;
	 * 			tx_cb:		回调函数;
	 * 		 			CB_RTN func_name(int eth_port, char* xmit_bd_data);
	 *			 			eth_port:		接收以太网口号;
	 *			 			xmit_bd_data:	待发送BD报文内容;
	 * 返回值:RTN_OK/RTN_ERR;
	 */
	 -2- int eth_bpm_tx_register(int eth_port, void *tx_cb);