#ifndef _SF_FPGA_ETH_BPM_H_
#define _SF_FPGA_ETH_BPM_H_

#include "basedefine.h"
#include "basetype.h"

typedef enum {
	RTN_DROP = 0,
    RTN_NO_CARE = 1,
    RTN_REBOUND = 2,
    RTN_TX_PROCED = 3,
} CB_RTN;

extern int eth_bpm_rx_register(int eth_port, void *rx_cb);
extern int eth_bpm_tx_register(int eth_port, void *tx_cb);
#endif /* _SF_FPGA_ETH_BPM_H_ */