#ifndef _SF_FPGA_ACP_H_
#define _SF_FPGA_ACP_H_

#include "basedefine.h"
#include "basetype.h"

typedef struct acp_bd_stru
{
	uint32 u32_SN_Whllen;
	uint32* pu32_DataAddr;
	uint32 u32_CtrlInfo;
	uint32 u32_PortMask;
} acp_bd_t;

typedef struct acp_pipe_cfg_stru
{
	uint32 pipe_no;
	uint32 is_valid;
	uint32 pipe_attr;

	uint32 bd_baseaddr;
	uint32 bd_vaddr;
	uint32 bd_size;
	uint32 bd_rd;
	uint32 bd_wr;
	
	uint32 data_baseaddr;
	uint32 data_vaddr;
	uint32 data_size;
	uint32 data_rd;
	uint32 data_wr;
} acp_pipe_cfg_t;

typedef enum {
	ACP_PIPE_VALID 	= 0x55555555,
	ACP_PIPE_INVALID= 0xAAAAAAAA,
} _ACP_PIPE_STATUS;

extern void* alloc_acp_bd_mem(int size);

extern void* alloc_acp_data_mem(int size);

extern int acp_pipe_read(int pipe_no, acp_bd_t *bd);

extern int acp_pipe_read_processed(int pipe_no, int bd_no, int data_offset);

extern int acp_pipe_write(int pipe_no, acp_bd_t *bd);

extern int acp_pipe_rx_init(acp_pipe_cfg_t *cfg);

extern int acp_pipe_tx_init(acp_pipe_cfg_t *cfg);

extern int acp_pipe_bd_is_full(int pipe_no);

extern int acp_pipe_data_is_full(int pipe_no, int data_len, uint32 *tx_data_pos);

extern int acp_pipe_bd_remainder(int pipe_no);

extern int acp_pipe_unxmit_port_info(int pipe_no, int port_no, int32 *xmited_data_pos);

extern int get_rx_pipe(uint32 type);

extern int get_tx_pipe(void);

extern int find_real_bd(uint32 pipe_no, int32 *bd_rd);

#endif /* _SF_FPGA_ACP_H_ */
