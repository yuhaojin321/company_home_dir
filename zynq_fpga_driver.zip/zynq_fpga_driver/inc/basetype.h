/**
 *  @file basetype.h
 *
 *  @version v1.0
 *
 *  Copyright (c) 2004 BEIJING SIFANG AUTOMATION CO.,LTD.
 *
 *  @brief һЩ��������������Ͷ���
 */

//////////////////////////////////////////////////////////////////////////

#ifndef __BASETYPE_H_INCLUDE__
#define __BASETYPE_H_INCLUDE__

#include <stdbool.h>

#if defined(__cplusplus)
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif

typedef signed char    sint8;
typedef signed short   sint16;
typedef signed int     sint32;

typedef signed char    int8;
typedef signed short   int16;
typedef signed int     int32;

typedef unsigned char   uint8;
typedef unsigned short  uint16;
typedef unsigned int    uint32;
typedef unsigned char   bystrm;	/* compact byte stream */
typedef unsigned int    _hwclk; /* hardware clock tag */

typedef unsigned char   u8;
typedef unsigned short  u16;
typedef unsigned int    u32;

typedef unsigned long   ulong;

typedef float float32;

#ifdef WIN32
  typedef __int64 int64;
  typedef unsigned __int64 uint64;
#else // zynq
  typedef long long				int64;
  typedef unsigned long long	uint64;
#endif

typedef enum {falses=0, trues}	Boolean;

// ��Ƭ�����ݳ��õ��޷�������
#ifndef WIN32
typedef signed char    INT8;
typedef signed short   INT16;
typedef signed int     INT32;

typedef unsigned char   UINT8;
typedef unsigned short  UINT16;
typedef unsigned int    UINT32;

typedef UINT8    BYTE;
typedef UINT16   WORD;
typedef UINT32   DWORD;
#endif

typedef struct{
    uint16 year;
    uint8 month;
    uint8 date;
    uint8 hour;
    uint8 minute;
    uint8 second;
}struTime;

typedef struct
{
	uint8	Byte0;
	uint8	Byte1;
	uint8	Byte2;
	uint8	Byte3;
}FBYTE;

typedef union
{
	uint32	u32Long;
	FBYTE	fByte;
}LWORD;

#undef  NULL
#ifndef NULL
#ifdef __cplusplus
#define NULL    0
#else  /* __cplusplus */
#define NULL    ((void *)0)
#endif  /* __cplusplus */
#endif  /* NULL */

#if 0
#ifndef __inline
#define __inline
#endif
#endif

#if defined(__cplusplus)
}   // extern "C" { 
#endif 

#endif  /* __BASETYPE_H_INCLUDE__ */
