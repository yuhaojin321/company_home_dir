#ifndef _SF_MMI_H_
#define _SF_MMI_H_

/***********************************************
 *  ioctl cmd start
 ***********************************************/
// lcd
#define MMI_CMD_FLUSH_FRM_BUF		0x01		// flush the frame buf to LCD,using 0 as 3st argment of ioctl 
#define MMI_CMD_CTRL_BACKLIGH		0x02		// 0,turn off back light; 1,turn on,using 0 as 3st argment of ioctl 
#define MMI_CMD_GET_STATUS			0x03		// 1,LCD is busy; 0,not busy,using 0 as 3st argment of ioctl 

// led 
#define MMI_CMD_LED_CTRL			0x04		// led control, using 3st argment of of ioctl to choose led and color
												// detail of 3st argment:
												// bit 0~1: 0:off;1,red; 2,green;3,red and green
												// bit 2~7: reserve
												// bit 8~15: choose led, 0~17
												// bit 16~31:reserve
#define MMI_CMD_LED_ALL_OFF			0x05
#define MMI_CMD_LED_ALL_RED			0x06
#define MMI_CMD_LED_ALL_GREEN		0x07
#define MMI_CMD_LED_ALL_RG			0x08		// red and green

// key
#define MMI_CMD_KEY_VAL				0x09		// all key status,0 pressed, 1 not pressed
												// bit0 : key0
												// bit1 : key1
												//   ...
												// bit15: key15
// lcd hardware debug		
#define MMI_CMD_WR_CMD1				0xF0
#define MMI_CMD_WR_CMD2				0xF1
#define MMI_CMD_WR_DATA1			0xF2
#define MMI_CMD_WR_DATA2			0xF3
/***********************************************
 *  ioctl cmd end  
 ***********************************************/


// led control code
#define MMI_LED_OFF			0		// MMI_CMD_LED_CTRL
#define MMI_LED_RED			1
#define MMI_LED_GREEN		2
#define MMI_LED_RG			3

#define MMI_LCD_BUSY 		1		// 	MMI_CMD_GET_STATUS
#define MMI_LCD_IDLE 		0	

#endif