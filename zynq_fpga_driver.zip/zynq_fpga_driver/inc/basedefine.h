/**
 *  @file basedefine.h
 *
 *  @version v1.0
 *
 *  Copyright (c) 2004 BEIJING SIFANG AUTOMATION CO.,LTD.
 *
 *  @brief һЩ������ĺ꺯������
 */

//////////////////////////////////////////////////////////////////////////

#ifndef __BASEDEFINE_H_INCLUDE__
#define __BASEDEFINE_H_INCLUDE__


#if defined(__cplusplus)
extern "C" {     /* Make sure we have C-declarations in C++ programs */
#endif


#define FALSE   0
#define TRUE    1

#define SAFE_TRUE	(0x5A)
#define SAFE_FALSE	(0xA5)

#define RTN_TYPE	int
#define RTN_OK		(0)
#define RTN_ERR		(-1)


// һά����
#define ARRAYSIZEOF(a)   (sizeof(a)/sizeof(a[0]))

// ����ϵͳĬ������֧�ֵĸ�λ
#define MAKEBIT(n)  (1<<(n))

// ��������������һ��aΪ��������bΪ����
#define MAKEDIVISOR(a,b)    (((a)+(((b)+1)/2))/(b))

#define SETFLAG(pVal,num)   do{((UINT8 *)pVal)[(num)>>3] |= MAKEBIT((num)&0x07);}while(0)
#define CLRFLAG(pVal,num)   do{((UINT8 *)pVal)[(num)>>3] &= ~MAKEBIT((num)&0x07);}while(0)
#define GETFLAG(pVal,num)   (((UINT8 *)pVal)[(num)>>3]&MAKEBIT((num)&0x07))

#define SET32FLAG(pVal,num)   do{((UINT32 *)pVal)[(num)>>5] |= MAKEBIT((num)&0x1f);}while(0)
#define CLR32FLAG(pVal,num)   do{((UINT32 *)pVal)[(num)>>5] &= ~MAKEBIT((num)&0x1f);}while(0)
#define GET32FLAG(pVal,num)   (((UINT32 *)pVal)[(num)>>5]&MAKEBIT((num)&0x1f))

/* 
#   ����������   ����   
  ����   #define     sssss(x)   #x   
  string   p   =   sssss(a);   ת��Ϊ   string   p   =   "a";   
*/
#ifndef WIN32
// ����WORD��aΪ���ֽڣ�bΪ���ֽ�
#define MAKEWORD(a,b)   (((WORD)(a)&0xff)+(((WORD)(b)&0xff)<<8))
#define MAKEDWORD(a,b,c,d)   (((DWORD)MAKEWORD(a,b)&0xffff)+(((DWORD)MAKEWORD(c,d)&0xffff)<<16))
	
#define HIBYTE(word)  ((BYTE)(((WORD)(word))>>8))
#define LOBYTE(word)  ((BYTE)(((WORD)(word))&0x00FFU))
#define HIWORD(dWord) ((WORD)(((DWORD)(dWord))>>16))
#define LOWORD(dWord) ((WORD)(((DWORD)(dWord))&0x0000FFFFUL))
#endif

#define BYTE_TO_WORD(a)		                (((a)+1)>>1)
#define BYTE_TO_DWORD(a)	                (((a)+3)>>2)

#define LEN8_TO_SIZE32(a)					(((a)+3)>>2)
#define SIZE_32BIT_TO_32BYTE(a)				(((a)+7)>>3)
 

#if defined(__cplusplus)
}   // extern "C" { 
#endif 
#endif  /* __BASEDEFINE_H_INCLUDE__ */
