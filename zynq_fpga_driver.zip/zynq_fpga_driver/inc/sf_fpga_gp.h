#ifndef _SF_FPGA_GP_H_
#define _SF_FPGA_GP_H_

#include "basedefine.h"
#include "basetype.h"

#define REG_WR(u32_OutAddress, u32_Value)		*(volatile unsigned int*) (u32_OutAddress) = u32_Value
#define REG_RD(u32_Addr)  					 	(*( volatile unsigned int*) (u32_Addr))

extern uint32 get_gp_global_remap(void);
extern uint32 get_gp_pre_remap(void);
extern uint32 get_gp_acp_remap(void);
extern uint32 get_gp_mac_remap(int macN);
extern uint32 get_gp_pre_7010_remap(void);
#endif /* _SF_FPGA_GP_H_ */