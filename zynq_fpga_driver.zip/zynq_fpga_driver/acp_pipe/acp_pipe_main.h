#ifndef _ACP_PIPE_MAIN_H_
#define _ACP_PIPE_MAIN_H_

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "../ver_inc/git_ver.h"

#define ACP_PIPE_DEV_NAME	"sf_acp_pipe"
#define ACP_PIPE_VER_INFO	GIT_COMMIT_ID_STR

#define ACP_PIPE_MAX	(0x20)

typedef enum {
	ACP_PIPE_DATA_ADDR 		= 0x00,
	ACP_PIPE_DATA_DEPTH		= 0x04,
	ACP_PIPE_BD_ADDR 		= 0x08,
	ACP_PIPE_BD_DEPTH		= 0x0C,
	ACP_PIPE_IGR_PS_RD		= 0x10,
	ACP_PIPE_IGR_PL_BD_WR	= 0x14,
	ACP_PIPE_IGR_PL_DATA_WR	= 0x1fc,
	ACP_PIPE_IGR_ATTRIB		= 0x18,
	ACP_PIPE_SEG_LENGTH		= 0x200,
	ACP_PIPE_BASE			= 0x1000,
} _ACP_PIPE_T;

typedef enum {
	GP_GLOBAL_ACP_MAP_NUM		= 0x00DC,
	GP_GLOBAL_ACP_TUNNEL_MAP0	= 0x00E0,
	GP_GLOBAL_ACP_TUNNEL_MAP1	= 0x00E4,
	GP_GLOBAL_ACP_TUNNEL_MAP2	= 0x00E8,
	GP_GLOBAL_ACP_TUNNEL_MAP3	= 0x00EC,
} _PIPE_INFO_ON_GP_T;

#endif	/*_ACP_PIPE_MAIN_H_*/
