#ifndef _ACP_PIPE_MAIN_C_
#define _ACP_PIPE_MAIN_C_

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioport.h>

#include "../inc/sf_fpga_acp.h"
#include "../inc/sf_fpga_gp.h"

#include "acp_pipe_sysfs.h"
#include "acp_pipe_main.h"

#ifdef CONFIG_SMP_ACP_PIPE
	#pragma message("Complie acp smp mode!")
#else
	#pragma message("Complie acp amp mode!")
#endif

extern sint32 acp_pipe_mem_init(void);
static uint32 g_gp_acp_remap = 0;
static uint32 g_tx_pipe_cnt = 0;
static uint32 g_rx_pipe_cnt = 0;

static acp_pipe_cfg_t g_acp_pipe_info[ACP_PIPE_MAX];
static atomic_t g_pipe_atomic[ACP_PIPE_MAX];

int acp_pipe_read(int pipe_no, acp_bd_t *bd)
{
	int rs = RTN_ERR;
	uint32 reg_tmp = 0;
	uint32 pipe_offset = 0;
	uint32 bd_pl_wr = 0;
	uint32 bd_ps_rd = 0;
	uint32 bd_size = 0;
	acp_bd_t *bd_vaddr = NULL;

	if(g_acp_pipe_info[pipe_no].is_valid != ACP_PIPE_VALID)
		return(rs);
	
	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PL_BD_WR);
	
	bd_pl_wr = reg_tmp&0x3FFF;

	if(unlikely(bd_pl_wr != (~(reg_tmp>>18&0x3FFF)&0x3FFF))) {
		printk("%s(%d): PIPE_%d bd_pl_wr:0x%08x	~bd_pl_wr:0x%08x\n"
				, __FUNCTION__
				, __LINE__
				, pipe_no
				, bd_pl_wr
				, ~(reg_tmp>>18&0x3FFF)&0x3FFF);
		return(RTN_ERR); 
	}
	
	bd_ps_rd = g_acp_pipe_info[pipe_no].bd_rd;
	
	if(likely(bd_ps_rd == bd_pl_wr))
		return(0);
	
	bd_size = g_acp_pipe_info[pipe_no].bd_size;
	
	if(unlikely(bd_pl_wr >= bd_size)) {
		printk("%s(%d): PIPE_%d bd %d out of range!\n"
				, __FUNCTION__
				, __LINE__
				, pipe_no
				, bd_pl_wr);
	}
	
	bd_vaddr = (acp_bd_t*)(g_acp_pipe_info[pipe_no].bd_vaddr + (bd_ps_rd<<4));

	mb();
	bd->u32_SN_Whllen = bd_vaddr->u32_SN_Whllen;
	bd->pu32_DataAddr = bd_vaddr->pu32_DataAddr;
	bd->u32_CtrlInfo = bd_vaddr->u32_CtrlInfo;
	bd->u32_PortMask = bd_vaddr->u32_PortMask;

	if(likely(bd_pl_wr > bd_ps_rd))
		rs = bd_pl_wr - bd_ps_rd;
	else
		rs = bd_size - bd_ps_rd;
	
	return(rs);
}
EXPORT_SYMBOL_GPL(acp_pipe_read);

int acp_pipe_read_processed(int pipe_no, int proc_bd_no, int data_offset)
{
	uint32 pipe_offset = 0;
	uint32 bd_rd = 0;

	if(unlikely(g_acp_pipe_info[pipe_no].is_valid != ACP_PIPE_VALID))
		return(RTN_ERR);

	bd_rd = g_acp_pipe_info[pipe_no].bd_rd;
	bd_rd = (bd_rd+proc_bd_no)%(g_acp_pipe_info[pipe_no].bd_size);
	
	g_acp_pipe_info[pipe_no].bd_rd = bd_rd;
	
	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	
	REG_WR(pipe_offset+ACP_PIPE_IGR_PS_RD,((data_offset<<14)&0xFFFFC000)|(g_acp_pipe_info[pipe_no].bd_rd&0x3FFF));
	
	return(RTN_OK);
}
EXPORT_SYMBOL_GPL(acp_pipe_read_processed);

int acp_pipe_write(int pipe_no, acp_bd_t *bd)
{
	int rs = RTN_ERR;
	uint32 reg_tmp = 0;
	uint32 pipe_offset = 0;
	uint32 bd_ps_wr = 0;
	acp_bd_t *bd_vaddr = NULL;

	if(unlikely(g_acp_pipe_info[pipe_no].is_valid != ACP_PIPE_VALID))
		return(rs);

	
	if(unlikely(acp_pipe_bd_is_full(pipe_no) == TRUE)) {
		return(rs);
	}

	if(unlikely(0 == atomic_read(&g_pipe_atomic[pipe_no]))) {
		return(rs);
	}

	atomic_set(&g_pipe_atomic[pipe_no], 0);
	
	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD);
	
	bd_ps_wr = g_acp_pipe_info[pipe_no].bd_wr;
	bd_vaddr = (void *)(g_acp_pipe_info[pipe_no].bd_vaddr + (bd_ps_wr<<4));

	mb();
	bd_vaddr->u32_SN_Whllen	= bd->u32_SN_Whllen;
	bd_vaddr->pu32_DataAddr	= bd->pu32_DataAddr;
	bd_vaddr->u32_CtrlInfo 	= bd->u32_CtrlInfo;
	bd_vaddr->u32_PortMask	= bd->u32_PortMask;
	
	mb();
	bd_ps_wr = bd_ps_wr + 1;
	bd_ps_wr = bd_ps_wr % g_acp_pipe_info[pipe_no].bd_size;

	reg_tmp = ((~bd_ps_wr) & 0x3fff) << 18;
	reg_tmp |= (bd_ps_wr & 0x3fff);
	
	REG_WR(pipe_offset+ACP_PIPE_IGR_PL_BD_WR, reg_tmp);

	g_acp_pipe_info[pipe_no].bd_wr = bd_ps_wr;

#if 0
	wr_data_offset = ((uint32)(bd->pu32_DataAddr))+((bd->u32_SN_Whllen)&0xffff)- g_acp_pipe_info[pipe_no].data_baseaddr;
	wr_data_offset = wr_data_offset>>5;
	wr_data_offset = wr_data_offset % g_acp_pipe_info[pipe_no].data_size;

	g_acp_pipe_info[pipe_no].data_wr = wr_data_offset;
#endif

	atomic_set(&g_pipe_atomic[pipe_no], 1);
	rs = RTN_OK;
	return(rs);
}
EXPORT_SYMBOL_GPL(acp_pipe_write);

int acp_pipe_unxmit_port_info(int pipe_no, int port_no, int32 *xmited_data_pos)
{
	int32 bd_pl_rd = 0;
	int32 bd_ps_wr = 0;
	uint32 bd_size = 0;
	uint32 port_mask = (0x01<<port_no);
	int32 pos = 0;
	acp_bd_t *bd_vaddr = NULL;
	int32 bd_cnt = 0;

	*xmited_data_pos = 0;
	if(find_real_bd(pipe_no, &bd_pl_rd) == RTN_ERR)
		return(RTN_ERR);

#if 0	
	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD);
	bd_pl_rd = reg_tmp & 0x3fff;
#endif
	
	bd_ps_wr = g_acp_pipe_info[pipe_no].bd_wr;
	bd_size = g_acp_pipe_info[pipe_no].bd_size;

	if(likely(bd_ps_wr == bd_pl_rd))
		return(RTN_OK);

	bd_cnt = bd_pl_rd + bd_size - bd_ps_wr;
	bd_cnt = bd_cnt%bd_size;

	bd_pl_rd = bd_pl_rd + bd_size - 1;

	while(bd_cnt) {
		pos = bd_pl_rd%bd_size;
		bd_vaddr = (void *)(g_acp_pipe_info[pipe_no].bd_vaddr + (pos<<4));	
		if((bd_vaddr->u32_PortMask) == port_mask) {
				*xmited_data_pos = ((uint32)(bd_vaddr->pu32_DataAddr)) - (g_acp_pipe_info[pipe_no].data_baseaddr);
				*xmited_data_pos = *xmited_data_pos + ((bd_vaddr->u32_SN_Whllen)&0xFFFF);
#if 0
				if((*xmited_data_pos)&0x1f != 0) {
					printk("<%d>:port_%d(pipe_%d)	pl_rd(0x%04x):ps_wr(0x%04x)	date pos from bd(0x%04x):0x%x(0x%x) 	data pos from gp:0x%x\n"
							, __LINE__
							, port_no
							, pipe_no
							, bd_pl_rd
							, bd_ps_wr
							, i
							, (*xmited_data_pos));
				}
#endif				
				return(RTN_OK);
		}
		bd_pl_rd--;
		bd_cnt--;
	}
	
	return(RTN_OK);
}
EXPORT_SYMBOL_GPL(acp_pipe_unxmit_port_info);

int find_real_bd(uint32 pipe_no, int32 *bd_rd)
{
	uint32 pipe_offset = 0;
	uint32 reg_tmp = 0;
	int32 data_pl_rd = 0;
	
	int32 bd_ps_wr = 0;
	int32 bd_size = 0;
	uint32 xmited_data_pos = 0;
	
	int32 pos = 0;
	int32 i = 0;
	int32 loop_cnt = 0;
	acp_bd_t *bd_vaddr = NULL;

	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD);
	data_pl_rd = (reg_tmp>>14) & 0x3ffff;

	bd_ps_wr = g_acp_pipe_info[pipe_no].bd_wr;
	bd_size = g_acp_pipe_info[pipe_no].bd_size;

	pos = bd_ps_wr + bd_size -1;
	loop_cnt = bd_size;
	while(loop_cnt > 0) {
	
		i = pos%bd_size;
		bd_vaddr = (void *)(g_acp_pipe_info[pipe_no].bd_vaddr + (i<<4));
		xmited_data_pos =  ((uint32)(bd_vaddr->pu32_DataAddr)) - (g_acp_pipe_info[pipe_no].data_baseaddr);
//		xmited_data_pos = xmited_data_pos + ((bd_vaddr->u32_SN_Whllen)&0xFFFF);

		if((xmited_data_pos>>5) == data_pl_rd) {
				*bd_rd = i;
				return(RTN_OK);
		}
		pos--;
		loop_cnt--;
	}

#if 0
	printk("<%d> pipe_%d	data_pl_rl:0x%08x bd_ps_wr:0x%08x\n"
			, __LINE__
			, pipe_no
			, data_pl_rd
			, bd_ps_wr);
#endif	
	return(RTN_ERR);
}
EXPORT_SYMBOL_GPL(find_real_bd);

int acp_pipe_bd_is_full(int pipe_no)
{
	uint32 pipe_offset = 0;
	uint32 reg_tmp = 0;
	uint32 bd_pl_rd = 0;
	uint32 bd_ps_wr = 0;
	uint32 bd_size = 0;

	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD);
	bd_pl_rd = reg_tmp & 0x3fff;
	bd_ps_wr = g_acp_pipe_info[pipe_no].bd_wr;

	bd_size = g_acp_pipe_info[pipe_no].bd_size;

	if(unlikely(bd_pl_rd == 0 && bd_ps_wr >= (bd_size-1))) {
		return(TRUE);
	}
	
	if(unlikely((bd_pl_rd-1) == bd_ps_wr)) {
		return(TRUE);
	}

	return(FALSE);
}
EXPORT_SYMBOL_GPL(acp_pipe_bd_is_full);

int acp_pipe_bd_remainder(int pipe_no)
{
	uint32 pipe_offset = 0;
	uint32 reg_tmp = 0;
	uint32 bd_pl_rd = 0;
	uint32 bd_ps_wr = 0;
	uint32 bd_size = 0;
	uint32 cnt = 0;
	
	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD);
	bd_pl_rd = reg_tmp & 0x3fff;
	bd_ps_wr = g_acp_pipe_info[pipe_no].bd_wr;

	bd_size = g_acp_pipe_info[pipe_no].bd_size;
	
	if(unlikely(bd_ps_wr >= bd_pl_rd)) {
		cnt = bd_ps_wr - bd_pl_rd;
		cnt = bd_size - cnt;
	} else {
		cnt = bd_pl_rd - bd_ps_wr;
	}

	return(cnt);
}
EXPORT_SYMBOL_GPL(acp_pipe_bd_remainder);

int acp_pipe_data_is_full(int pipe_no, int data_len, uint32 *tx_data_pos)
{
	uint32 pipe_offset = 0;
	uint32 reg_tmp = 0;
	uint32 data_pl_rd = 0;
	uint32 data_ps_wr = 0;
	uint32 data_size = 0;
	
	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
	reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD);
	data_pl_rd = (reg_tmp>>14) & 0x3ffff;
	data_ps_wr = g_acp_pipe_info[pipe_no].data_wr;

	data_size = g_acp_pipe_info[pipe_no].data_size;
	data_len = data_len>>5;

	if(data_pl_rd >= data_size) {
		printk("Huge error data_pl_rd >= data_size\n");
	}

	if(data_pl_rd > data_ps_wr) {
		if((data_ps_wr+data_len) >= data_pl_rd) {
			return(TRUE);
		}
		else
			*tx_data_pos = data_ps_wr;
		
	} else {
		if((data_ps_wr+data_len) >= data_size) {
			if(data_len >= data_pl_rd) {
				return(TRUE);
			}
			else
				*tx_data_pos = 0;
		} else {
			*tx_data_pos = data_ps_wr;
		}
	}		


	g_acp_pipe_info[pipe_no].data_wr = *tx_data_pos + data_len;

	return(FALSE);
}
EXPORT_SYMBOL_GPL(acp_pipe_data_is_full);

int acp_pipe_rx_init(acp_pipe_cfg_t *cfg)
{
	int rs = RTN_ERR;
	uint32 pipe_no = 0;
	uint32 reg_tmp = 0;
	uint32 pipe_offset;
	
	if(unlikely(cfg == NULL)) {
		return(rs);
	}
	
	pipe_no = cfg->pipe_no;
	
	reg_tmp = REG_RD(g_gp_acp_remap);
	reg_tmp &= ~(0x01<<pipe_no);
	REG_WR(g_gp_acp_remap,reg_tmp);

	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;

	cfg->bd_rd = REG_RD(pipe_offset+ACP_PIPE_IGR_PL_BD_WR) & 0x3fff;
	cfg->bd_wr = cfg->bd_rd;

	cfg->data_rd = REG_RD(pipe_offset+ACP_PIPE_IGR_PL_DATA_WR) & 0x3ffff;
	cfg->data_wr = cfg->data_rd; 
 
	g_acp_pipe_info[pipe_no].pipe_no 		= pipe_no;
	g_acp_pipe_info[pipe_no].is_valid 		= cfg->is_valid;
	g_acp_pipe_info[pipe_no].pipe_attr 		= cfg->pipe_attr;
		
	g_acp_pipe_info[pipe_no].bd_baseaddr 	= cfg->bd_baseaddr;
	g_acp_pipe_info[pipe_no].bd_vaddr 		= cfg->bd_vaddr;
	g_acp_pipe_info[pipe_no].bd_size 		= cfg->bd_size;
	g_acp_pipe_info[pipe_no].bd_rd 			= cfg->bd_rd;
	g_acp_pipe_info[pipe_no].bd_wr 			= cfg->bd_wr;
	
	g_acp_pipe_info[pipe_no].data_baseaddr 	= cfg->data_baseaddr;
	g_acp_pipe_info[pipe_no].data_vaddr 	= cfg->data_vaddr;
	g_acp_pipe_info[pipe_no].data_size 		= cfg->data_size;
	g_acp_pipe_info[pipe_no].data_rd 		= cfg->data_rd*32;
	g_acp_pipe_info[pipe_no].data_wr 		= cfg->data_wr*32;
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_DATA_ADDR,\
	cfg->data_baseaddr);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_DATA_DEPTH,\
	cfg->data_size);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_BD_ADDR,\
	cfg->bd_baseaddr);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_BD_DEPTH,\
	cfg->bd_size);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_IGR_PS_RD,\
	(cfg->bd_rd&0x3fff) | (cfg->data_rd&0x3ffff)<<14);

	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_IGR_ATTRIB,\
	cfg->pipe_attr);
	
	reg_tmp = REG_RD(g_gp_acp_remap);
	reg_tmp |= 0x01<<pipe_no;
	
	REG_WR(g_gp_acp_remap,reg_tmp);

	atomic_set(&g_pipe_atomic[pipe_no], 1);
	rs = RTN_OK;
	return(rs);
}
EXPORT_SYMBOL_GPL(acp_pipe_rx_init);

int acp_pipe_tx_init(acp_pipe_cfg_t *cfg)
{
	int rs = RTN_ERR;
	uint32 pipe_no = 0;
	uint32 reg_tmp = 0;
	uint32 pipe_offset;
	
	if(unlikely(cfg == NULL)) {
		return(rs);
	}
	
	pipe_no = cfg->pipe_no;
	
	/* Modified by zhengg, Stop the acp pipe first */
	reg_tmp = REG_RD(g_gp_acp_remap);
	reg_tmp &= ~(0x01<<pipe_no);
	REG_WR(g_gp_acp_remap,reg_tmp);

	pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;

	cfg->bd_wr = REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD) & 0x3fff;
	cfg->bd_rd = cfg->bd_wr;

	cfg->data_wr = (REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD)>>14) & 0x3ffff;
	cfg->data_rd = cfg->data_wr; 
 
	g_acp_pipe_info[pipe_no].pipe_no 		= pipe_no;
	g_acp_pipe_info[pipe_no].is_valid 		= cfg->is_valid;
	g_acp_pipe_info[pipe_no].pipe_attr 		= cfg->pipe_attr;
		
	g_acp_pipe_info[pipe_no].bd_baseaddr 	= cfg->bd_baseaddr;
	g_acp_pipe_info[pipe_no].bd_vaddr 		= cfg->bd_vaddr;
	g_acp_pipe_info[pipe_no].bd_size 		= cfg->bd_size;
	g_acp_pipe_info[pipe_no].bd_rd 			= cfg->bd_rd;
	g_acp_pipe_info[pipe_no].bd_wr 			= cfg->bd_wr;
	
	g_acp_pipe_info[pipe_no].data_baseaddr 	= cfg->data_baseaddr;
	g_acp_pipe_info[pipe_no].data_vaddr 	= cfg->data_vaddr;
	g_acp_pipe_info[pipe_no].data_size 		= cfg->data_size;
	g_acp_pipe_info[pipe_no].data_rd 		= cfg->data_rd*32;
	g_acp_pipe_info[pipe_no].data_wr 		= cfg->data_wr*32;

	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_DATA_ADDR,\
	cfg->data_baseaddr);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_DATA_DEPTH,\
	cfg->data_size);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_BD_ADDR,\
	cfg->bd_baseaddr);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_BD_DEPTH,\
	cfg->bd_size);
	
	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_IGR_PL_BD_WR,\
	((~cfg->bd_wr)<<18) |cfg->bd_wr);

	REG_WR(g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH+ACP_PIPE_IGR_ATTRIB,\
	cfg->pipe_attr);

	reg_tmp = REG_RD(g_gp_acp_remap);
	reg_tmp |= 0x01<<pipe_no;
	REG_WR(g_gp_acp_remap,reg_tmp);
	
	atomic_set(&g_pipe_atomic[pipe_no], 1);
	rs = RTN_OK;
	return(rs);
}
EXPORT_SYMBOL_GPL(acp_pipe_tx_init);

int do_acp_pipe_show(char* buf)
{
	uint32 pipe_no = 0;
	char *ps = buf;
	int len = 0;
	int rs = 0;
	uint32 pipe_offset = 0;
	uint32 reg_tmp = 0;
	
	rs = sprintf(ps, "\nDRIVER:%s GIT_VER:%s\n",ACP_PIPE_DEV_NAME,ACP_PIPE_VER_INFO);		
	len = len + rs;
	ps = ps + rs;
	
	rs = sprintf(ps, "\n#########RX PIPE INFO#########\n");		
	len = len + rs;
	ps = ps + rs;
	
	for(pipe_no=0; pipe_no<16; pipe_no++) {
		pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
		reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_ATTRIB);
		
		if((reg_tmp&0xFF) != 0xAA) continue;
		
		rs = sprintf(ps, "PIPE_%d: DATATYPE:%d	",pipe_no, (reg_tmp>>16)&0xff);		
		len = len + rs;
		ps = ps + rs;
		
		rs = sprintf(ps, "0x10:0x%08x	0x14:0x%08x\n",\
					REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD),\
					REG_RD(pipe_offset+ACP_PIPE_IGR_PL_BD_WR));		
		len = len + rs;
		ps = ps + rs;

		rs = sprintf(ps, "BD_INFO:bd_addr:0x%08x(0x%08x)	bd_size:0x%08x	0x%0x:0x%0x\n", \
					g_acp_pipe_info[pipe_no].bd_vaddr,g_acp_pipe_info[pipe_no].bd_baseaddr,g_acp_pipe_info[pipe_no].bd_size, \
					g_acp_pipe_info[pipe_no].bd_rd,g_acp_pipe_info[pipe_no].bd_wr);
		
		len = len + rs;
		ps = ps + rs;

		rs = sprintf(ps, "DATA_INFO:data_addr:0x%08x(0x%08x)	data_size:0x%08x	0x%0x:0x%0x\n", \
					g_acp_pipe_info[pipe_no].data_vaddr,g_acp_pipe_info[pipe_no].data_baseaddr,g_acp_pipe_info[pipe_no].data_size, \
					g_acp_pipe_info[pipe_no].data_rd,g_acp_pipe_info[pipe_no].data_wr);
		
		len = len + rs;
		ps = ps + rs;
	}
	
	rs = sprintf(ps, "\n#########TX PIPE INFO#########\n");		
	len = len + rs;
	ps = ps + rs;
	
	for(pipe_no=16; pipe_no<ACP_PIPE_MAX; pipe_no++) {
		pipe_offset = g_gp_acp_remap+ACP_PIPE_BASE+pipe_no*ACP_PIPE_SEG_LENGTH;
		reg_tmp = REG_RD(pipe_offset+ACP_PIPE_IGR_ATTRIB);
		
		if((reg_tmp&0xFF) != 0xAA) continue;
		
		rs = sprintf(ps, "PIPE_%d: DATATYPE:%d	",pipe_no, (reg_tmp>>16)&0xff);		
		len = len + rs;
		ps = ps + rs;
		
		rs = sprintf(ps, "0x10:0x%08x	0x14:0x%08x\n",\
					REG_RD(pipe_offset+ACP_PIPE_IGR_PS_RD),\
					REG_RD(pipe_offset+ACP_PIPE_IGR_PL_BD_WR));		
		len = len + rs;
		ps = ps + rs;

		rs = sprintf(ps, "BD_INFO:bd_addr:0x%08x(0x%08x)	bd_size:0x%08x	0x%0x:0x%0x\n", \
					g_acp_pipe_info[pipe_no].bd_vaddr,g_acp_pipe_info[pipe_no].bd_baseaddr,g_acp_pipe_info[pipe_no].bd_size, \
					g_acp_pipe_info[pipe_no].bd_rd,g_acp_pipe_info[pipe_no].bd_wr);
		
		len = len + rs;
		ps = ps + rs;

		rs = sprintf(ps, "DATA_INFO:data_addr:0x%08x(0x%08x)	data_size:0x%08x	0x%0x:0x%0x\n", \
					g_acp_pipe_info[pipe_no].data_vaddr,g_acp_pipe_info[pipe_no].data_baseaddr,g_acp_pipe_info[pipe_no].data_size, \
					g_acp_pipe_info[pipe_no].data_rd,g_acp_pipe_info[pipe_no].data_wr);
		
		len = len + rs;
		ps = ps + rs;
	}

	return(len);
}

int get_rx_pipe(uint32 type)
{
	int32 rs = RTN_ERR;
	uint32 gp_global_remap = 0;
	uint32 reg_temp = 0;
	int32 i = 0;
	
	gp_global_remap = get_gp_global_remap();
	if(unlikely(gp_global_remap == (uint32)NULL)) {
		printk("<%d>:%s GP GLOBAL ADDRESS ERROR!",__LINE__,__FUNCTION__);
		return(RTN_ERR);
	}
	
	reg_temp = REG_RD(gp_global_remap+GP_GLOBAL_ACP_TUNNEL_MAP0);
	for(i=0;i<4;i++){
		if(((reg_temp>>(i*8))&0xFF) == type)
			break;
	}

	if(i!=4)
		return(i);

	reg_temp = REG_RD(gp_global_remap+GP_GLOBAL_ACP_TUNNEL_MAP1);
	for(i=0;i<4;i++){
		if(((reg_temp>>(i*8))&0xFF) == type)
			break;
	}
	
	if(i!=4)
		return(i+4);
	
	return(rs);
}
EXPORT_SYMBOL_GPL(get_rx_pipe);

int get_tx_pipe(void)
{
	static uint32 pipe_sequ = 0;
	int32 rs = RTN_ERR;
	
	if(pipe_sequ >= g_tx_pipe_cnt)
		return(rs);

#define ACP_TX_PIPE_BASE		(0x10)
	rs = ACP_TX_PIPE_BASE + pipe_sequ;
	pipe_sequ++;
	
	return(rs);
}
EXPORT_SYMBOL_GPL(get_tx_pipe);

int __init acp_pipe_init(void)
{
	int rs = RTN_ERR;
	uint32 gp_global_remap = 0;
	uint32 reg_temp = 0;
	
	printk("%s COMPILE TIME:%s %s\n"
			, ACP_PIPE_DEV_NAME
			, __DATE__
			, __TIME__);
	
	printk("VER:%s\n", ACP_PIPE_VER_INFO);

	gp_global_remap = get_gp_global_remap();
	if(unlikely(gp_global_remap == (uint32)NULL)) {
		printk("<%d>:%s GP GLOBAL ADDRESS ERROR!",__LINE__,__FUNCTION__);
		return(RTN_ERR);
	}
	
	reg_temp = REG_RD(gp_global_remap+GP_GLOBAL_ACP_MAP_NUM);
	
	g_rx_pipe_cnt = reg_temp & 0xffff;
	g_tx_pipe_cnt = (reg_temp>>16) & 0xffff;

	printk("rx_acp_pipe:%d tx_acp_pipe:%d\n"
			, g_rx_pipe_cnt
			, g_tx_pipe_cnt);
	
	g_gp_acp_remap = get_gp_acp_remap();
	if(g_gp_acp_remap == (uint32)NULL) {
		printk("%s(%d): get acp mem fail!\n"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	acp_sysfs_create(ACP_PIPE_DEV_NAME);
	
	rs = acp_pipe_mem_init();
	
	return(rs);
}

void __exit acp_pipe_exit(void)
{
	acp_sysfs_release();
	return;
}

module_init(acp_pipe_init);
module_exit(acp_pipe_exit);

MODULE_AUTHOR("cuijinjin@sf-auto");
MODULE_DESCRIPTION("zynq fpga acp pipe:"ACP_PIPE_VER_INFO);
MODULE_LICENSE("Dual BSD/GPL");

#endif /*_ACP_PIPE__MAIN_C_*/
