#ifndef _ACP_PIPE_MEM_H_
#define _ACP_PIPE_MEM_H_

#define OF_ACP_MEM            "acp-mem"

#define ACP_BD_MEM_OFFSET		(0x0)
#define ACP_DATA_MEM_OFFSET		(0x200000)

#define ACP_BD_MEM_SIZE			(0x200000)
#define ACP_DATA_MEM_SIZE		(0x1E00000)

#define ACP_BD_MEM_ALIGNED		(0x10)
#define ACP_DATA_MEM_ALIGNED	(0x20)

#endif	/*_ACP_PIPE_MEM_H_*/