#ifndef _ACP_PIPE_SYSFS_H_
#define _ACP_PIPE_SYSFS_H_

extern int acp_sysfs_create(const char *dev_name);
extern int acp_sysfs_release(void);

#endif /*_ACP_PIPE_SYSFS_C_*/