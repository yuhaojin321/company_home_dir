#ifndef _ACP_PIPE_MEM_C_
#define _ACP_PIPE_MEM_C_

#include <linux/of.h>

#include "../inc/basedefine.h"
#include "../inc/basetype.h"
#include "acp_pipe_mem.h"

static uint32 acp_mem_base = 0;
static uint32 acp_mem_size = 0;
static uint32 acp_bd_pos = 0;
static uint32 acp_data_pos = 0;

void* alloc_acp_bd_mem(int size)
{
	int pos = 0;
	
	if(size%ACP_BD_MEM_ALIGNED != 0) {
		printk("%s(%d): Bd mem out of range!\n"		
			, __FUNCTION__
			, __LINE__);
		return(NULL);
	}
	
	if(acp_bd_pos+size > ACP_BD_MEM_SIZE) {
		printk("%s(%d): Bd mem out of range!\n"
			, __FUNCTION__
			, __LINE__);
		return(NULL);
	}
	
	pos = acp_mem_base+ACP_BD_MEM_OFFSET+acp_bd_pos;
	acp_bd_pos = acp_bd_pos + size;
	
	return((void *)pos);
}
EXPORT_SYMBOL_GPL(alloc_acp_bd_mem);

void* alloc_acp_data_mem(int size)
{
	int pos = 0;
	
	if(size%ACP_BD_MEM_ALIGNED != 0)
		return(NULL);
	
	if(acp_data_pos+size > ACP_DATA_MEM_SIZE) {
		printk("%s(%d): Data mem out of range!\n"
			, __FUNCTION__
			, __LINE__);
		return(NULL);
	}
	pos = acp_mem_base+ACP_DATA_MEM_OFFSET+acp_data_pos;
	acp_data_pos = acp_data_pos + size;
	
	return((void *)pos);
}
EXPORT_SYMBOL_GPL(alloc_acp_data_mem);

static sint32 of_get_acp_mem(const char *property, uint32 *start, uint32 *size)
{
	const char *name = NULL;
	char *retstr = NULL;
	uint32 value = 0;
	struct device_node *of_chosen = NULL;

	of_chosen = of_find_node_by_path("/chosen");
	if(of_chosen)
		name = of_get_property(of_chosen, property, NULL);
	else{
		pr_err("%s(%d): there is no of_chosen node\n"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}

	if(name == NULL) {
		pr_err("%s(%d): there is no mem parameter in the node\n"
				, __FUNCTION__
				, __LINE__);
		return(RTN_ERR);
	}
	
	printk("%s(%d): name:%s\n"
			, __FUNCTION__
			, __LINE__
			, name);
	value = memparse(name, &retstr);
	*start = value;
	pr_info("%s(%d): acp-mem-start: 0x%08x\n"
			, __FUNCTION__
			, __LINE__
			, value);

	while(*retstr != '\0' && (*retstr == ',' || *retstr == ' '))
		retstr++;
	if(retstr == NULL)
		return(RTN_ERR);
	name = retstr;

	value = memparse(name, &retstr);
	*size = value;
	pr_info("%s(%d): acp-mem-size: 0x%08x\n"
			, __FUNCTION__
			, __LINE__
			, value);

	return(RTN_OK);
}

sint32 acp_pipe_mem_init(void)
{
	int rs = RTN_OK;
	
	rs = of_get_acp_mem(OF_ACP_MEM, &acp_mem_base, &acp_mem_size);
	
	printk("acp_mem_base:0x%08x acp_mem_size:0x%08x\n"
			, acp_mem_base
			, acp_mem_size);
	
	return(rs);
} 

#endif	/*_ACP_PIPE_MEM_C_*/