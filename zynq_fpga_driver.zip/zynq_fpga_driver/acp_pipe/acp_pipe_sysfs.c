#ifndef _ACP_PIPE_SYSFS_C_
#define _ACP_PIPE_SYSFS_C_

/*
 * Implement FPGA ACP information use sysfs.
 * Copyright (C) 2017 sf-auto Ltd. 
 *
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

#include "acp_pipe_sysfs.h"

extern int do_acp_pipe_show(char* buf);

static struct class *_sf_acp_pipe_class = NULL;

static ssize_t acp_info_show(struct class *class, struct class_attribute *attr, char *buf)
{
	int rs = 0;
	int len = 0;
	
	rs = do_acp_pipe_show(buf);
	len = len + rs;
	return(len);
}

static ssize_t acp_info_store(struct class *class, struct class_attribute *attr, const char *buf, size_t count)
{
	return ~0;
}

static struct class_attribute dev_attr_acp_info = {
	.attr = {
		.name = NULL,
		.mode = S_IWUSR | S_IRUGO,
	},
	.show = acp_info_show,
	.store = acp_info_store,
};

int acp_sysfs_create(const char *dev_name)
{
	int rs = RTN_ERR;
	
	_sf_acp_pipe_class = class_create(THIS_MODULE, dev_name);
	if(IS_ERR(_sf_acp_pipe_class) != 0) {
		printk(KERN_ALERT"Failed to create device class.\n");
		return(RTN_ERR);
	}
		
	dev_attr_acp_info.attr.name = dev_name;
	rs = class_create_file(_sf_acp_pipe_class, &dev_attr_acp_info);
	if(rs < 0) {
		printk(KERN_ALERT"Failed to create attribute info device.\n");
		return(RTN_ERR);
	}
	
	return(RTN_OK);	
}

int acp_sysfs_release(void)
{
	class_remove_file(_sf_acp_pipe_class, &dev_attr_acp_info);
	class_destroy(_sf_acp_pipe_class);
	return(RTN_OK);
}

#endif /*_ACP_PIPE_SYSFS_C_*/