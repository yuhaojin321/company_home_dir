#ifndef __LCD_HW_FS8812_NEON_H__
#define __LCD_HW_FS8812_NEON_H__

#include "../inc/basedefine.h"
#include "../inc/basetype.h"

#define LCD_8812_ROW_BYTES		16
#define LCD_8812_PAGE_ROWS		8
#define LCD_PAGE_BYTES			(LCD_8812_ROW_BYTES*LCD_8812_PAGE_ROWS)
#define LCD_PAGE_BYTES_VAL		122

extern int fs8812_cvt_buf( uint8 * dst, uint8 * src );

#endif

