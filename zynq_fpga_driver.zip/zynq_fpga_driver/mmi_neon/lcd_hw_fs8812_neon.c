/*
 * LCD FS-8812S20022 module from JingHua company
 * 122*32 dot,driver IC is SBN1661G_xxx
 */

#include <linux/module.h> 
#include <linux/printk.h>
#include <arm_neon.h>
#include "lcd_hw_fs8812_neon.h"

uint8 g_tmp_buf[LCD_PAGE_BYTES];
int fs8812_cvt_buf( uint8 * dst, uint8 * src )
{
	uint8x16_t V_src[8];
	uint8x16_t V_tmp[8];
	uint8x16_t V_dst[8];
	uint8x16_t V_msk;
	int8x16_t V_shift;
	int8 RSHL_bits[8] = {0,1,2,3,4,5,6,7};
	int8 row,bit;
	uint8 page;
	uint8 * fb_page_x = NULL;
	uint8 i,ram_col,ram_row,ram_ind;
	uint16 off;
	
	uint8 row_bytes;
#if 0
	uint8 i;
	uint8x16_t V_src_test;
	int8x16_t V_shift_test;
	V_src_test = vdupq_n_u8(0xA5);
	V_shift_test = vdupq_n_s8(-4);
	V_src_test = vshlq_u8( V_src_test,V_shift_test );
	printk("\n*******************vshlq_u8 test:\n");
	for(i=0;i<LCD_8812_ROW_BYTES;i++)
		printk("0x%02x ",*((uint8*)(&V_src_test)+i));	
#endif	
	
	// convert the frame_buf for fs8812
	for( page=0;page<4;page++ ){
		//printk("\n*******************page %d:\n",page);
		fb_page_x = src + page*LCD_PAGE_BYTES;
		for( row=0;row<LCD_8812_PAGE_ROWS;row++ ){
			V_src[row] = vld1q_u8( fb_page_x + row*LCD_8812_ROW_BYTES );
			#if 0
			printk("\nsrc row %d\n",row);
			for(i=0;i<LCD_8812_ROW_BYTES;i++)
				printk("0x%02x ",*((uint8*)(&V_src[row])+i));	
			#endif
		}
		for( bit=0;bit<8;bit++){
			V_msk = vdupq_n_u8(1<<bit);
			#if 0
			printk("\n******bit %d,V_msk:\n",bit);
			for(i=0;i<LCD_8812_ROW_BYTES;i++)
				printk("0x%02x ",*((uint8*)(&V_msk)+i));	
			#endif
			for( row=0;row<LCD_8812_PAGE_ROWS;row++){
				V_tmp[row] = vandq_u8(V_src[row],V_msk);	// only process the desire bit
				#if 0
				printk("\nvandq_u8(V_src[row%d],V_msk):\n",row);
				for(i=0;i<LCD_8812_ROW_BYTES;i++)
					printk("0x%02x ",*((uint8*)(&V_tmp[row])+i));		
				#endif
				V_shift = vdupq_n_s8( RSHL_bits[row]-bit );
				#if 0
				printk("\nV_shift:\n");
				for(i=0;i<LCD_8812_ROW_BYTES;i++)
					printk("0x%02x ",*((uint8*)(&V_shift)+i));
				#endif
				V_tmp[row] = vshlq_u8( V_tmp[row],V_shift );
				#if 0
				printk("\nvshlq_u8( V_tmp[row],V_shift ):\n");
				for(i=0;i<LCD_8812_ROW_BYTES;i++)
					printk("0x%02x ",*((uint8*)(&V_tmp[row])+i));				
				#endif
			}	
			V_dst[bit]  =  vorrq_u8(V_tmp[0],V_tmp[1]); // all bit_x convert to one row
			V_dst[bit] |=  vorrq_u8(V_tmp[2],V_tmp[3]);
			V_dst[bit] |=  vorrq_u8(V_tmp[4],V_tmp[5]);
			V_dst[bit] |=  vorrq_u8(V_tmp[6],V_tmp[7]);
			#if 0
			printk("\nV_dst[%d]:\n",bit);
			for(i=0;i<LCD_8812_ROW_BYTES;i++)
				printk("0x%02x ",*((uint8*)(&V_dst[bit])+i));	
			#endif
			
		}
		// store to ram
		fb_page_x = g_tmp_buf + page*LCD_PAGE_BYTES;
		for( row=0;row<LCD_8812_PAGE_ROWS;row++ ){
			vst1q_u8(fb_page_x,V_dst[row]);
			fb_page_x += LCD_8812_ROW_BYTES;
		}

		off=page*LCD_PAGE_BYTES;
		for( i=0;i<LCD_PAGE_BYTES;i++ ){
			ram_row = i&0x07;   // "%8"
			ram_col = i>>3;		// "/8"
			ram_ind = ram_row*LCD_8812_ROW_BYTES + ram_col;
			dst[off+i] = g_tmp_buf[ram_ind];
		}
#if 0
		printk("\n*******************temp buf page %d:\n",page);	
		for(row_bytes=0;row_bytes<LCD_PAGE_BYTES;row_bytes++)
		{
			if( row_bytes%16==0 )
				printk("\r\n");

			printk("0x%02x  ",g_tmp_buf[row_bytes]);
		}
#endif		
	}
#if 0		
	// test
	for( page=0;page<4;page++ ){
		printk("\n*******************SRC page %d:\n",page);
		for(row_bytes=0;row_bytes<16*8;row_bytes++)
		{
			if( row_bytes%16==0 )
				printk("\r\n");

			printk("0x%02x  ",src[page*LCD_PAGE_BYTES+row_bytes]);
		}
		printk("\n*******************DST page %d:\n",page);	
		for(row_bytes=0;row_bytes<16*8;row_bytes++)
		{
			if( row_bytes%16==0 )
				printk("\r\n");

			printk("0x%02x  ",dst[page*LCD_PAGE_BYTES+row_bytes]);
		}
	}
#endif
	return 0;

}
EXPORT_SYMBOL_GPL(fs8812_cvt_buf);






MODULE_AUTHOR("liuwanpeng@sf-auto");
MODULE_DESCRIPTION("zynq fpga mmi neon module V1.0");
MODULE_LICENSE("Dual BSD/GPL");


